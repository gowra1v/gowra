﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Employee
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.LbsEmpID = New System.Windows.Forms.Label()
        Me.LbsFname = New System.Windows.Forms.Label()
        Me.LbsLname = New System.Windows.Forms.Label()
        Me.LbsAddress = New System.Windows.Forms.Label()
        Me.LbsCity = New System.Windows.Forms.Label()
        Me.LbsState = New System.Windows.Forms.Label()
        Me.LbsCountry = New System.Windows.Forms.Label()
        Me.EmpidTextBox = New System.Windows.Forms.TextBox()
        Me.FnameTextBox = New System.Windows.Forms.TextBox()
        Me.LnameTextBox = New System.Windows.Forms.TextBox()
        Me.CityTextBox = New System.Windows.Forms.TextBox()
        Me.StateTextbox = New System.Windows.Forms.TextBox()
        Me.CountryTextBox = New System.Windows.Forms.TextBox()
        Me.AddressRichTextBox = New System.Windows.Forms.RichTextBox()
        Me.LbsZipcode = New System.Windows.Forms.Label()
        Me.LbsContact = New System.Windows.Forms.Label()
        Me.LbsEmailID = New System.Windows.Forms.Label()
        Me.LbsUsername = New System.Windows.Forms.Label()
        Me.LbsPassword = New System.Windows.Forms.Label()
        Me.LbsEmployeetype = New System.Windows.Forms.Label()
        Me.ZipcodeTextBox = New System.Windows.Forms.TextBox()
        Me.EmilIDTextBox = New System.Windows.Forms.TextBox()
        Me.PasswordTextBox = New System.Windows.Forms.TextBox()
        Me.UsernameTextBox = New System.Windows.Forms.TextBox()
        Me.ContactTextBox = New System.Windows.Forms.TextBox()
        Me.EmployeetypeTextBox = New System.Windows.Forms.TextBox()
        Me.SaveButton = New System.Windows.Forms.Button()
        Me.CancelButton = New System.Windows.Forms.Button()
        Me.ClearButton = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'LbsEmpID
        '
        Me.LbsEmpID.AutoSize = True
        Me.LbsEmpID.Location = New System.Drawing.Point(34, 94)
        Me.LbsEmpID.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbsEmpID.Name = "LbsEmpID"
        Me.LbsEmpID.Size = New System.Drawing.Size(63, 20)
        Me.LbsEmpID.TabIndex = 0
        Me.LbsEmpID.Text = "Emp ID"
        '
        'LbsFname
        '
        Me.LbsFname.AutoSize = True
        Me.LbsFname.Location = New System.Drawing.Point(34, 166)
        Me.LbsFname.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbsFname.Name = "LbsFname"
        Me.LbsFname.Size = New System.Drawing.Size(59, 20)
        Me.LbsFname.TabIndex = 1
        Me.LbsFname.Text = "Fname"
        '
        'LbsLname
        '
        Me.LbsLname.AutoSize = True
        Me.LbsLname.Location = New System.Drawing.Point(34, 238)
        Me.LbsLname.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbsLname.Name = "LbsLname"
        Me.LbsLname.Size = New System.Drawing.Size(58, 20)
        Me.LbsLname.TabIndex = 2
        Me.LbsLname.Text = "Lname"
        '
        'LbsAddress
        '
        Me.LbsAddress.AutoSize = True
        Me.LbsAddress.Location = New System.Drawing.Point(34, 311)
        Me.LbsAddress.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbsAddress.Name = "LbsAddress"
        Me.LbsAddress.Size = New System.Drawing.Size(68, 20)
        Me.LbsAddress.TabIndex = 3
        Me.LbsAddress.Text = "Address"
        '
        'LbsCity
        '
        Me.LbsCity.AutoSize = True
        Me.LbsCity.Location = New System.Drawing.Point(34, 400)
        Me.LbsCity.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbsCity.Name = "LbsCity"
        Me.LbsCity.Size = New System.Drawing.Size(35, 20)
        Me.LbsCity.TabIndex = 4
        Me.LbsCity.Text = "City"
        '
        'LbsState
        '
        Me.LbsState.AutoSize = True
        Me.LbsState.Location = New System.Drawing.Point(34, 468)
        Me.LbsState.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbsState.Name = "LbsState"
        Me.LbsState.Size = New System.Drawing.Size(48, 20)
        Me.LbsState.TabIndex = 5
        Me.LbsState.Text = "State"
        '
        'LbsCountry
        '
        Me.LbsCountry.AutoSize = True
        Me.LbsCountry.Location = New System.Drawing.Point(34, 535)
        Me.LbsCountry.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbsCountry.Name = "LbsCountry"
        Me.LbsCountry.Size = New System.Drawing.Size(64, 20)
        Me.LbsCountry.TabIndex = 6
        Me.LbsCountry.Text = "Country"
        '
        'EmpidTextBox
        '
        Me.EmpidTextBox.Location = New System.Drawing.Point(194, 89)
        Me.EmpidTextBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.EmpidTextBox.Name = "EmpidTextBox"
        Me.EmpidTextBox.Size = New System.Drawing.Size(148, 26)
        Me.EmpidTextBox.TabIndex = 7
        '
        'FnameTextBox
        '
        Me.FnameTextBox.Location = New System.Drawing.Point(194, 157)
        Me.FnameTextBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.FnameTextBox.Name = "FnameTextBox"
        Me.FnameTextBox.Size = New System.Drawing.Size(148, 26)
        Me.FnameTextBox.TabIndex = 8
        '
        'LnameTextBox
        '
        Me.LnameTextBox.Location = New System.Drawing.Point(194, 225)
        Me.LnameTextBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.LnameTextBox.Name = "LnameTextBox"
        Me.LnameTextBox.Size = New System.Drawing.Size(148, 26)
        Me.LnameTextBox.TabIndex = 9
        '
        'CityTextBox
        '
        Me.CityTextBox.Location = New System.Drawing.Point(194, 395)
        Me.CityTextBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.CityTextBox.Name = "CityTextBox"
        Me.CityTextBox.Size = New System.Drawing.Size(148, 26)
        Me.CityTextBox.TabIndex = 11
        '
        'StateTextbox
        '
        Me.StateTextbox.Location = New System.Drawing.Point(194, 463)
        Me.StateTextbox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.StateTextbox.Name = "StateTextbox"
        Me.StateTextbox.Size = New System.Drawing.Size(148, 26)
        Me.StateTextbox.TabIndex = 12
        '
        'CountryTextBox
        '
        Me.CountryTextBox.Location = New System.Drawing.Point(194, 531)
        Me.CountryTextBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.CountryTextBox.Name = "CountryTextBox"
        Me.CountryTextBox.Size = New System.Drawing.Size(148, 26)
        Me.CountryTextBox.TabIndex = 13
        '
        'AddressRichTextBox
        '
        Me.AddressRichTextBox.Location = New System.Drawing.Point(194, 292)
        Me.AddressRichTextBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.AddressRichTextBox.Name = "AddressRichTextBox"
        Me.AddressRichTextBox.Size = New System.Drawing.Size(148, 64)
        Me.AddressRichTextBox.TabIndex = 14
        Me.AddressRichTextBox.Text = ""
        '
        'LbsZipcode
        '
        Me.LbsZipcode.AutoSize = True
        Me.LbsZipcode.Location = New System.Drawing.Point(432, 94)
        Me.LbsZipcode.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbsZipcode.Name = "LbsZipcode"
        Me.LbsZipcode.Size = New System.Drawing.Size(66, 20)
        Me.LbsZipcode.TabIndex = 15
        Me.LbsZipcode.Text = "Zipcode"
        '
        'LbsContact
        '
        Me.LbsContact.AutoSize = True
        Me.LbsContact.Location = New System.Drawing.Point(432, 166)
        Me.LbsContact.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbsContact.Name = "LbsContact"
        Me.LbsContact.Size = New System.Drawing.Size(78, 20)
        Me.LbsContact.TabIndex = 16
        Me.LbsContact.Text = "Contact #"
        '
        'LbsEmailID
        '
        Me.LbsEmailID.AutoSize = True
        Me.LbsEmailID.Location = New System.Drawing.Point(432, 238)
        Me.LbsEmailID.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbsEmailID.Name = "LbsEmailID"
        Me.LbsEmailID.Size = New System.Drawing.Size(69, 20)
        Me.LbsEmailID.TabIndex = 17
        Me.LbsEmailID.Text = "Email ID"
        '
        'LbsUsername
        '
        Me.LbsUsername.AutoSize = True
        Me.LbsUsername.Location = New System.Drawing.Point(432, 311)
        Me.LbsUsername.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbsUsername.Name = "LbsUsername"
        Me.LbsUsername.Size = New System.Drawing.Size(83, 20)
        Me.LbsUsername.TabIndex = 18
        Me.LbsUsername.Text = "Username"
        '
        'LbsPassword
        '
        Me.LbsPassword.AutoSize = True
        Me.LbsPassword.Location = New System.Drawing.Point(432, 400)
        Me.LbsPassword.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbsPassword.Name = "LbsPassword"
        Me.LbsPassword.Size = New System.Drawing.Size(78, 20)
        Me.LbsPassword.TabIndex = 19
        Me.LbsPassword.Text = "Password"
        '
        'LbsEmployeetype
        '
        Me.LbsEmployeetype.AutoSize = True
        Me.LbsEmployeetype.Location = New System.Drawing.Point(432, 468)
        Me.LbsEmployeetype.Margin = New System.Windows.Forms.Padding(4, 0, 4, 0)
        Me.LbsEmployeetype.Name = "LbsEmployeetype"
        Me.LbsEmployeetype.Size = New System.Drawing.Size(117, 20)
        Me.LbsEmployeetype.TabIndex = 20
        Me.LbsEmployeetype.Text = "Employee Type"
        '
        'ZipcodeTextBox
        '
        Me.ZipcodeTextBox.Location = New System.Drawing.Point(584, 89)
        Me.ZipcodeTextBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ZipcodeTextBox.Name = "ZipcodeTextBox"
        Me.ZipcodeTextBox.Size = New System.Drawing.Size(148, 26)
        Me.ZipcodeTextBox.TabIndex = 21
        '
        'EmilIDTextBox
        '
        Me.EmilIDTextBox.Location = New System.Drawing.Point(584, 234)
        Me.EmilIDTextBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.EmilIDTextBox.Name = "EmilIDTextBox"
        Me.EmilIDTextBox.Size = New System.Drawing.Size(148, 26)
        Me.EmilIDTextBox.TabIndex = 22
        '
        'PasswordTextBox
        '
        Me.PasswordTextBox.Location = New System.Drawing.Point(584, 395)
        Me.PasswordTextBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.PasswordTextBox.Name = "PasswordTextBox"
        Me.PasswordTextBox.Size = New System.Drawing.Size(148, 26)
        Me.PasswordTextBox.TabIndex = 23
        '
        'UsernameTextBox
        '
        Me.UsernameTextBox.Location = New System.Drawing.Point(584, 306)
        Me.UsernameTextBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.UsernameTextBox.Name = "UsernameTextBox"
        Me.UsernameTextBox.Size = New System.Drawing.Size(148, 26)
        Me.UsernameTextBox.TabIndex = 24
        '
        'ContactTextBox
        '
        Me.ContactTextBox.Location = New System.Drawing.Point(584, 162)
        Me.ContactTextBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ContactTextBox.Name = "ContactTextBox"
        Me.ContactTextBox.Size = New System.Drawing.Size(148, 26)
        Me.ContactTextBox.TabIndex = 25
        '
        'EmployeetypeTextBox
        '
        Me.EmployeetypeTextBox.Location = New System.Drawing.Point(584, 463)
        Me.EmployeetypeTextBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.EmployeetypeTextBox.Name = "EmployeetypeTextBox"
        Me.EmployeetypeTextBox.Size = New System.Drawing.Size(148, 26)
        Me.EmployeetypeTextBox.TabIndex = 26
        '
        'SaveButton
        '
        Me.SaveButton.Location = New System.Drawing.Point(260, 645)
        Me.SaveButton.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.SaveButton.Name = "SaveButton"
        Me.SaveButton.Size = New System.Drawing.Size(112, 35)
        Me.SaveButton.TabIndex = 27
        Me.SaveButton.Text = "Save"
        Me.SaveButton.UseVisualStyleBackColor = True
        '
        'CancelButton
        '
        Me.CancelButton.Location = New System.Drawing.Point(454, 645)
        Me.CancelButton.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.CancelButton.Name = "CancelButton"
        Me.CancelButton.Size = New System.Drawing.Size(112, 35)
        Me.CancelButton.TabIndex = 28
        Me.CancelButton.Text = "Cancel"
        Me.CancelButton.UseVisualStyleBackColor = True
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(650, 645)
        Me.ClearButton.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(112, 35)
        Me.ClearButton.TabIndex = 29
        Me.ClearButton.Text = "Clear"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.EmpidTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsEmpID)
        Me.GroupBox1.Controls.Add(Me.LbsFname)
        Me.GroupBox1.Controls.Add(Me.LbsLname)
        Me.GroupBox1.Controls.Add(Me.EmployeetypeTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsAddress)
        Me.GroupBox1.Controls.Add(Me.ContactTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsCity)
        Me.GroupBox1.Controls.Add(Me.UsernameTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsState)
        Me.GroupBox1.Controls.Add(Me.PasswordTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsCountry)
        Me.GroupBox1.Controls.Add(Me.EmilIDTextBox)
        Me.GroupBox1.Controls.Add(Me.FnameTextBox)
        Me.GroupBox1.Controls.Add(Me.ZipcodeTextBox)
        Me.GroupBox1.Controls.Add(Me.LnameTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsEmployeetype)
        Me.GroupBox1.Controls.Add(Me.CityTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsPassword)
        Me.GroupBox1.Controls.Add(Me.StateTextbox)
        Me.GroupBox1.Controls.Add(Me.LbsUsername)
        Me.GroupBox1.Controls.Add(Me.CountryTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsEmailID)
        Me.GroupBox1.Controls.Add(Me.AddressRichTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsContact)
        Me.GroupBox1.Controls.Add(Me.LbsZipcode)
        Me.GroupBox1.Location = New System.Drawing.Point(66, 18)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.GroupBox1.Size = New System.Drawing.Size(842, 617)
        Me.GroupBox1.TabIndex = 30
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Customer Details"
        '
        'Employee
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1012, 743)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.ClearButton)
        Me.Controls.Add(Me.CancelButton)
        Me.Controls.Add(Me.SaveButton)
        Me.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.Name = "Employee"
        Me.Text = "Employee"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents LbsEmpID As System.Windows.Forms.Label
    Friend WithEvents LbsFname As System.Windows.Forms.Label
    Friend WithEvents LbsLname As System.Windows.Forms.Label
    Friend WithEvents LbsAddress As System.Windows.Forms.Label
    Friend WithEvents LbsCity As System.Windows.Forms.Label
    Friend WithEvents LbsState As System.Windows.Forms.Label
    Friend WithEvents LbsCountry As System.Windows.Forms.Label
    Friend WithEvents EmpidTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FnameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LnameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents CityTextBox As System.Windows.Forms.TextBox
    Friend WithEvents StateTextbox As System.Windows.Forms.TextBox
    Friend WithEvents CountryTextBox As System.Windows.Forms.TextBox
    Friend WithEvents AddressRichTextBox As System.Windows.Forms.RichTextBox
    Friend WithEvents LbsZipcode As System.Windows.Forms.Label
    Friend WithEvents LbsContact As System.Windows.Forms.Label
    Friend WithEvents LbsEmailID As System.Windows.Forms.Label
    Friend WithEvents LbsUsername As System.Windows.Forms.Label
    Friend WithEvents LbsPassword As System.Windows.Forms.Label
    Friend WithEvents LbsEmployeetype As System.Windows.Forms.Label
    Friend WithEvents ZipcodeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents EmilIDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents PasswordTextBox As System.Windows.Forms.TextBox
    Friend WithEvents UsernameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ContactTextBox As System.Windows.Forms.TextBox
    Friend WithEvents EmployeetypeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents SaveButton As System.Windows.Forms.Button
    Friend WithEvents CancelButton As System.Windows.Forms.Button
    Friend WithEvents ClearButton As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox

End Class
