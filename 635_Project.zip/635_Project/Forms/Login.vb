﻿Imports System.Data.OleDB
Public Class Login

    Private Sub frmLogin_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        End
    End Sub

    Private Sub frmLogin_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        SqlHelper.strConnect = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\Popoye.accdb;"
    End Sub

    Private Sub btnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLogin.Click
        If Len(Trim(txtUserName.Text)) = 0 Then
            MessageBox.Show("Please enter user name", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtUserName.Focus()
            Exit Sub
        End If
        If Len(Trim(txtPassword.Text)) = 0 Then
            MessageBox.Show("Please enter password", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtPassword.Focus()
            Exit Sub
        End If
        Try
            Dim myConnection As OleDbConnection
            myConnection = New OleDbConnection("Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\Popoye.accdb")
            Dim myCommand As OleDbCommand
            myCommand = New OleDbCommand("SELECT UserID,UserName,Password FROM Login WHERE UserName = @pusername AND Password = @puserpassword", myConnection)
            Dim uName As New OleDbParameter("@pusername", SqlDbType.VarChar)
            Dim uPassword As New OleDbParameter("@puserpassword", SqlDbType.VarChar)
            uName.Value = txtUserName.Text
            uPassword.Value = txtPassword.Text
            myCommand.Parameters.Add(uName)
            myCommand.Parameters.Add(uPassword)
            myCommand.Connection.Open()

            Dim myReader As OleDbDataReader = myCommand.ExecuteReader(CommandBehavior.CloseConnection)
            Dim Login As Object = 0
            If myReader.HasRows Then
                myReader.Read()
                Login = myReader(Login)
                SqlHelper.EmployeeID = Convert.ToInt32(myReader("UserID"))
                SqlHelper.EmployeeName = myReader("UserName")
            End If

            If Login = Nothing Then
                MsgBox("Login is Failed...Try again !", MsgBoxStyle.Critical, "Login Denied")
                txtUserName.Clear()
                txtPassword.Clear()
                txtUserName.Focus()

            Else

                ProgressBar1.Visible = True
                ProgressBar1.Maximum = 5000
                ProgressBar1.Minimum = 0
                ProgressBar1.Value = 4
                ProgressBar1.Step = 1

                For i = 0 To 5000
                    ProgressBar1.PerformStep()
                Next

                MainForm.ToolStripStatusLabel2.Text = txtUserName.Text
                Me.Hide()
                txtUserName.Clear()
                txtPassword.Clear()
                txtUserName.Focus()
                MainForm.Show()
            End If
            myCommand.Dispose()
            myConnection.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnCancel_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCancel.Click
        End
    End Sub

End Class
