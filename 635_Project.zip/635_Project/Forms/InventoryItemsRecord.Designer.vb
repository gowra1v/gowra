﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class InventoryItemsRecord
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(InventoryItemsRecord))
        Me.Button3 = New System.Windows.Forms.Button()
        Me.Button2 = New System.Windows.Forms.Button()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.dgvInventoryDetails = New System.Windows.Forms.DataGridView()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.txtInventoryName = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnInventoryExport = New System.Windows.Forms.Button()
        Me.btnResetInventory = New System.Windows.Forms.Button()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.cmbInventoryName = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.btnExportAll = New System.Windows.Forms.Button()
        Me.btnGetAll = New System.Windows.Forms.Button()
        Me.dgvInventoryData = New System.Windows.Forms.DataGridView()
        Me.btnResetAll = New System.Windows.Forms.Button()
        Me.InventoryTabControl = New System.Windows.Forms.TabControl()
        Me.TabPage2.SuspendLayout()
        CType(Me.dgvInventoryDetails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.dgvInventoryData, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.InventoryTabControl.SuspendLayout()
        Me.SuspendLayout()
        '
        'Button3
        '
        Me.Button3.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button3.Location = New System.Drawing.Point(118, 26)
        Me.Button3.Name = "Button3"
        Me.Button3.Size = New System.Drawing.Size(94, 40)
        Me.Button3.TabIndex = 1
        Me.Button3.Text = "&Reset"
        Me.Button3.UseVisualStyleBackColor = True
        '
        'Button2
        '
        Me.Button2.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button2.Location = New System.Drawing.Point(18, 26)
        Me.Button2.Name = "Button2"
        Me.Button2.Size = New System.Drawing.Size(94, 40)
        Me.Button2.TabIndex = 0
        Me.Button2.Text = "&Get Data"
        Me.Button2.UseVisualStyleBackColor = True
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(218, 26)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(94, 40)
        Me.Button1.TabIndex = 2
        Me.Button1.Text = "&Export Excel"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.dgvInventoryDetails)
        Me.TabPage2.Controls.Add(Me.GroupBox10)
        Me.TabPage2.Controls.Add(Me.GroupBox3)
        Me.TabPage2.Controls.Add(Me.GroupBox4)
        Me.TabPage2.Location = New System.Drawing.Point(4, 26)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TabPage2.Size = New System.Drawing.Size(833, 579)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "By Inventory Item Name"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'dgvInventoryDetails
        '
        Me.dgvInventoryDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvInventoryDetails.Location = New System.Drawing.Point(8, 97)
        Me.dgvInventoryDetails.MultiSelect = False
        Me.dgvInventoryDetails.Name = "dgvInventoryDetails"
        Me.dgvInventoryDetails.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.dgvInventoryDetails.Size = New System.Drawing.Size(828, 475)
        Me.dgvInventoryDetails.TabIndex = 35
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.txtInventoryName)
        Me.GroupBox10.Controls.Add(Me.Label6)
        Me.GroupBox10.Location = New System.Drawing.Point(314, 6)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(278, 87)
        Me.GroupBox10.TabIndex = 34
        Me.GroupBox10.TabStop = False
        '
        'txtInventoryName
        '
        Me.txtInventoryName.Location = New System.Drawing.Point(24, 45)
        Me.txtInventoryName.Name = "txtInventoryName"
        Me.txtInventoryName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtInventoryName.Size = New System.Drawing.Size(231, 24)
        Me.txtInventoryName.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(21, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(107, 18)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Search by Name"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnInventoryExport)
        Me.GroupBox3.Controls.Add(Me.btnResetInventory)
        Me.GroupBox3.Location = New System.Drawing.Point(600, 6)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(224, 87)
        Me.GroupBox3.TabIndex = 33
        Me.GroupBox3.TabStop = False
        '
        'btnInventoryExport
        '
        Me.btnInventoryExport.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInventoryExport.Location = New System.Drawing.Point(116, 26)
        Me.btnInventoryExport.Name = "btnInventoryExport"
        Me.btnInventoryExport.Size = New System.Drawing.Size(94, 40)
        Me.btnInventoryExport.TabIndex = 2
        Me.btnInventoryExport.Text = "&Export Excel"
        Me.btnInventoryExport.UseVisualStyleBackColor = True
        '
        'btnResetInventory
        '
        Me.btnResetInventory.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnResetInventory.Location = New System.Drawing.Point(16, 26)
        Me.btnResetInventory.Name = "btnResetInventory"
        Me.btnResetInventory.Size = New System.Drawing.Size(94, 40)
        Me.btnResetInventory.TabIndex = 1
        Me.btnResetInventory.Text = "&Reset"
        Me.btnResetInventory.UseVisualStyleBackColor = True
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.cmbInventoryName)
        Me.GroupBox4.Controls.Add(Me.Label1)
        Me.GroupBox4.Location = New System.Drawing.Point(8, 6)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(300, 87)
        Me.GroupBox4.TabIndex = 32
        Me.GroupBox4.TabStop = False
        '
        'cmbInventoryName
        '
        Me.cmbInventoryName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cmbInventoryName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbInventoryName.FormattingEnabled = True
        Me.cmbInventoryName.Location = New System.Drawing.Point(24, 45)
        Me.cmbInventoryName.Name = "cmbInventoryName"
        Me.cmbInventoryName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbInventoryName.Size = New System.Drawing.Size(248, 25)
        Me.cmbInventoryName.TabIndex = 25
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Palatino Linotype", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(20, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(126, 21)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Inventory Name"
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.btnExportAll)
        Me.TabPage1.Controls.Add(Me.btnGetAll)
        Me.TabPage1.Controls.Add(Me.dgvInventoryData)
        Me.TabPage1.Controls.Add(Me.btnResetAll)
        Me.TabPage1.Location = New System.Drawing.Point(4, 26)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(833, 579)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "All Data"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'btnExportAll
        '
        Me.btnExportAll.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExportAll.Location = New System.Drawing.Point(235, 26)
        Me.btnExportAll.Name = "btnExportAll"
        Me.btnExportAll.Size = New System.Drawing.Size(94, 40)
        Me.btnExportAll.TabIndex = 2
        Me.btnExportAll.Text = "&Export Excel"
        Me.btnExportAll.UseVisualStyleBackColor = True
        '
        'btnGetAll
        '
        Me.btnGetAll.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGetAll.Location = New System.Drawing.Point(17, 26)
        Me.btnGetAll.Name = "btnGetAll"
        Me.btnGetAll.Size = New System.Drawing.Size(94, 40)
        Me.btnGetAll.TabIndex = 0
        Me.btnGetAll.Text = "&Get Data"
        Me.btnGetAll.UseVisualStyleBackColor = True
        '
        'dgvInventoryData
        '
        Me.dgvInventoryData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvInventoryData.Location = New System.Drawing.Point(8, 94)
        Me.dgvInventoryData.MultiSelect = False
        Me.dgvInventoryData.Name = "dgvInventoryData"
        Me.dgvInventoryData.Size = New System.Drawing.Size(822, 475)
        Me.dgvInventoryData.TabIndex = 32
        '
        'btnResetAll
        '
        Me.btnResetAll.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnResetAll.Location = New System.Drawing.Point(126, 26)
        Me.btnResetAll.Name = "btnResetAll"
        Me.btnResetAll.Size = New System.Drawing.Size(94, 40)
        Me.btnResetAll.TabIndex = 1
        Me.btnResetAll.Text = "&Reset"
        Me.btnResetAll.UseVisualStyleBackColor = True
        '
        'InventoryTabControl
        '
        Me.InventoryTabControl.Controls.Add(Me.TabPage1)
        Me.InventoryTabControl.Controls.Add(Me.TabPage2)
        Me.InventoryTabControl.Location = New System.Drawing.Point(0, 0)
        Me.InventoryTabControl.Name = "InventoryTabControl"
        Me.InventoryTabControl.SelectedIndex = 0
        Me.InventoryTabControl.Size = New System.Drawing.Size(841, 609)
        Me.InventoryTabControl.TabIndex = 0
        '
        'InventoryItemsRecord
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(837, 609)
        Me.Controls.Add(Me.InventoryTabControl)
        Me.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "InventoryItemsRecord"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Inventory Details"
        Me.TabPage2.ResumeLayout(False)
        CType(Me.dgvInventoryDetails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.TabPage1.ResumeLayout(False)
        CType(Me.dgvInventoryData, System.ComponentModel.ISupportInitialize).EndInit()
        Me.InventoryTabControl.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Button3 As System.Windows.Forms.Button
    Friend WithEvents Button2 As System.Windows.Forms.Button
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents dgvInventoryDetails As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents txtInventoryName As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents btnInventoryExport As System.Windows.Forms.Button
    Friend WithEvents btnResetInventory As System.Windows.Forms.Button
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbInventoryName As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents btnExportAll As System.Windows.Forms.Button
    Friend WithEvents btnGetAll As System.Windows.Forms.Button
    Friend WithEvents dgvInventoryData As System.Windows.Forms.DataGridView
    Friend WithEvents btnResetAll As System.Windows.Forms.Button
    Friend WithEvents InventoryTabControl As System.Windows.Forms.TabControl
End Class
