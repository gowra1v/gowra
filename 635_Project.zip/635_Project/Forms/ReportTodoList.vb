﻿Public Class ReportTodoList
    Dim sql As SqlHelper

    Public Function SelectPromotionDetailsForReport(Enabled As String)
        sql = New SqlHelper()
        Dim selectStr As String
        selectStr = "SELECT * FROM Promotions"

        If Enabled = "Active" Then
            selectStr += " WHERE Active = True"
        End If
        If Enabled = "InActive" Then
            selectStr += " WHERE Active = False"
        End If

        Dim dt As DataTable = sql.ExecuteSelectTable(selectStr)

        If dt.Rows.Count = 0 Then
            MessageBox.Show("Promotion details Not found for search criteria" & vbNewLine & "So we will be displaying full list of promotions", "Promotion not found", MessageBoxButtons.OK, MessageBoxIcon.Information)
            dt = sql.ExecuteSelectTable("SELECT * FROM Promotions")
        End If
        Return dt
    End Function

    Public Function SelectPromotionsForReport() As DataTable
        sql = New SqlHelper()
        Dim selectStr As String
        selectStr = "SELECT * FROM Promotions"


        Dim dt As DataTable = sql.ExecuteSelectTable(selectStr)

        If dt.Rows.Count = 0 Then
            MessageBox.Show("Promotion details Not found for search criteria" & vbNewLine & "So we will be displaying full list of promotions", "Promotion not found", MessageBoxButtons.OK, MessageBoxIcon.Information)
            dt = sql.ExecuteSelectTable("SELECT * FROM Promotions")
        End If
        Return dt
    End Function

    Public Function SelectInventoryDetailsForReport(Optional ByVal Enabled As Integer = 0) As DataTable
        sql = New SqlHelper()
        Dim selectStr As String
        Dim selWhere As String = ""
        selectStr = "SELECT InventoryID, InventoryName, AvailableQty, ReorderPoint, (AvailableQty - ReorderPoint), UnitPrice FROM InventoryItems"

        If Enabled > 0 Then
            selWhere += " WHERE InventoryID = " & Enabled
            selectStr += selWhere
        End If

        

        Dim dt As DataTable = sql.ExecuteSelectTable(selectStr)

        If dt.Rows.Count = 0 Then
            MessageBox.Show("Inventory details Not found for search criteria" & vbNewLine & "So we will be displaying full list of Inventory Items", "Inventory Item not found", MessageBoxButtons.OK, MessageBoxIcon.Information)
            dt = sql.ExecuteSelectTable("SELECT InventoryID, InventoryName, AvailableQty, ReorderPoint, (AvailableQty - ReorderPoint), UnitPrice FROM InventoryItems")
        End If
        Return dt
    End Function


    Public Function SelectInventoryDetailsReport(Optional ByVal Enabled As Integer = 0, Optional ByVal InInventoryName As String = "") As DataTable
        sql = New SqlHelper()
        Dim selectStr As String
        Dim selWhere As String = ""
        selectStr = "SELECT InventoryID, InventoryName, AvailableQty, ReorderPoint, (AvailableQty - ReorderPoint), UnitPrice FROM InventoryItems"

        Dim dt As DataTable = sql.ExecuteSelectTable(selectStr)

        If dt.Rows.Count = 0 Then
            MessageBox.Show("Inventory details Not found for search criteria" & vbNewLine & "So we will be displaying full list of Inventory Items", "Inventory Item not found", MessageBoxButtons.OK, MessageBoxIcon.Information)
            dt = sql.ExecuteSelectTable("SELECT InventoryID, InventoryName, AvailableQty, ReorderPoint, (AvailableQty - ReorderPoint), UnitPrice FROM InventoryItems")
        End If
        Return dt
    End Function

    Public Function SelectSalesForReport() As DataTable
        sql = New SqlHelper()
        Dim selectStr As String
        selectStr = "SELECT OrderID, Format(OrderDate, ""mm/dd/yyyy"") AS OrderDate, OrderAmount FROM Orders order by OrderDate"


        Dim dt As DataTable = sql.ExecuteSelectTable(selectStr)

        If dt.Rows.Count = 0 Then
            MessageBox.Show("Promotion details Not found for search criteria" & vbNewLine & "So we will be displaying full list of promotions", "Promotion not found", MessageBoxButtons.OK, MessageBoxIcon.Information)
            dt = sql.ExecuteSelectTable("SELECT OrderID, OrderDate, OrderAmount FROM Orders order by OrderDate")
        End If
        Return dt
    End Function

End Class
