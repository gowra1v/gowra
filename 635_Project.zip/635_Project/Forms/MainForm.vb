﻿Imports System.Data.OleDb
Imports System.IO
Public Class MainForm
    Dim sSql As String
    Dim rdr As OleDbDataReader = Nothing
    Dim con As OleDbConnection = Nothing
    Dim cmd As OleDbCommand = Nothing


    Private Sub CalculatorToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles CalculatorToolStripMenuItem.Click
        Try
            System.Diagnostics.Process.Start("Calc.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub NotepadToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles NotepadToolStripMenuItem.Click
        Try
            System.Diagnostics.Process.Start("Notepad.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub TaskManagerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TaskManagerToolStripMenuItem.Click
        Try
            System.Diagnostics.Process.Start("TaskMgr.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub MSWordToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MSWordToolStripMenuItem.Click
        Try
            System.Diagnostics.Process.Start("Winword.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    
    Private Sub MainForm_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("You cannot close application, Please click on Logout button to logout from system?", "Click on logout button?", MessageBoxButtons.OKCancel, MessageBoxIcon.Information) = Windows.Forms.DialogResult.OK Then
            e.Cancel = True
        Else
            e.Cancel = True
        End If
    End Sub
   
    Private Sub MainForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        ToolStripStatusLabel4.Text = Now

        ToolStripStatusLabel2.Text = SqlHelper.EmployeeName
        Me.Refresh()
        Button1.PerformClick()
        Timer2.Start()
        Timer2.Interval = 1000

    End Sub

    Private Sub Timer1_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer1.Tick
        Timer1.Start()
        ToolStripStatusLabel4.Text = Now
    End Sub

    Private Sub WordpadToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles WordpadToolStripMenuItem.Click
        Try
            System.Diagnostics.Process.Start("Wordpad.exe")
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub Timer2_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Timer2.Tick
        Button1.PerformClick()

    End Sub

    Private Sub CreateOrderToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CreateOrderToolStripMenuItem.Click
        Me.Hide()
        OrderDetails.Show()
    End Sub

    Private Sub OrderToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs)
        Me.Hide()
        OrderDetails.Show()
    End Sub

    Private Sub InventoryToolStripMenu_Click(sender As System.Object, e As System.EventArgs)
        Me.Hide()
        OrderDetails.Show()
    End Sub

    Private Sub RegistrationToolStripMenuItem1_Click(sender As System.Object, e As System.EventArgs)
        Me.Hide()
        CreateNewEmployee.Show()
    End Sub

    Private Sub RegistrationToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs)
        Me.Hide()
        CreateNewEmployee.Show()
    End Sub

    Private Sub CategoryToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs)
        Me.Hide()
        InventoryCategory.Show()
    End Sub



    Private Sub MapMenuItemsToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles MapMenuItemsToolStripMenuItem.Click
        Me.Hide()
        InventoryCategory.Show()
    End Sub

    Private Sub RegistrationToolStripMenuItem2_Click(sender As System.Object, e As System.EventArgs) Handles RegistrationToolStripMenuItem2.Click
        Me.Hide()
        PromotionReport.Show()
    End Sub

    Private Sub NewMenuItemToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles NewMenuItemToolStripMenuItem.Click
        Me.Hide()
        MenuItems.Show()
    End Sub

    Private Sub InventoryToolStripMenuItem1_Click(sender As System.Object, e As System.EventArgs) Handles InventoryToolStripMenuItem1.Click
        Me.Hide()
        InventoryReport.Show()
    End Sub

    Private Sub ProductMasterEntryToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles ProductMasterEntryToolStripMenuItem.Click
        Me.Hide()
        InventoryItems.Show()
    End Sub

    Private Sub pbInventoryItem_Click(sender As System.Object, e As System.EventArgs) Handles pbInventoryItem.Click
        Me.Hide()
        InventoryItems.Show()
    End Sub

    Private Sub btnLogout_Click(sender As System.Object, e As System.EventArgs) Handles btnLogout.Click
        If MessageBox.Show("Click on Ok button to logout ?", "Are you sure to LogOut?", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = Windows.Forms.DialogResult.OK Then
            Me.Hide()
            Login.Show()
            Login.txtUserName.Text = ""
            Login.txtPassword.Text = ""
            Login.txtUserName.Focus()
            Login.ProgressBar1.Visible = False
        End If
    End Sub

    Private Sub pbOrderForm_Click(sender As System.Object, e As System.EventArgs) Handles pbOrderForm.Click
        Me.Hide()
        OrderDetails.Show()
    End Sub

    Private Sub SalesReportToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SalesReportToolStripMenuItem.Click
        Me.Hide()
        SalesReport.Show()
    End Sub

    Private Sub SendEmailToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles SendEmailToolStripMenuItem.Click
        Me.Hide()
        SendPromotions.Show()
    End Sub

    Private Sub CreatePromotionToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles CreatePromotionToolStripMenuItem.Click
        Me.Hide()
        DiscountsOffer.Show()
    End Sub

    Private Sub UpdateOrderToolStripMenuItem_Click(sender As System.Object, e As System.EventArgs) Handles UpdateOrderToolStripMenuItem.Click
        Me.Hide()
        EditOrderDetails.Show()
    End Sub
End Class