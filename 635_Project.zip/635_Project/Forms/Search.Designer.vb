﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Search
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.EmpidTextBox = New System.Windows.Forms.TextBox()
        Me.LbsEmpID = New System.Windows.Forms.Label()
        Me.LbsFname = New System.Windows.Forms.Label()
        Me.LbsLname = New System.Windows.Forms.Label()
        Me.EmployeetypeTextBox = New System.Windows.Forms.TextBox()
        Me.LbsAddress = New System.Windows.Forms.Label()
        Me.ContactTextBox = New System.Windows.Forms.TextBox()
        Me.LbsCity = New System.Windows.Forms.Label()
        Me.UsernameTextBox = New System.Windows.Forms.TextBox()
        Me.LbsState = New System.Windows.Forms.Label()
        Me.PasswordTextBox = New System.Windows.Forms.TextBox()
        Me.LbsCountry = New System.Windows.Forms.Label()
        Me.EmilIDTextBox = New System.Windows.Forms.TextBox()
        Me.FnameTextBox = New System.Windows.Forms.TextBox()
        Me.ZipcodeTextBox = New System.Windows.Forms.TextBox()
        Me.LnameTextBox = New System.Windows.Forms.TextBox()
        Me.LbsEmployeetype = New System.Windows.Forms.Label()
        Me.CityTextBox = New System.Windows.Forms.TextBox()
        Me.LbsPassword = New System.Windows.Forms.Label()
        Me.StateTextbox = New System.Windows.Forms.TextBox()
        Me.LbsUsername = New System.Windows.Forms.Label()
        Me.CountryTextBox = New System.Windows.Forms.TextBox()
        Me.LbsEmailID = New System.Windows.Forms.Label()
        Me.AddressRichTextBox = New System.Windows.Forms.RichTextBox()
        Me.LbsContact = New System.Windows.Forms.Label()
        Me.LbsZipcode = New System.Windows.Forms.Label()
        Me.ClearButton = New System.Windows.Forms.Button()
        Me.CancelButton = New System.Windows.Forms.Button()
        Me.UpdateButton = New System.Windows.Forms.Button()
        Me.SearchButton = New System.Windows.Forms.Button()
        Me.EditButton = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.EditButton)
        Me.GroupBox1.Controls.Add(Me.SearchButton)
        Me.GroupBox1.Controls.Add(Me.EmpidTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsEmpID)
        Me.GroupBox1.Controls.Add(Me.LbsFname)
        Me.GroupBox1.Controls.Add(Me.LbsLname)
        Me.GroupBox1.Controls.Add(Me.EmployeetypeTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsAddress)
        Me.GroupBox1.Controls.Add(Me.ContactTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsCity)
        Me.GroupBox1.Controls.Add(Me.UsernameTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsState)
        Me.GroupBox1.Controls.Add(Me.PasswordTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsCountry)
        Me.GroupBox1.Controls.Add(Me.EmilIDTextBox)
        Me.GroupBox1.Controls.Add(Me.FnameTextBox)
        Me.GroupBox1.Controls.Add(Me.ZipcodeTextBox)
        Me.GroupBox1.Controls.Add(Me.LnameTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsEmployeetype)
        Me.GroupBox1.Controls.Add(Me.CityTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsPassword)
        Me.GroupBox1.Controls.Add(Me.StateTextbox)
        Me.GroupBox1.Controls.Add(Me.LbsUsername)
        Me.GroupBox1.Controls.Add(Me.CountryTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsEmailID)
        Me.GroupBox1.Controls.Add(Me.AddressRichTextBox)
        Me.GroupBox1.Controls.Add(Me.LbsContact)
        Me.GroupBox1.Controls.Add(Me.LbsZipcode)
        Me.GroupBox1.Location = New System.Drawing.Point(56, 20)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(561, 401)
        Me.GroupBox1.TabIndex = 31
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Update Employee Details"
        '
        'EmpidTextBox
        '
        Me.EmpidTextBox.Location = New System.Drawing.Point(129, 58)
        Me.EmpidTextBox.Name = "EmpidTextBox"
        Me.EmpidTextBox.Size = New System.Drawing.Size(100, 20)
        Me.EmpidTextBox.TabIndex = 7
        '
        'LbsEmpID
        '
        Me.LbsEmpID.AutoSize = True
        Me.LbsEmpID.Location = New System.Drawing.Point(23, 61)
        Me.LbsEmpID.Name = "LbsEmpID"
        Me.LbsEmpID.Size = New System.Drawing.Size(42, 13)
        Me.LbsEmpID.TabIndex = 0
        Me.LbsEmpID.Text = "Emp ID"
        '
        'LbsFname
        '
        Me.LbsFname.AutoSize = True
        Me.LbsFname.Location = New System.Drawing.Point(23, 108)
        Me.LbsFname.Name = "LbsFname"
        Me.LbsFname.Size = New System.Drawing.Size(39, 13)
        Me.LbsFname.TabIndex = 1
        Me.LbsFname.Text = "Fname"
        '
        'LbsLname
        '
        Me.LbsLname.AutoSize = True
        Me.LbsLname.Location = New System.Drawing.Point(23, 155)
        Me.LbsLname.Name = "LbsLname"
        Me.LbsLname.Size = New System.Drawing.Size(39, 13)
        Me.LbsLname.TabIndex = 2
        Me.LbsLname.Text = "Lname"
        '
        'EmployeetypeTextBox
        '
        Me.EmployeetypeTextBox.Location = New System.Drawing.Point(389, 348)
        Me.EmployeetypeTextBox.Name = "EmployeetypeTextBox"
        Me.EmployeetypeTextBox.Size = New System.Drawing.Size(100, 20)
        Me.EmployeetypeTextBox.TabIndex = 26
        '
        'LbsAddress
        '
        Me.LbsAddress.AutoSize = True
        Me.LbsAddress.Location = New System.Drawing.Point(23, 202)
        Me.LbsAddress.Name = "LbsAddress"
        Me.LbsAddress.Size = New System.Drawing.Size(45, 13)
        Me.LbsAddress.TabIndex = 3
        Me.LbsAddress.Text = "Address"
        '
        'ContactTextBox
        '
        Me.ContactTextBox.Location = New System.Drawing.Point(389, 152)
        Me.ContactTextBox.Name = "ContactTextBox"
        Me.ContactTextBox.Size = New System.Drawing.Size(100, 20)
        Me.ContactTextBox.TabIndex = 25
        '
        'LbsCity
        '
        Me.LbsCity.AutoSize = True
        Me.LbsCity.Location = New System.Drawing.Point(23, 260)
        Me.LbsCity.Name = "LbsCity"
        Me.LbsCity.Size = New System.Drawing.Size(24, 13)
        Me.LbsCity.TabIndex = 4
        Me.LbsCity.Text = "City"
        '
        'UsernameTextBox
        '
        Me.UsernameTextBox.Location = New System.Drawing.Point(389, 246)
        Me.UsernameTextBox.Name = "UsernameTextBox"
        Me.UsernameTextBox.Size = New System.Drawing.Size(100, 20)
        Me.UsernameTextBox.TabIndex = 24
        '
        'LbsState
        '
        Me.LbsState.AutoSize = True
        Me.LbsState.Location = New System.Drawing.Point(23, 304)
        Me.LbsState.Name = "LbsState"
        Me.LbsState.Size = New System.Drawing.Size(32, 13)
        Me.LbsState.TabIndex = 5
        Me.LbsState.Text = "State"
        '
        'PasswordTextBox
        '
        Me.PasswordTextBox.Location = New System.Drawing.Point(389, 304)
        Me.PasswordTextBox.Name = "PasswordTextBox"
        Me.PasswordTextBox.Size = New System.Drawing.Size(100, 20)
        Me.PasswordTextBox.TabIndex = 23
        '
        'LbsCountry
        '
        Me.LbsCountry.AutoSize = True
        Me.LbsCountry.Location = New System.Drawing.Point(23, 348)
        Me.LbsCountry.Name = "LbsCountry"
        Me.LbsCountry.Size = New System.Drawing.Size(43, 13)
        Me.LbsCountry.TabIndex = 6
        Me.LbsCountry.Text = "Country"
        '
        'EmilIDTextBox
        '
        Me.EmilIDTextBox.Location = New System.Drawing.Point(389, 199)
        Me.EmilIDTextBox.Name = "EmilIDTextBox"
        Me.EmilIDTextBox.Size = New System.Drawing.Size(100, 20)
        Me.EmilIDTextBox.TabIndex = 22
        '
        'FnameTextBox
        '
        Me.FnameTextBox.Location = New System.Drawing.Point(129, 102)
        Me.FnameTextBox.Name = "FnameTextBox"
        Me.FnameTextBox.Size = New System.Drawing.Size(100, 20)
        Me.FnameTextBox.TabIndex = 8
        '
        'ZipcodeTextBox
        '
        Me.ZipcodeTextBox.Location = New System.Drawing.Point(389, 105)
        Me.ZipcodeTextBox.Name = "ZipcodeTextBox"
        Me.ZipcodeTextBox.Size = New System.Drawing.Size(100, 20)
        Me.ZipcodeTextBox.TabIndex = 21
        '
        'LnameTextBox
        '
        Me.LnameTextBox.Location = New System.Drawing.Point(129, 146)
        Me.LnameTextBox.Name = "LnameTextBox"
        Me.LnameTextBox.Size = New System.Drawing.Size(100, 20)
        Me.LnameTextBox.TabIndex = 9
        '
        'LbsEmployeetype
        '
        Me.LbsEmployeetype.AutoSize = True
        Me.LbsEmployeetype.Location = New System.Drawing.Point(288, 351)
        Me.LbsEmployeetype.Name = "LbsEmployeetype"
        Me.LbsEmployeetype.Size = New System.Drawing.Size(80, 13)
        Me.LbsEmployeetype.TabIndex = 20
        Me.LbsEmployeetype.Text = "Employee Type"
        '
        'CityTextBox
        '
        Me.CityTextBox.Location = New System.Drawing.Point(129, 257)
        Me.CityTextBox.Name = "CityTextBox"
        Me.CityTextBox.Size = New System.Drawing.Size(100, 20)
        Me.CityTextBox.TabIndex = 11
        '
        'LbsPassword
        '
        Me.LbsPassword.AutoSize = True
        Me.LbsPassword.Location = New System.Drawing.Point(288, 307)
        Me.LbsPassword.Name = "LbsPassword"
        Me.LbsPassword.Size = New System.Drawing.Size(53, 13)
        Me.LbsPassword.TabIndex = 19
        Me.LbsPassword.Text = "Password"
        '
        'StateTextbox
        '
        Me.StateTextbox.Location = New System.Drawing.Point(129, 301)
        Me.StateTextbox.Name = "StateTextbox"
        Me.StateTextbox.Size = New System.Drawing.Size(100, 20)
        Me.StateTextbox.TabIndex = 12
        '
        'LbsUsername
        '
        Me.LbsUsername.AutoSize = True
        Me.LbsUsername.Location = New System.Drawing.Point(288, 249)
        Me.LbsUsername.Name = "LbsUsername"
        Me.LbsUsername.Size = New System.Drawing.Size(55, 13)
        Me.LbsUsername.TabIndex = 18
        Me.LbsUsername.Text = "Username"
        '
        'CountryTextBox
        '
        Me.CountryTextBox.Location = New System.Drawing.Point(129, 345)
        Me.CountryTextBox.Name = "CountryTextBox"
        Me.CountryTextBox.Size = New System.Drawing.Size(100, 20)
        Me.CountryTextBox.TabIndex = 13
        '
        'LbsEmailID
        '
        Me.LbsEmailID.AutoSize = True
        Me.LbsEmailID.Location = New System.Drawing.Point(288, 202)
        Me.LbsEmailID.Name = "LbsEmailID"
        Me.LbsEmailID.Size = New System.Drawing.Size(46, 13)
        Me.LbsEmailID.TabIndex = 17
        Me.LbsEmailID.Text = "Email ID"
        '
        'AddressRichTextBox
        '
        Me.AddressRichTextBox.Location = New System.Drawing.Point(129, 190)
        Me.AddressRichTextBox.Name = "AddressRichTextBox"
        Me.AddressRichTextBox.Size = New System.Drawing.Size(100, 43)
        Me.AddressRichTextBox.TabIndex = 14
        Me.AddressRichTextBox.Text = ""
        '
        'LbsContact
        '
        Me.LbsContact.AutoSize = True
        Me.LbsContact.Location = New System.Drawing.Point(288, 155)
        Me.LbsContact.Name = "LbsContact"
        Me.LbsContact.Size = New System.Drawing.Size(54, 13)
        Me.LbsContact.TabIndex = 16
        Me.LbsContact.Text = "Contact #"
        '
        'LbsZipcode
        '
        Me.LbsZipcode.AutoSize = True
        Me.LbsZipcode.Location = New System.Drawing.Point(288, 108)
        Me.LbsZipcode.Name = "LbsZipcode"
        Me.LbsZipcode.Size = New System.Drawing.Size(46, 13)
        Me.LbsZipcode.TabIndex = 15
        Me.LbsZipcode.Text = "Zipcode"
        '
        'ClearButton
        '
        Me.ClearButton.Location = New System.Drawing.Point(413, 441)
        Me.ClearButton.Name = "ClearButton"
        Me.ClearButton.Size = New System.Drawing.Size(75, 23)
        Me.ClearButton.TabIndex = 34
        Me.ClearButton.Text = "Clear"
        Me.ClearButton.UseVisualStyleBackColor = True
        '
        'CancelButton
        '
        Me.CancelButton.Location = New System.Drawing.Point(283, 441)
        Me.CancelButton.Name = "CancelButton"
        Me.CancelButton.Size = New System.Drawing.Size(75, 23)
        Me.CancelButton.TabIndex = 33
        Me.CancelButton.Text = "Cancel"
        Me.CancelButton.UseVisualStyleBackColor = True
        '
        'UpdateButton
        '
        Me.UpdateButton.Location = New System.Drawing.Point(153, 441)
        Me.UpdateButton.Name = "UpdateButton"
        Me.UpdateButton.Size = New System.Drawing.Size(75, 23)
        Me.UpdateButton.TabIndex = 32
        Me.UpdateButton.Text = "Update"
        Me.UpdateButton.UseVisualStyleBackColor = True
        '
        'SearchButton
        '
        Me.SearchButton.Location = New System.Drawing.Point(291, 54)
        Me.SearchButton.Name = "SearchButton"
        Me.SearchButton.Size = New System.Drawing.Size(75, 23)
        Me.SearchButton.TabIndex = 27
        Me.SearchButton.Text = "Search"
        Me.SearchButton.UseVisualStyleBackColor = True
        '
        'EditButton
        '
        Me.EditButton.Location = New System.Drawing.Point(399, 54)
        Me.EditButton.Name = "EditButton"
        Me.EditButton.Size = New System.Drawing.Size(75, 23)
        Me.EditButton.TabIndex = 28
        Me.EditButton.Text = "Edit"
        Me.EditButton.UseVisualStyleBackColor = True
        '
        'Search
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(672, 476)
        Me.Controls.Add(Me.ClearButton)
        Me.Controls.Add(Me.CancelButton)
        Me.Controls.Add(Me.UpdateButton)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "Search"
        Me.Text = "Search"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents EmpidTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LbsEmpID As System.Windows.Forms.Label
    Friend WithEvents LbsFname As System.Windows.Forms.Label
    Friend WithEvents LbsLname As System.Windows.Forms.Label
    Friend WithEvents EmployeetypeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LbsAddress As System.Windows.Forms.Label
    Friend WithEvents ContactTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LbsCity As System.Windows.Forms.Label
    Friend WithEvents UsernameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LbsState As System.Windows.Forms.Label
    Friend WithEvents PasswordTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LbsCountry As System.Windows.Forms.Label
    Friend WithEvents EmilIDTextBox As System.Windows.Forms.TextBox
    Friend WithEvents FnameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents ZipcodeTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LnameTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LbsEmployeetype As System.Windows.Forms.Label
    Friend WithEvents CityTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LbsPassword As System.Windows.Forms.Label
    Friend WithEvents StateTextbox As System.Windows.Forms.TextBox
    Friend WithEvents LbsUsername As System.Windows.Forms.Label
    Friend WithEvents CountryTextBox As System.Windows.Forms.TextBox
    Friend WithEvents LbsEmailID As System.Windows.Forms.Label
    Friend WithEvents AddressRichTextBox As System.Windows.Forms.RichTextBox
    Friend WithEvents LbsContact As System.Windows.Forms.Label
    Friend WithEvents LbsZipcode As System.Windows.Forms.Label
    Friend WithEvents EditButton As System.Windows.Forms.Button
    Friend WithEvents SearchButton As System.Windows.Forms.Button
    Friend WithEvents ClearButton As System.Windows.Forms.Button
    Friend WithEvents CancelButton As System.Windows.Forms.Button
    Friend WithEvents UpdateButton As System.Windows.Forms.Button
End Class
