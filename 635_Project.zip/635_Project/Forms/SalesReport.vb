﻿Public Class SalesReport
    Dim reportTodo As ReportTodoList
    Private Sub SalesReport_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        'cmbPromotionStatus.SelectedIndex = -1
        Try
            Dim docXML As String = ""
            Dim reportData As String = ""

            Dim dtSalesReport As New DataTable
            reportTodo = New ReportTodoList()
            dtSalesReport = reportTodo.SelectSalesForReport()
            If dtSalesReport.Rows.Count > 0 Then
                reportData = buildXMLContent(dtSalesReport)
            End If
            docXML = "<?xml version=""1.0"" encoding=""utf-8""?>"
            docXML += "<html>"
            docXML += "<head>"
            docXML += "<style type=""text/css"">"
            docXML += "body { margin-top: 100px, margin-bottom: 40px, margin-right: 40px; margin-left: 40px; font-family: arial;font-size: 16pt;}"
            docXML += " th { font-style: italic; } th, td { border: 1px solid black; padding: 10 px; text-align: center;}"
            docXML += "tr.odd { background: rgb(244,244,244); } tr.even { background: rgb(232,232,232); }"
            docXML += "table {border-collapse:collapse;}"
            docXML += "</style>"
            docXML += "</head>"
            docXML += "<body> <h1>Sales Report</h1> <h2></h2>"
            docXML += "<table><tr class=""even""><th>Order ID</th><th>Order Date</th><th>Net Order Amount</th></tr>"
            docXML += "</table>"
            docXML += "</body>"
            docXML += "</html>"
            If reportData.Trim.Length = 0 Then
                WebBrowser1.DocumentText = docXML.ToString()
            Else
                WebBrowser1.DocumentText = reportData.ToString()
                WebBrowser1.Visible = True
            End If
        Catch ex As Exception
            MessageBox.Show("Error in loading data for report... please try after sometime", "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Function buildXMLContent(ByVal dtTable As DataTable) As String
        Dim docXML As String = ""
        Dim reportData As String = ""
        Dim tagClass As String = "odd"
        'Dim finalXML As Xml.XmlText
        Dim rowCount As Integer = 0
        Dim TimesOut As Integer = 0
        Dim battingAverage As Decimal = 0D
        Dim bowlingAverage As Decimal = 0D
        Dim TotalSalesDone As Decimal = 0D
        docXML = "<?xml version=""1.0"" encoding=""utf-8""?>"
        docXML += "<html>"
        docXML += "<head>"
        docXML += "<style type=""text/css"">"
        docXML += "body { margin: 40px; font-family: arial;font-size: 16pt;}"
        docXML += " th { font-style: italic; } th, td { border: 1px solid black; padding: 10 px; text-align: center;}"
        docXML += "tr.odd { background: rgb(244,244,244); } tr.even { background: rgb(232,232,232); }"
        docXML += "table {border-collapse:collapse;}"
        docXML += "</style>"
        docXML += "</head>"
        docXML += "<body> <h1>Sales Report</h1> <h2></h2>"
        docXML += "<table><tr class=""even""><th>Order ID</th><th>Order Date</th><th>Net Order Amount</th></tr>"
        For Each dr As DataRow In dtTable.Rows
            If rowCount = 0 Then
                tagClass = "odd"
            ElseIf (rowCount Mod 2) = 0 Then
                tagClass = "even"
            End If

            reportData += "<tr class=" & tagClass & ">"
            reportData += "<td>" & dr.Item("OrderID").ToString() & "</td>"
            reportData += "<td>" & dr.Item("OrderDate").ToString() & "</td>"
            reportData += "<td>" & dr.Item("OrderAmount").ToString() & "</td>"
            reportData += "</tr>"
            rowCount += 1
            TotalSalesDone = TotalSalesDone + Convert.ToDecimal(If(dr.Item("OrderAmount").ToString() = "", 0D, Decimal.Parse(dr.Item("OrderAmount"))))
            If rowCount = dtTable.Rows.Count Then
                If tagClass = "odd" Then
                    tagClass = "even"
                Else
                    tagClass = "odd"
                End If
                reportData += "<tr class=" & tagClass & ">"
                reportData += "<td></td>"
                reportData += "<td> Total Net Sales</td>"
                reportData += "<td>" & TotalSalesDone & "</td>"
                reportData += "</tr>"
                reportData += "</table>"
                reportData += "</body>"
                reportData += "</html>"

            End If
        Next
               Return (docXML.ToString() & " " & reportData.ToString())
    End Function

    Private Sub btnClose_Click(sender As System.Object, e As System.EventArgs) Handles btnClose.Click
        Me.Hide()
        MainForm.Show()
    End Sub

    Private Sub SalesReport_FormClosing(sender As System.Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Me.Hide()
        MainForm.Show()
    End Sub
End Class