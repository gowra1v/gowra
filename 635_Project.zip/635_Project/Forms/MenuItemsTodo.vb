﻿Public Class MenuItemsTodo

    Dim Sql As SqlHelper


    Public Property InItemID As Integer
    Public Property InItemName As String
    Public Property InCategoryID As Integer
    Public Property InItemPrice As Decimal
    Public Property InItemDescription As String


    Public Sub New()

    End Sub

    Public Sub New(ByVal ItemName As String, ByVal CategoryID As Integer,
                   ByVal ItemPrice As Decimal, ByVal ItemDescription As String)

        InItemName = ItemName
        InCategoryID = CategoryID
        InItemPrice = ItemPrice
        InItemDescription = ItemDescription
    End Sub

    Public Function InsertMenuItemsIntoDatabase() As Integer
        Sql = New SqlHelper()
        Dim insertStr As String
        Dim InsertSuccess As Integer
        'insertStr = "INSERT INTO MenuItems (ItemName, CategoryID, ItemPrice, Description) VALUES ('" & InItemName & "'," & InCategoryID & ",'" & InItemPrice & "','" & InItemDescription & "')"
        insertStr = "INSERT INTO MenuItems (ItemName, CategoryID, ItemPrice, Description) VALUES ('" & InItemName & "'," & InCategoryID & ",'" & InItemPrice & "','" & InItemDescription & "')"
        InsertSuccess = Sql.ExecuteInsUpdDel(insertStr, True) REM True, it is Insert
        If InsertSuccess > 0 Then

        End If
        Return InsertSuccess
    End Function

    Public Function UpdateInventoryItemsIntoDatabase() As Integer
        Sql = New SqlHelper()
        'Dim insertStr, updateStr As String
        'Dim InsertSuccess, UpdateSuccess As Integer
        Dim updateStr As String
        Dim UpdateSuccess As Integer
        updateStr = "UPDATE MenuItems SET ItemName = '" & InItemName & "', CategoryID = " & InCategoryID & ", ItemPrice = '" & InItemPrice & "',Description = '" & InItemDescription & "' WHERE ItemID = " & InItemID & """"
        UpdateSuccess = Sql.ExecuteInsUpdDel(updateStr) REM True, it is Insert

        Return UpdateSuccess
    End Function

    Public Function DeleteMenuItemFromDatabase(ByVal InItemID As Integer) As Integer
        Sql = New SqlHelper()
        Dim deleteStr As String
        deleteStr = "DELETE * FROM MenuItems WHERE ItemID  = " & InItemID
        Dim deleteStatus As Integer = Sql.ExecuteInsUpdDel(deleteStr)
        Return deleteStatus
    End Function

    Public Function GetMenuItemID() As Integer
        Dim GetMaxID As Integer
        Dim selectStr As String
        Sql = New SqlHelper()
        selectStr = "select Max(ItemID) as MaxID from MenuItems"
        GetMaxID = Sql.GetMaxID(selectStr)
        Return GetMaxID
    End Function

    Public Function LoadMenuItemsDetails(ByVal InItemID As Integer) As DataTable
        Sql = New SqlHelper()
        Dim selectStr As String
        Dim dt As DataTable
        selectStr = "select * from MenuItems where MenuID = " & InItemID & ""
        dt = Sql.ExecuteSelectTable(selectStr)
        Return dt
    End Function

    Public Function LoadPriceDetails(ByVal InMenuID As Integer) As Decimal
        Sql = New SqlHelper()
        Dim selectStr As String
        Dim decPrice As Decimal
        selectStr = "select ItemPrice As PriceItem from MenuItems where MenuID = " & InMenuID & ""
        decPrice = Sql.GetPrice(selectStr)
        Return decPrice
    End Function

    Public Function LoadItemDetails() As DataTable
        Sql = New SqlHelper()
        Dim selectStr As String
        Dim dt As DataTable
        selectStr = "select * from MenuItems"
        dt = Sql.ExecuteSelectTable(selectStr)
        Return dt
    End Function

    Public Function LoadItemCategoriesList(ByVal CountryCode As String) As DataTable
        Sql = New SqlHelper()
        Dim selectStr As String
        Dim dt As DataTable
        selectStr = "select  CategoryID, CategoryName FROM ItemCategories"
        dt = Sql.ExecuteSelectTable(selectStr)
        Return dt

    End Function


End Class
