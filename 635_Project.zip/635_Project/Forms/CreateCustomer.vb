﻿Public Class Employee

    
End Class
