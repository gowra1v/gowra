﻿Imports System.Data.OleDb
Public Class SqlHelper
    Public Shared strConnect As String
    Public Shared UserLoginType As String
    Public Shared EmployeeID As Integer
    Public Shared EmployeeName As String


    Public Function GetConnection() As OleDbConnection
        strConnect = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\Popoye.accdb;"
        Dim oconn As OleDbConnection = New OleDbConnection(strConnect)
        Return oconn
    End Function

    Public Function ExecuteSelectTable(ByVal strSQL As String) As DataTable
        Dim oconn As OleDbConnection = GetConnection()
        Dim dt As New DataTable
        Dim da As New OleDbDataAdapter(strSQL, oconn)
        da.Fill(dt)
        oconn.Close()
        oconn.Dispose()
        da.Dispose()
        Return dt
    End Function

    Public Function ExecuteInsUpdDel(ByVal strSQL As String,
                                     Optional ByVal ReturnID As Boolean = False) As Integer
        Dim oconn As OleDbConnection = GetConnection()
        Dim command As New OleDbCommand(strSQL, oconn)
        command.CommandType = CommandType.Text
        oconn.Open()
        Dim retval As Integer
        Try
            If ReturnID Then
                command.ExecuteNonQuery()
                command.CommandText = "SELECT @@IDENTITY"
                retval = command.ExecuteScalar()
            Else
                retval = command.ExecuteNonQuery()
            End If


        Catch ex As Exception
            MsgBox("SQL error: " & ex.Message)
            retval = -1
        Finally
            oconn.Close()
            oconn.Dispose()
            command.Dispose()
        End Try
        Return retval  REM either number of rows affected; or ID of new row
    End Function


    Public Function GetMaxID(ByVal strSQL As String) As Integer

        Dim oconn As OleDbConnection = GetConnection()
        Dim command As New OleDbCommand(strSQL, oconn)
        Dim oReader As OleDbDataReader = Nothing
        Dim retval As Integer
        oconn.Open()
        Try
            oReader = command.ExecuteReader()
            oReader.Read()

            If oReader("MaxID").ToString() <> "" Then
                retval = Integer.Parse(oReader("MaxID").ToString()) + 1
            Else
                retval = 1
            End If
        Catch ex As Exception
            MsgBox("SQL error: " & ex.Message)
            retval = -1
        Finally
            oconn.Close()
            oconn.Dispose()
            command.Dispose()
            oReader.Close()
        End Try
        Return retval
    End Function


    Public Function GetPrice(ByVal strSQL As String) As Decimal

        Dim oconn As OleDbConnection = GetConnection()
        Dim command As New OleDbCommand(strSQL, oconn)
        Dim oReader As OleDbDataReader = Nothing
        Dim retval As Decimal
        oconn.Open()
        Try
            oReader = command.ExecuteReader()
            oReader.Read()

            If oReader("PriceItem").ToString() <> "" Then
                retval = Decimal.Parse(oReader("PriceItem").ToString())
            Else
                retval = 1D
            End If
        Catch ex As Exception
            MsgBox("SQL error: " & ex.Message)
            retval = -1
        Finally
            oconn.Close()
            oconn.Dispose()
            command.Dispose()
            oReader.Close()
        End Try
        Return retval
    End Function

End Class
