﻿Imports System.Net.Mail
Public Class DiscountsOffer
    Dim PromotionTo As PromotionTodo
    Dim PromotionCode As Integer
    Dim PromotionDescription As String
    Dim PromoDiscount As Integer
    Dim ValidityFrom As Date
    Dim ValidityTo As Date

    Private Sub btnCreate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnCreate.Click
        Dim insertStatus As Integer
        If txtDescriptionPromotion.Text = "" Then
            MessageBox.Show("Description cannot be blank", "Description", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtDescriptionPromotion.Focus()
            Exit Sub
        ElseIf txtDiscount.Text = "" Then
            MessageBox.Show("Discount cannot be blank", "Discount", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtDiscount.Focus()
            Exit Sub
        ElseIf dtpValidityFrom.Value.Date < Date.Today Then
            MessageBox.Show(" Validity From Date should not be less than today's date", "Validity Date Error...", MessageBoxButtons.OK, MessageBoxIcon.Error)
            dtpValidityFrom.Focus()
            Exit Sub
        ElseIf dtpValidTo.Value.Date < Date.Today Then
            MessageBox.Show(" Validity To Date should not be less than today's date", "Validity To Date Error...", MessageBoxButtons.OK, MessageBoxIcon.Error)
            dtpValidTo.Focus()
            Exit Sub
        ElseIf dtpValidTo.Value.Date < dtpValidityFrom.Value.Date Then
            MessageBox.Show("Validity Date value cannot be greater than Valid from Date", "Validity To Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            dtpValidTo.Focus()
            Exit Sub
        ElseIf txtDiscount.Text.Trim.Length > 2 Then
            MessageBox.Show("Discount Value Cannot be more than or equal to 100, ", "Discount Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtDiscount.Focus()
            Exit Sub
        Else
            PromotionTo = New PromotionTodo(txtDescriptionPromotion.Text, Convert.ToInt32(txtDiscount.Text), Format(Convert.ToDateTime(dtpValidityFrom.Value), "MM-dd-yyyy"), Format(Convert.ToDateTime(dtpValidTo.Value), "MM-dd-yyyy"))
            insertStatus = PromotionTo.InsertPromotionsIntoDatabase()
            If insertStatus > 0 Then
                MessageBox.Show("New Promotion got created successfully", "New Promotion : Success", MessageBoxButtons.OK, MessageBoxIcon.Information)

                PromotionCode = insertStatus
                PromotionDescription = txtDescriptionPromotion.Text
                PromoDiscount = Convert.ToInt32(txtDiscount.Text)
                ValidityFrom = Format(Convert.ToDateTime(dtpValidityFrom.Value), "MM-dd-yyyy")
                ValidityTo = Format(Convert.ToDateTime(dtpValidTo.Value), "MM-dd-yyyy")
            End If
        End If
        txtPromotionID.Text = insertStatus
        txtPromotionID.Enabled = False
        txtDescriptionPromotion.Enabled = False
        txtDiscount.Enabled = False
        dtpValidityFrom.Enabled = False
        dtpValidTo.Enabled = False
        btnCreate.Enabled = False
        btnClear.Text = "&Create New"
        btnSendtoUsers.Enabled = True

    End Sub
    Private Sub DiscountTextBox_KeyPress(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtDiscount.KeyPress
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Then
            e.Handled = False
        Else
            e.Handled = True
            MessageBox.Show("Please enter Discount in numbers", "Discount", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub DiscountsOffer_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        If MessageBox.Show("Please save any unsaved changes and then navigate to main menu view?", "Are you sure to Exit?", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = Windows.Forms.DialogResult.OK Then
            'Me.Close()
            Clear()
            MainForm.Show()
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub DiscountsOffer_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        txtDescriptionPromotion.Focus()
    End Sub
    Sub Clear()
        txtPromotionID.Text = ""
        txtDescriptionPromotion.Text = ""
        txtDiscount.Text = ""
    End Sub

    Private Sub CancelButton_Click(sender As System.Object, e As System.EventArgs) Handles CancelButton.Click

        If MessageBox.Show("Please save any unsaved changes and then navigate to main menu view?", "Are you sure to Exit?", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = Windows.Forms.DialogResult.OK Then
            Me.Hide()
            Clear()
            MainForm.Show()
        End If
    End Sub

    Private Sub ClearButton_Click(sender As System.Object, e As System.EventArgs) Handles btnClear.Click

        If btnClear.Text = "&Clear" Then
            Clear()
            btnSendtoUsers.Enabled = False
        ElseIf btnClear.Text = "&Create New" Then
            Clear()

            txtDescriptionPromotion.Enabled = True
            txtDiscount.Enabled = True
            btnSendtoUsers.Enabled = True
            dtpValidityFrom.Enabled = True
            dtpValidTo.Enabled = True
        End If
    End Sub


    Private Sub btnSendtoUsers_Click(sender As System.Object, e As System.EventArgs) Handles btnSendtoUsers.Click

        Dim dtEmailIds As DataTable
        Dim toEmailID As String
        PromotionTo = New PromotionTodo()
        dtEmailIds = PromotionTo.GetCustomerEmailIds()
        If dtEmailIds.Rows.Count > 0 Then
            For Each dr As DataRow In dtEmailIds.Rows
                toEmailID = dr.Item("EmailID").ToString()
                sendEmail(toEmailID)
            Next
        End If

    End Sub

    Private Sub sendEmail(email As String)
        Dim smtpServer As New SmtpClient()
        Dim mail As New MailMessage
        Dim mobile As String = ""
        smtpServer.Credentials = New Net.NetworkCredential("popeyes.mtpleasant@gmail.com", "bisgroup3")
        smtpServer.Port = 587
        smtpServer.Host = "smtp.gmail.com"
        smtpServer.EnableSsl = True
        mail.From = New MailAddress("popeyes.mtpleasant@gmail.com", "Popeyes Chicken")
        
        mail.To.Add(email)
       
        mail.Subject = "Promotion notification"
        mail.Body = "Dear Customer," & vbNewLine & "There is an promotional offer between " & ValidityFrom & " and " & ValidityTo & " with discount coupon code " & PromotionCode & "which will gice an discount of " & PromoDiscount & ". " & vbNewLine & " Please visit our store and get benefits of this promotion"
        
        smtpServer.Send(mail)
        MsgBox("Mail is sent", MsgBoxStyle.OkOnly, "Mail")
    End Sub
End Class