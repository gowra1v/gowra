﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainForm
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainForm))
        Me.MenuStrip2 = New System.Windows.Forms.MenuStrip()
        Me.InventoryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ProductMasterEntryToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuItemsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NewMenuItemToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MapMenuItemsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.OrdersToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CreateOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ReportsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RegistrationToolStripMenuItem2 = New System.Windows.Forms.ToolStripMenuItem()
        Me.InventoryToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.SalesReportToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.PromotionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CreatePromotionToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SendEmailToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.CalculatorToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.NotepadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.TaskManagerToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MSWordToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.SystemInfoToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.WordpadToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.StatusStrip1 = New System.Windows.Forms.StatusStrip()
        Me.ToolStripStatusLabel1 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel2 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel3 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.ToolStripStatusLabel4 = New System.Windows.Forms.ToolStripStatusLabel()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Button1 = New System.Windows.Forms.Button()
        Me.pbInventoryItem = New System.Windows.Forms.PictureBox()
        Me.pbOrderForm = New System.Windows.Forms.PictureBox()
        Me.btnLogout = New System.Windows.Forms.PictureBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.PlaceOrder = New System.Windows.Forms.Label()
        Me.UpdateOrderToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.MenuStrip2.SuspendLayout()
        Me.StatusStrip1.SuspendLayout()
        CType(Me.pbInventoryItem, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.pbOrderForm, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.btnLogout, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip2
        '
        Me.MenuStrip2.BackColor = System.Drawing.SystemColors.Control
        Me.MenuStrip2.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InventoryToolStripMenuItem, Me.MenuItemsToolStripMenuItem, Me.OrdersToolStripMenuItem, Me.ReportsToolStripMenuItem, Me.PromotionsToolStripMenuItem, Me.ToolsToolStripMenuItem})
        Me.MenuStrip2.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip2.Name = "MenuStrip2"
        Me.MenuStrip2.Padding = New System.Windows.Forms.Padding(7, 2, 0, 2)
        Me.MenuStrip2.Size = New System.Drawing.Size(650, 24)
        Me.MenuStrip2.TabIndex = 1
        Me.MenuStrip2.Text = "MenuStrip2"
        '
        'InventoryToolStripMenuItem
        '
        Me.InventoryToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProductMasterEntryToolStripMenuItem})
        Me.InventoryToolStripMenuItem.Name = "InventoryToolStripMenuItem"
        Me.InventoryToolStripMenuItem.Size = New System.Drawing.Size(69, 20)
        Me.InventoryToolStripMenuItem.Text = "Inventory"
        '
        'ProductMasterEntryToolStripMenuItem
        '
        Me.ProductMasterEntryToolStripMenuItem.Name = "ProductMasterEntryToolStripMenuItem"
        Me.ProductMasterEntryToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.ProductMasterEntryToolStripMenuItem.Text = "Inventory Item"
        '
        'MenuItemsToolStripMenuItem
        '
        Me.MenuItemsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.NewMenuItemToolStripMenuItem, Me.MapMenuItemsToolStripMenuItem})
        Me.MenuItemsToolStripMenuItem.Name = "MenuItemsToolStripMenuItem"
        Me.MenuItemsToolStripMenuItem.Size = New System.Drawing.Size(82, 20)
        Me.MenuItemsToolStripMenuItem.Text = "Menu Items"
        '
        'NewMenuItemToolStripMenuItem
        '
        Me.NewMenuItemToolStripMenuItem.Name = "NewMenuItemToolStripMenuItem"
        Me.NewMenuItemToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.NewMenuItemToolStripMenuItem.Text = "Menu Item"
        '
        'MapMenuItemsToolStripMenuItem
        '
        Me.MapMenuItemsToolStripMenuItem.Name = "MapMenuItemsToolStripMenuItem"
        Me.MapMenuItemsToolStripMenuItem.Size = New System.Drawing.Size(157, 22)
        Me.MapMenuItemsToolStripMenuItem.Text = "Item Categories"
        '
        'OrdersToolStripMenuItem
        '
        Me.OrdersToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CreateOrderToolStripMenuItem, Me.UpdateOrderToolStripMenuItem})
        Me.OrdersToolStripMenuItem.Name = "OrdersToolStripMenuItem"
        Me.OrdersToolStripMenuItem.Size = New System.Drawing.Size(54, 20)
        Me.OrdersToolStripMenuItem.Text = "Orders"
        '
        'CreateOrderToolStripMenuItem
        '
        Me.CreateOrderToolStripMenuItem.Name = "CreateOrderToolStripMenuItem"
        Me.CreateOrderToolStripMenuItem.Size = New System.Drawing.Size(141, 22)
        Me.CreateOrderToolStripMenuItem.Text = "Create Order"
        '
        'ReportsToolStripMenuItem
        '
        Me.ReportsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RegistrationToolStripMenuItem2, Me.InventoryToolStripMenuItem1, Me.SalesReportToolStripMenuItem})
        Me.ReportsToolStripMenuItem.Name = "ReportsToolStripMenuItem"
        Me.ReportsToolStripMenuItem.Size = New System.Drawing.Size(59, 20)
        Me.ReportsToolStripMenuItem.Text = "Reports"
        '
        'RegistrationToolStripMenuItem2
        '
        Me.RegistrationToolStripMenuItem2.Name = "RegistrationToolStripMenuItem2"
        Me.RegistrationToolStripMenuItem2.Size = New System.Drawing.Size(138, 22)
        Me.RegistrationToolStripMenuItem2.Text = "Promotions"
        '
        'InventoryToolStripMenuItem1
        '
        Me.InventoryToolStripMenuItem1.Name = "InventoryToolStripMenuItem1"
        Me.InventoryToolStripMenuItem1.Size = New System.Drawing.Size(138, 22)
        Me.InventoryToolStripMenuItem1.Text = "Inventory"
        '
        'SalesReportToolStripMenuItem
        '
        Me.SalesReportToolStripMenuItem.Name = "SalesReportToolStripMenuItem"
        Me.SalesReportToolStripMenuItem.Size = New System.Drawing.Size(138, 22)
        Me.SalesReportToolStripMenuItem.Text = "Sales Report"
        '
        'PromotionsToolStripMenuItem
        '
        Me.PromotionsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CreatePromotionToolStripMenuItem, Me.SendEmailToolStripMenuItem})
        Me.PromotionsToolStripMenuItem.Name = "PromotionsToolStripMenuItem"
        Me.PromotionsToolStripMenuItem.Size = New System.Drawing.Size(81, 20)
        Me.PromotionsToolStripMenuItem.Text = "Promotions"
        '
        'CreatePromotionToolStripMenuItem
        '
        Me.CreatePromotionToolStripMenuItem.Name = "CreatePromotionToolStripMenuItem"
        Me.CreatePromotionToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.CreatePromotionToolStripMenuItem.Text = "Create Promotion"
        '
        'SendEmailToolStripMenuItem
        '
        Me.SendEmailToolStripMenuItem.Name = "SendEmailToolStripMenuItem"
        Me.SendEmailToolStripMenuItem.Size = New System.Drawing.Size(168, 22)
        Me.SendEmailToolStripMenuItem.Text = "Send Email"
        '
        'ToolsToolStripMenuItem
        '
        Me.ToolsToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.CalculatorToolStripMenuItem, Me.NotepadToolStripMenuItem, Me.TaskManagerToolStripMenuItem, Me.MSWordToolStripMenuItem, Me.SystemInfoToolStripMenuItem, Me.WordpadToolStripMenuItem})
        Me.ToolsToolStripMenuItem.Name = "ToolsToolStripMenuItem"
        Me.ToolsToolStripMenuItem.Size = New System.Drawing.Size(48, 20)
        Me.ToolsToolStripMenuItem.Text = "Tools"
        '
        'CalculatorToolStripMenuItem
        '
        Me.CalculatorToolStripMenuItem.Image = CType(resources.GetObject("CalculatorToolStripMenuItem.Image"), System.Drawing.Image)
        Me.CalculatorToolStripMenuItem.Name = "CalculatorToolStripMenuItem"
        Me.CalculatorToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.CalculatorToolStripMenuItem.Text = "Calculator"
        '
        'NotepadToolStripMenuItem
        '
        Me.NotepadToolStripMenuItem.Image = CType(resources.GetObject("NotepadToolStripMenuItem.Image"), System.Drawing.Image)
        Me.NotepadToolStripMenuItem.Name = "NotepadToolStripMenuItem"
        Me.NotepadToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.NotepadToolStripMenuItem.Text = "Notepad"
        '
        'TaskManagerToolStripMenuItem
        '
        Me.TaskManagerToolStripMenuItem.Image = CType(resources.GetObject("TaskManagerToolStripMenuItem.Image"), System.Drawing.Image)
        Me.TaskManagerToolStripMenuItem.Name = "TaskManagerToolStripMenuItem"
        Me.TaskManagerToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.TaskManagerToolStripMenuItem.Text = "Task Manager"
        '
        'MSWordToolStripMenuItem
        '
        Me.MSWordToolStripMenuItem.Image = CType(resources.GetObject("MSWordToolStripMenuItem.Image"), System.Drawing.Image)
        Me.MSWordToolStripMenuItem.Name = "MSWordToolStripMenuItem"
        Me.MSWordToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.MSWordToolStripMenuItem.Text = "MS Word"
        '
        'SystemInfoToolStripMenuItem
        '
        Me.SystemInfoToolStripMenuItem.Image = CType(resources.GetObject("SystemInfoToolStripMenuItem.Image"), System.Drawing.Image)
        Me.SystemInfoToolStripMenuItem.Name = "SystemInfoToolStripMenuItem"
        Me.SystemInfoToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.SystemInfoToolStripMenuItem.Text = "System Info"
        '
        'WordpadToolStripMenuItem
        '
        Me.WordpadToolStripMenuItem.Image = CType(resources.GetObject("WordpadToolStripMenuItem.Image"), System.Drawing.Image)
        Me.WordpadToolStripMenuItem.Name = "WordpadToolStripMenuItem"
        Me.WordpadToolStripMenuItem.Size = New System.Drawing.Size(148, 22)
        Me.WordpadToolStripMenuItem.Text = "Wordpad"
        '
        'StatusStrip1
        '
        Me.StatusStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ToolStripStatusLabel1, Me.ToolStripStatusLabel2, Me.ToolStripStatusLabel3, Me.ToolStripStatusLabel4})
        Me.StatusStrip1.Location = New System.Drawing.Point(0, 463)
        Me.StatusStrip1.Name = "StatusStrip1"
        Me.StatusStrip1.Padding = New System.Windows.Forms.Padding(1, 0, 16, 0)
        Me.StatusStrip1.Size = New System.Drawing.Size(650, 22)
        Me.StatusStrip1.TabIndex = 2
        Me.StatusStrip1.Text = "StatusStrip1"
        '
        'ToolStripStatusLabel1
        '
        Me.ToolStripStatusLabel1.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel1.Name = "ToolStripStatusLabel1"
        Me.ToolStripStatusLabel1.Size = New System.Drawing.Size(86, 17)
        Me.ToolStripStatusLabel1.Text = "Logged in As :"
        '
        'ToolStripStatusLabel2
        '
        Me.ToolStripStatusLabel2.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel2.Image = CType(resources.GetObject("ToolStripStatusLabel2.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel2.Name = "ToolStripStatusLabel2"
        Me.ToolStripStatusLabel2.Size = New System.Drawing.Size(145, 17)
        Me.ToolStripStatusLabel2.Text = "ToolStripStatusLabel2"
        '
        'ToolStripStatusLabel3
        '
        Me.ToolStripStatusLabel3.Name = "ToolStripStatusLabel3"
        Me.ToolStripStatusLabel3.Size = New System.Drawing.Size(257, 17)
        Me.ToolStripStatusLabel3.Spring = True
        '
        'ToolStripStatusLabel4
        '
        Me.ToolStripStatusLabel4.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.ToolStripStatusLabel4.Image = CType(resources.GetObject("ToolStripStatusLabel4.Image"), System.Drawing.Image)
        Me.ToolStripStatusLabel4.Name = "ToolStripStatusLabel4"
        Me.ToolStripStatusLabel4.Size = New System.Drawing.Size(145, 17)
        Me.ToolStripStatusLabel4.Text = "ToolStripStatusLabel4"
        '
        'Timer1
        '
        Me.Timer1.Enabled = True
        '
        'Timer2
        '
        Me.Timer2.Enabled = True
        '
        'Button1
        '
        Me.Button1.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.Button1.ForeColor = System.Drawing.SystemColors.ControlLightLight
        Me.Button1.Location = New System.Drawing.Point(0, 800)
        Me.Button1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(1, 1)
        Me.Button1.TabIndex = 99
        Me.Button1.Text = "."
        Me.Button1.UseVisualStyleBackColor = False
        '
        'pbInventoryItem
        '
        Me.pbInventoryItem.Image = CType(resources.GetObject("pbInventoryItem.Image"), System.Drawing.Image)
        Me.pbInventoryItem.Location = New System.Drawing.Point(143, 166)
        Me.pbInventoryItem.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.pbInventoryItem.Name = "pbInventoryItem"
        Me.pbInventoryItem.Size = New System.Drawing.Size(112, 113)
        Me.pbInventoryItem.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbInventoryItem.TabIndex = 100
        Me.pbInventoryItem.TabStop = False
        '
        'pbOrderForm
        '
        Me.pbOrderForm.Image = CType(resources.GetObject("pbOrderForm.Image"), System.Drawing.Image)
        Me.pbOrderForm.Location = New System.Drawing.Point(377, 166)
        Me.pbOrderForm.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.pbOrderForm.Name = "pbOrderForm"
        Me.pbOrderForm.Size = New System.Drawing.Size(112, 113)
        Me.pbOrderForm.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.pbOrderForm.TabIndex = 101
        Me.pbOrderForm.TabStop = False
        '
        'btnLogout
        '
        Me.btnLogout.Image = CType(resources.GetObject("btnLogout.Image"), System.Drawing.Image)
        Me.btnLogout.Location = New System.Drawing.Point(576, 35)
        Me.btnLogout.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnLogout.Name = "btnLogout"
        Me.btnLogout.Size = New System.Drawing.Size(59, 53)
        Me.btnLogout.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage
        Me.btnLogout.TabIndex = 102
        Me.btnLogout.TabStop = False
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(162, 305)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(63, 17)
        Me.Label1.TabIndex = 103
        Me.Label1.Text = "Inventory"
        '
        'PlaceOrder
        '
        Me.PlaceOrder.AutoSize = True
        Me.PlaceOrder.Location = New System.Drawing.Point(401, 305)
        Me.PlaceOrder.Name = "PlaceOrder"
        Me.PlaceOrder.Size = New System.Drawing.Size(72, 17)
        Me.PlaceOrder.TabIndex = 104
        Me.PlaceOrder.Text = "Place Order"
        '
        'UpdateOrderToolStripMenuItem
        '
        Me.UpdateOrderToolStripMenuItem.Name = "UpdateOrderToolStripMenuItem"
        Me.UpdateOrderToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.UpdateOrderToolStripMenuItem.Text = "Update Order"
        '
        'MainForm
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.ClientSize = New System.Drawing.Size(650, 485)
        Me.Controls.Add(Me.PlaceOrder)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.btnLogout)
        Me.Controls.Add(Me.pbOrderForm)
        Me.Controls.Add(Me.pbInventoryItem)
        Me.Controls.Add(Me.Button1)
        Me.Controls.Add(Me.StatusStrip1)
        Me.Controls.Add(Me.MenuStrip2)
        Me.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.MaximizeBox = False
        Me.Name = "MainForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Main Menu"
        Me.MenuStrip2.ResumeLayout(False)
        Me.MenuStrip2.PerformLayout()
        Me.StatusStrip1.ResumeLayout(False)
        Me.StatusStrip1.PerformLayout()
        CType(Me.pbInventoryItem, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.pbOrderForm, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.btnLogout, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip2 As System.Windows.Forms.MenuStrip
    Friend WithEvents InventoryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ToolsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CalculatorToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NotepadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents TaskManagerToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MSWordToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SystemInfoToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents StatusStrip1 As System.Windows.Forms.StatusStrip
    Friend WithEvents ToolStripStatusLabel1 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel2 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel3 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents ToolStripStatusLabel4 As System.Windows.Forms.ToolStripStatusLabel
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents WordpadToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ReportsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RegistrationToolStripMenuItem2 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents ProductMasterEntryToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents OrdersToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreateOrderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MenuItemsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents NewMenuItemToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents MapMenuItemsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InventoryToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents pbInventoryItem As System.Windows.Forms.PictureBox
    Friend WithEvents pbOrderForm As System.Windows.Forms.PictureBox
    Friend WithEvents btnLogout As System.Windows.Forms.PictureBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents PlaceOrder As System.Windows.Forms.Label
    Friend WithEvents SalesReportToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents PromotionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents SendEmailToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents CreatePromotionToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents UpdateOrderToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
