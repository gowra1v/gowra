﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MenuItemsRecord
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvCategoryDetails = New System.Windows.Forms.DataGridView()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnResetExport = New System.Windows.Forms.Button()
        Me.btnResetCategory = New System.Windows.Forms.Button()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.btnExportAll = New System.Windows.Forms.Button()
        Me.btnGetAll = New System.Windows.Forms.Button()
        Me.dgvMenuItemsData = New System.Windows.Forms.DataGridView()
        Me.btnResetAll = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.cmbCategory = New System.Windows.Forms.ComboBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.btnInventoryExport = New System.Windows.Forms.Button()
        Me.cmbInventoryName = New System.Windows.Forms.ComboBox()
        Me.GroupBox4 = New System.Windows.Forms.GroupBox()
        Me.btnResetInventory = New System.Windows.Forms.Button()
        Me.MenuItemTabControl = New System.Windows.Forms.TabControl()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.dgvMenuItemDetails = New System.Windows.Forms.DataGridView()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.txtMenuItemName = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.Button1 = New System.Windows.Forms.Button()
        CType(Me.dgvCategoryDetails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.dgvMenuItemsData, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage4.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.GroupBox4.SuspendLayout()
        Me.MenuItemTabControl.SuspendLayout()
        Me.TabPage2.SuspendLayout()
        CType(Me.dgvMenuItemDetails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.SuspendLayout()
        '
        'dgvCategoryDetails
        '
        Me.dgvCategoryDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvCategoryDetails.Location = New System.Drawing.Point(8, 97)
        Me.dgvCategoryDetails.MultiSelect = False
        Me.dgvCategoryDetails.Name = "dgvCategoryDetails"
        Me.dgvCategoryDetails.Size = New System.Drawing.Size(824, 475)
        Me.dgvCategoryDetails.TabIndex = 34
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnResetExport)
        Me.GroupBox2.Controls.Add(Me.btnResetCategory)
        Me.GroupBox2.Location = New System.Drawing.Point(358, 6)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Size = New System.Drawing.Size(230, 87)
        Me.GroupBox2.TabIndex = 32
        Me.GroupBox2.TabStop = False
        '
        'btnResetExport
        '
        Me.btnResetExport.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnResetExport.Location = New System.Drawing.Point(117, 30)
        Me.btnResetExport.Name = "btnResetExport"
        Me.btnResetExport.Size = New System.Drawing.Size(94, 40)
        Me.btnResetExport.TabIndex = 2
        Me.btnResetExport.Text = "&Export Excel"
        Me.btnResetExport.UseVisualStyleBackColor = True
        '
        'btnResetCategory
        '
        Me.btnResetCategory.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnResetCategory.Location = New System.Drawing.Point(17, 30)
        Me.btnResetCategory.Name = "btnResetCategory"
        Me.btnResetCategory.Size = New System.Drawing.Size(94, 40)
        Me.btnResetCategory.TabIndex = 1
        Me.btnResetCategory.Text = "&Reset"
        Me.btnResetCategory.UseVisualStyleBackColor = True
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.btnExportAll)
        Me.TabPage1.Controls.Add(Me.btnGetAll)
        Me.TabPage1.Controls.Add(Me.dgvMenuItemsData)
        Me.TabPage1.Controls.Add(Me.btnResetAll)
        Me.TabPage1.Location = New System.Drawing.Point(4, 33)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage1.Size = New System.Drawing.Size(970, 557)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "All Data"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'btnExportAll
        '
        Me.btnExportAll.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExportAll.Location = New System.Drawing.Point(235, 26)
        Me.btnExportAll.Name = "btnExportAll"
        Me.btnExportAll.Size = New System.Drawing.Size(94, 40)
        Me.btnExportAll.TabIndex = 2
        Me.btnExportAll.Text = "&Export Excel"
        Me.btnExportAll.UseVisualStyleBackColor = True
        '
        'btnGetAll
        '
        Me.btnGetAll.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGetAll.Location = New System.Drawing.Point(17, 26)
        Me.btnGetAll.Name = "btnGetAll"
        Me.btnGetAll.Size = New System.Drawing.Size(94, 40)
        Me.btnGetAll.TabIndex = 0
        Me.btnGetAll.Text = "&Get Data"
        Me.btnGetAll.UseVisualStyleBackColor = True
        '
        'dgvMenuItemsData
        '
        Me.dgvMenuItemsData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvMenuItemsData.Location = New System.Drawing.Point(8, 94)
        Me.dgvMenuItemsData.MultiSelect = False
        Me.dgvMenuItemsData.Name = "dgvMenuItemsData"
        Me.dgvMenuItemsData.Size = New System.Drawing.Size(822, 475)
        Me.dgvMenuItemsData.TabIndex = 32
        '
        'btnResetAll
        '
        Me.btnResetAll.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnResetAll.Location = New System.Drawing.Point(126, 26)
        Me.btnResetAll.Name = "btnResetAll"
        Me.btnResetAll.Size = New System.Drawing.Size(94, 40)
        Me.btnResetAll.TabIndex = 1
        Me.btnResetAll.Text = "&Reset"
        Me.btnResetAll.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Palatino Linotype", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(20, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(203, 31)
        Me.Label1.TabIndex = 9
        Me.Label1.Text = "Menu Item Name"
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.dgvCategoryDetails)
        Me.TabPage4.Controls.Add(Me.GroupBox2)
        Me.TabPage4.Controls.Add(Me.GroupBox7)
        Me.TabPage4.Location = New System.Drawing.Point(4, 33)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage4.Size = New System.Drawing.Size(970, 557)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "By Category"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.cmbCategory)
        Me.GroupBox7.Controls.Add(Me.Label3)
        Me.GroupBox7.Location = New System.Drawing.Point(8, 6)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Size = New System.Drawing.Size(328, 87)
        Me.GroupBox7.TabIndex = 31
        Me.GroupBox7.TabStop = False
        '
        'cmbCategory
        '
        Me.cmbCategory.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cmbCategory.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbCategory.FormattingEnabled = True
        Me.cmbCategory.Items.AddRange(New Object() {"Cancelled", "Completed", "Uncompleted"})
        Me.cmbCategory.Location = New System.Drawing.Point(24, 45)
        Me.cmbCategory.Name = "cmbCategory"
        Me.cmbCategory.Size = New System.Drawing.Size(282, 32)
        Me.cmbCategory.TabIndex = 25
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Palatino Linotype", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(20, 18)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(111, 31)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Category"
        '
        'btnInventoryExport
        '
        Me.btnInventoryExport.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInventoryExport.Location = New System.Drawing.Point(116, 26)
        Me.btnInventoryExport.Name = "btnInventoryExport"
        Me.btnInventoryExport.Size = New System.Drawing.Size(94, 40)
        Me.btnInventoryExport.TabIndex = 2
        Me.btnInventoryExport.Text = "&Export Excel"
        Me.btnInventoryExport.UseVisualStyleBackColor = True
        '
        'cmbInventoryName
        '
        Me.cmbInventoryName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cmbInventoryName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbInventoryName.FormattingEnabled = True
        Me.cmbInventoryName.Location = New System.Drawing.Point(24, 45)
        Me.cmbInventoryName.Name = "cmbInventoryName"
        Me.cmbInventoryName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmbInventoryName.Size = New System.Drawing.Size(248, 32)
        Me.cmbInventoryName.TabIndex = 25
        '
        'GroupBox4
        '
        Me.GroupBox4.Controls.Add(Me.cmbInventoryName)
        Me.GroupBox4.Controls.Add(Me.Label1)
        Me.GroupBox4.Location = New System.Drawing.Point(8, 6)
        Me.GroupBox4.Name = "GroupBox4"
        Me.GroupBox4.Size = New System.Drawing.Size(300, 87)
        Me.GroupBox4.TabIndex = 32
        Me.GroupBox4.TabStop = False
        '
        'btnResetInventory
        '
        Me.btnResetInventory.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnResetInventory.Location = New System.Drawing.Point(16, 26)
        Me.btnResetInventory.Name = "btnResetInventory"
        Me.btnResetInventory.Size = New System.Drawing.Size(94, 40)
        Me.btnResetInventory.TabIndex = 1
        Me.btnResetInventory.Text = "&Reset"
        Me.btnResetInventory.UseVisualStyleBackColor = True
        '
        'MenuItemTabControl
        '
        Me.MenuItemTabControl.Controls.Add(Me.TabPage1)
        Me.MenuItemTabControl.Controls.Add(Me.TabPage2)
        Me.MenuItemTabControl.Controls.Add(Me.TabPage4)
        Me.MenuItemTabControl.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuItemTabControl.Location = New System.Drawing.Point(12, 3)
        Me.MenuItemTabControl.Name = "MenuItemTabControl"
        Me.MenuItemTabControl.SelectedIndex = 0
        Me.MenuItemTabControl.Size = New System.Drawing.Size(978, 594)
        Me.MenuItemTabControl.TabIndex = 3
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.dgvMenuItemDetails)
        Me.TabPage2.Controls.Add(Me.GroupBox10)
        Me.TabPage2.Controls.Add(Me.GroupBox3)
        Me.TabPage2.Controls.Add(Me.GroupBox4)
        Me.TabPage2.Location = New System.Drawing.Point(4, 33)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(3)
        Me.TabPage2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TabPage2.Size = New System.Drawing.Size(970, 557)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "By Menu Item Name"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'dgvMenuItemDetails
        '
        Me.dgvMenuItemDetails.AllowUserToAddRows = False
        Me.dgvMenuItemDetails.AllowUserToDeleteRows = False
        Me.dgvMenuItemDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvMenuItemDetails.Location = New System.Drawing.Point(8, 97)
        Me.dgvMenuItemDetails.MultiSelect = False
        Me.dgvMenuItemDetails.Name = "dgvMenuItemDetails"
        Me.dgvMenuItemDetails.ReadOnly = True
        Me.dgvMenuItemDetails.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.dgvMenuItemDetails.Size = New System.Drawing.Size(828, 475)
        Me.dgvMenuItemDetails.TabIndex = 35
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.txtMenuItemName)
        Me.GroupBox10.Controls.Add(Me.Label6)
        Me.GroupBox10.Location = New System.Drawing.Point(314, 6)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Size = New System.Drawing.Size(278, 87)
        Me.GroupBox10.TabIndex = 34
        Me.GroupBox10.TabStop = False
        '
        'txtMenuItemName
        '
        Me.txtMenuItemName.Location = New System.Drawing.Point(24, 45)
        Me.txtMenuItemName.Name = "txtMenuItemName"
        Me.txtMenuItemName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtMenuItemName.Size = New System.Drawing.Size(231, 32)
        Me.txtMenuItemName.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(21, 16)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(161, 27)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Search by Name"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnInventoryExport)
        Me.GroupBox3.Controls.Add(Me.btnResetInventory)
        Me.GroupBox3.Location = New System.Drawing.Point(600, 6)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Size = New System.Drawing.Size(224, 87)
        Me.GroupBox3.TabIndex = 33
        Me.GroupBox3.TabStop = False
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Button1.Location = New System.Drawing.Point(230, 29)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(94, 40)
        Me.Button1.TabIndex = 6
        Me.Button1.Text = "&Export Excel"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'MenuItemsRecord
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(9.0!, 20.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(872, 617)
        Me.Controls.Add(Me.MenuItemTabControl)
        Me.Controls.Add(Me.Button1)
        Me.Name = "MenuItemsRecord"
        Me.Text = "MenuItemsRecord"
        CType(Me.dgvCategoryDetails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.dgvMenuItemsData, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage4.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.GroupBox4.ResumeLayout(False)
        Me.GroupBox4.PerformLayout()
        Me.MenuItemTabControl.ResumeLayout(False)
        Me.TabPage2.ResumeLayout(False)
        CType(Me.dgvMenuItemDetails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents dgvCategoryDetails As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnResetExport As System.Windows.Forms.Button
    Friend WithEvents btnResetCategory As System.Windows.Forms.Button
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents btnExportAll As System.Windows.Forms.Button
    Friend WithEvents btnGetAll As System.Windows.Forms.Button
    Friend WithEvents dgvMenuItemsData As System.Windows.Forms.DataGridView
    Friend WithEvents btnResetAll As System.Windows.Forms.Button
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents cmbCategory As System.Windows.Forms.ComboBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents btnInventoryExport As System.Windows.Forms.Button
    Friend WithEvents cmbInventoryName As System.Windows.Forms.ComboBox
    Friend WithEvents GroupBox4 As System.Windows.Forms.GroupBox
    Friend WithEvents btnResetInventory As System.Windows.Forms.Button
    Friend WithEvents MenuItemTabControl As System.Windows.Forms.TabControl
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents dgvMenuItemDetails As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents txtMenuItemName As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents Button1 As System.Windows.Forms.Button
End Class
