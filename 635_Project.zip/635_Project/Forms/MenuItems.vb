﻿Imports System.Data.OleDb
Imports System.Security.Cryptography
Imports System.Text


Public Class MenuItems
    Dim rdr As OleDbDataReader = Nothing
    Dim dtable As DataTable
    Dim con As OleDbConnection = Nothing
    Dim adp As OleDbDataAdapter
    Dim ds As DataSet
    Dim cmd As OleDbCommand = Nothing
    Dim dt As New DataTable
    Dim MenuItemsTo As MenuItemsTodo
    Dim Sql As SqlHelper
    Public Shared unmapInventoryID As Integer
    Public Shared unmapMenuID As Integer
    Dim selMenuID As Integer
    Dim selInventoryID As Integer


    Sub setMenuID(InMenuID As Integer)
        selMenuID = InMenuID
    End Sub


    Sub setInventoryID(InInventoryID As Integer)
        selInventoryID = InInventoryID
    End Sub

    Sub clear()
        txtMenuItemID.Text = ""
        txtMenuItemName.Text = ""
        txtMenuName.Text = ""
        txtInventoryName.Text = ""
        txtQuantityNeeded.Text = ""
        txtunInventoryID.Text = ""
        txtUnitPrice.Text = ""
        txtunMenuID.Text = ""


    End Sub

    Sub clearAll()
        txtMenuItemID.Text = ""
        txtMenuItemName.Text = ""
        txtMenuName.Text = ""
        txtInventoryName.Text = ""
        txtQuantityNeeded.Text = ""
        txtunInventoryID.Text = ""
        txtUnitPrice.Text = ""
        txtunMenuID.Text = ""
    End Sub
   
    Private Sub btnNewMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewMenuItem.Click
        clear()
        txtMenuItemName.Focus()
        btnSaveMenuItem.Enabled = True
        btnMenuUpdate.Enabled = False
        btnMenuDelete.Enabled = False

    End Sub
    Sub sugMenuItemNames()
        con = New OleDbConnection(SqlHelper.strConnect)
        con.Open()

        Dim cmd As New OleDbCommand("SELECT ItemName FROM MenuItems", con)
        Dim ds As New DataSet
        Dim da As New OleDbDataAdapter(cmd)
        da.Fill(ds, "My List")

        Dim col As New AutoCompleteStringCollection
        Dim i As Integer
        For i = 0 To ds.Tables(0).Rows.Count - 1
            col.Add(ds.Tables(0).Rows(i)("ItemName").ToString())

        Next
        txtMenuItemName.AutoCompleteSource = AutoCompleteSource.CustomSource
        txtMenuItemName.AutoCompleteCustomSource = col
        txtMenuItemName.AutoCompleteMode = AutoCompleteMode.Suggest

        con.Close()
    End Sub
    Private Sub btnSaveMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSaveMenuItem.Click


        If Len(Trim(txtMenuItemName.Text)) = 0 Then
            MessageBox.Show("Please enter Item name", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtMenuItemName.Focus()
            Exit Sub
        End If
        If Len(Trim(cmbCategoryName.Text)) = 0 Then
            MessageBox.Show("Please select category", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            cmbCategoryName.Focus()
            Exit Sub
        End If

        If Len(Trim(txtUnitPrice.Text)) = 0 Then
            MessageBox.Show("Please enter Item price", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtUnitPrice.Focus()
            Exit Sub
        End If


        Try
            con = New OleDbConnection(SqlHelper.strConnect)
            con.Open()
            Dim ct1 As String = "select ItemName from MenuItems where ItemName= '" & txtMenuItemName.Text & "'"

            cmd = New OleDbCommand(ct1)
            cmd.Connection = con
            rdr = cmd.ExecuteReader()

            If rdr.Read Then
                MessageBox.Show("Entry for new Menu Item already exists" & vbCrLf & "You can not make duplicate entry" & vbCrLf & "for the same Menu Item" & vbCrLf & "please update the details of Inventory Item", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                If Not rdr Is Nothing Then
                    rdr.Close()
                End If
                Exit Sub
            End If


            con = New OleDbConnection(SqlHelper.strConnect)
            con.Open()

            Dim cb As String = "insert into MenuItems(ItemName,CategoryID,ItemPrice) VALUES (@ItemName,@CategoryID,@ItemPrice)"


            cmd = New OleDbCommand(cb)

            cmd.Connection = con

            cmd.Parameters.Add(New OleDbParameter("@ItemName", System.Data.OleDb.OleDbType.VarChar, 20, "ItemName"))
            cmd.Parameters.Add(New OleDbParameter("@CategoryID", System.Data.OleDb.OleDbType.Integer, 11, "CategoryID"))
            cmd.Parameters.Add(New OleDbParameter("@ItemPrice", System.Data.OleDb.OleDbType.Double, 10, "ItemPrice"))
            cmd.Parameters("@ItemName").Value = txtMenuItemName.Text
            cmd.Parameters("@CategoryID").Value = Convert.ToInt32(cmbCategoryName.SelectedValue)
            cmd.Parameters("@ItemPrice").Value = CDbl(txtUnitPrice.Text)
            cmd.ExecuteReader()

            MessageBox.Show("Successfully saved", "Menu Items Details", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnSaveMenuItem.Enabled = False

            fillCategory()
            sugMenuItemNames()

            If con.State = ConnectionState.Open Then
                con.Close()
            End If

            clear()
            con.Close()
            txtMenuItemID.Text = ""

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
        End Try
    End Sub

    Public Function GetMenuItemID() As Integer
        Dim GetMaxID As Integer
        Dim selectStr As String
        Sql = New SqlHelper()
        selectStr = "select Max(MenuID) as MaxID from MenuItems"
        GetMaxID = Sql.GetMaxID(selectStr)
        Return GetMaxID
    End Function

    Private Sub btnMenuUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMenuUpdate.Click
        Try

            con = New OleDbConnection(SqlHelper.strConnect)
            con.Open()

            Dim cb As String = "update MenuItems set ItemName = '" & txtMenuItemName.Text & "',CategoryID = " & Convert.ToInt32(cmbCategoryName.SelectedValue) & ", ItemPrice = '" & Convert.ToDecimal(txtUnitPrice.Text) & "' where MenuID = " & Convert.ToInt32(txtMenuItemID.Text) & ""
            cmd = New OleDbCommand(cb)
            cmd.Connection = con
            cmd.ExecuteReader()

            MessageBox.Show("Successfully updated", "Menu Item Details", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnMenuUpdate.Enabled = False

            fillCategory()
            sugMenuItemNames()

            If con.State = ConnectionState.Open Then
                con.Close()
            End If

            con.Close()

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnMenuDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMenuDelete.Click
        Try
            If MessageBox.Show("Do you really want to delete the record?", "Menu Item Record", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
                delItemAssignments()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Private Sub delItemAssignments()
        Try
            Dim RowsAffected As Integer = 0

            con = New OleDbConnection(SqlHelper.strConnect)
            con.Open()

            Dim ct As String = "DELETE from ItemAssignments where MenuItemID=@MenuItemID"
            cmd = New OleDbCommand(ct)

            cmd.Connection = con
            cmd.Parameters.Add(New OleDbParameter("@MenuItemID", System.Data.OleDb.OleDbType.Integer, 20, "MenuItemID"))
            cmd.Parameters("@MenuItemID").Value = txtMenuItemID.Text
            RowsAffected = cmd.ExecuteNonQuery()
           


            Dim cq As String = "delete from MenuItems where MenuID=@MenuID;"


            cmd = New OleDbCommand(cq)

            cmd.Connection = con
            cmd.Parameters.Add(New OleDbParameter("@MenuID", System.Data.OleDb.OleDbType.Integer, 20, "MenuID"))
            cmd.Parameters("@MenuID").Value = Convert.ToInt32(Trim(txtMenuItemID.Text))
            RowsAffected = cmd.ExecuteNonQuery()

            If RowsAffected > 0 Then
                MessageBox.Show("Successfully deleted", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
                clear()
                btnMenuUpdate.Enabled = False
                btnMenuDelete.Enabled = False
                fillCategory()
                sugMenuItemNames()
            Else
                MessageBox.Show("No record found", "Sorry", MessageBoxButtons.OK, MessageBoxIcon.Information)
                'clear()
                btnMenuUpdate.Enabled = False
                btnMenuDelete.Enabled = False
            End If

            If con.State = ConnectionState.Open Then
                con.Close()
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Sub fillCategory()
        Dim conn As New OleDbConnection(SqlHelper.strConnect)
        Try
            conn.Open()
            adp = New OleDbDataAdapter()
            adp.SelectCommand = New OleDbCommand("SELECT CategoryID,CategoryName FROM ItemCategories", conn)
            ds = New DataSet("ds")
            cmbCategoryName.DataBindings.Clear()
            cmbCategoryName.DataSource = Nothing
            adp.Fill(ds)
            dtable = ds.Tables(0)

            With cmbCategoryName
                .DataSource = dtable
                .DisplayMember = "CategoryName"
                .ValueMember = "CategoryID"
                .SelectedIndex = -1
            End With

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            conn.Close()
        End Try
    End Sub


    Private Sub MenuItems_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Click on ok to navigate to main page?", "Are you sure to Exit?", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = Windows.Forms.DialogResult.OK Then
            'Me.Hide()
            clear()
            MainForm.Show()
        Else
            e.Cancel = True
        End If
    End Sub
    Private Sub MenuItems_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        fillCategory()
        clear()
        sugMenuItemNames()
    End Sub

    Private Sub btnSearchMenuItemID_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearchMenuItemID.Click
        Me.clear()
        
        MenuItemsRecord.dgvCategoryDetails.DataBindings.Clear()
        MenuItemsRecord.dgvCategoryDetails.DataSource = Nothing
        MenuItemsRecord.cmbCategory.Text = ""

        MenuItemsRecord.cmbInventoryName.Text = ""
        MenuItemsRecord.txtMenuItemName.Text = ""
        MenuItemsRecord.dgvMenuItemDetails.DataBindings.Clear()
        MenuItemsRecord.dgvMenuItemsData.DataBindings.Clear()
        MenuItemsRecord.dgvMenuItemDetails.DataSource = Nothing
        MenuItemsRecord.dgvMenuItemsData.DataSource = Nothing
        MenuItemsRecord.fillCategoryDetails()
        MenuItemsRecord.fillInventoryDetails()
        MenuItemsRecord.Show()
    End Sub

    Private Sub txtUnitPrice_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtUnitPrice.KeyPress
        Dim keyChar = e.KeyChar

        If Char.IsControl(keyChar) Then
            'Allow all control characters.
        ElseIf Char.IsDigit(keyChar) OrElse keyChar = "."c Then
            Dim text = Me.txtUnitPrice.Text
            Dim selectionStart = Me.txtUnitPrice.SelectionStart
            Dim selectionLength = Me.txtUnitPrice.SelectionLength

            text = text.Substring(0, selectionStart) & keyChar & text.Substring(selectionStart + selectionLength)

            If Integer.TryParse(text, New Integer) AndAlso text.Length > 16 Then
                'Reject an integer that is longer than 16 digits.
                e.Handled = True
            ElseIf Double.TryParse(text, New Double) AndAlso text.IndexOf("."c) < text.Length - 3 Then
                'Reject a real number with two many decimal places.
                e.Handled = False
            End If
        Else
            'Reject all other characters.
            e.Handled = True
        End If
    End Sub

    Private Sub chkMapMenuItem_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkMapMenuItem.CheckedChanged
        If chkMapMenuItem.Checked Then
            txtMenuItemID.Enabled = False
            txtMenuItemName.Enabled = False
            txtUnitPrice.Enabled = False
            cmbCategoryName.Enabled = False
            cmbCategoryName.SelectedText = ""
            btnSearchMenuItemID.Enabled = False
            ActionPanel.Enabled = False
            txtMenuName.Enabled = True
            txtInventoryName.Enabled = True
            txtQuantityNeeded.Enabled = True
            btnMenuItemID.Enabled = True
            btnInventoryID.Enabled = True
            btnMap.Enabled = True
            chkUnMap.Checked = False
            clear()
        Else

            txtMenuItemID.Enabled = False
            txtMenuItemName.Enabled = True
            txtUnitPrice.Enabled = True
            cmbCategoryName.Enabled = True
            btnSearchMenuItemID.Enabled = True
            ActionPanel.Enabled = True
            txtMenuName.Enabled = False
            txtInventoryName.Enabled = False
            txtQuantityNeeded.Enabled = False
            btnMenuItemID.Enabled = False
            btnInventoryID.Enabled = False
            btnMap.Enabled = False
            clear()
        End If
    End Sub
    Private Sub chkUnMap_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles chkUnMap.CheckedChanged
        If chkUnMap.Checked Then
            txtunMenuID.Enabled = False
            txtunInventoryID.Enabled = False
            txtMenuItemID.Enabled = False
            txtMenuItemName.Enabled = False
            txtUnitPrice.Enabled = False
            cmbCategoryName.Enabled = False
            cmbCategoryName.SelectedText = ""
            btnSearchMenuItemID.Enabled = False
            ActionPanel.Enabled = False
            txtMenuName.Enabled = False
            txtInventoryName.Enabled = False
            txtQuantityNeeded.Enabled = False
            btnMenuItemID.Enabled = False
            btnInventoryID.Enabled = False
            btnUnMap.Enabled = True
            btnGetItemDetails.Enabled = True
            chkMapMenuItem.Checked = False

            clear()
        Else

            txtMenuItemID.Enabled = False
            txtMenuItemName.Enabled = True
            txtUnitPrice.Enabled = True
            cmbCategoryName.Enabled = True
            btnSearchMenuItemID.Enabled = True
            ActionPanel.Enabled = True
            txtMenuName.Enabled = False
            txtInventoryName.Enabled = False
            txtQuantityNeeded.Enabled = False
            btnMenuItemID.Enabled = False
            btnInventoryID.Enabled = False
            btnMap.Enabled = False
            btnUnMap.Enabled = False
            btnGetItemDetails.Enabled = False

            clear()
        End If
    End Sub
    Private Sub btnMenuItemID_Click(sender As System.Object, e As System.EventArgs) Handles btnMenuItemID.Click
        MenuItemsRecord.selMenuItem("selMenuItemID")
        Me.Hide()
        MenuItemsRecord.Show()
    End Sub

    Private Sub btnInventoryID_Click(sender As System.Object, e As System.EventArgs) Handles btnInventoryID.Click
        InventoryItemsRecord.selInventoryName("selInventoryID")
        Me.Hide()
        InventoryItemsRecord.Show()
    End Sub

    Private Sub btnMap_Click(sender As System.Object, e As System.EventArgs) Handles btnMap.Click

        Dim RowsAffected As Integer = 0
        If Len(Trim(txtMenuName.Text)) = 0 Then
            MessageBox.Show("Please enter Menu Item using < button", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtMenuName.Focus()
            Exit Sub
        End If
        If Len(Trim(txtInventoryName.Text)) = 0 Then
            MessageBox.Show("Please enter Inventory Item using < button", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtInventoryName.Focus()
            Exit Sub
        End If

        If Len(Trim(txtQuantityNeeded.Text)) = 0 Then
            MessageBox.Show("Please enter Qunatity Needed", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtQuantityNeeded.Focus()
            Exit Sub
        End If


        Try
           
            con = New OleDbConnection(SqlHelper.strConnect)
            con.Open()
            Dim selMapDetails As String = "select MenuItemID,InventoryItemID from ItemAssignments where MenuItemID=@MenuID  AND  InventoryItemID = @InventoryItemID and IsDeleted = 0 "

            cmd = New OleDbCommand(selMapDetails)
            cmd.Connection = con
            cmd.Parameters.Add(New OleDbParameter("@MenuID", System.Data.OleDb.OleDbType.Integer, 20, "MenuID"))
            cmd.Parameters.Add(New OleDbParameter("@InventoryItemID", System.Data.OleDb.OleDbType.Integer, 20, "InventoryItemID"))
            cmd.Parameters("@MenuID").Value = selMenuID
            cmd.Parameters("@InventoryItemID").Value = selInventoryID
            rdr = cmd.ExecuteReader()

            If rdr.Read Then
                MessageBox.Show("Mappaing between Menu Name and Inventory Already Exists", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                If Not rdr Is Nothing Then
                    rdr.Close()
                End If
                Exit Sub
            Else

                Dim selMapDelete As String = "select MenuItemID,InventoryItemID from ItemAssignments where MenuItemID=@MenuID  AND  InventoryItemID = @InventoryItemID and IsDeleted = 1"

                cmd = New OleDbCommand(selMapDelete)
                cmd.Connection = con
                cmd.Parameters.Add(New OleDbParameter("@MenuID", System.Data.OleDb.OleDbType.Integer, 20, "MenuID"))
                cmd.Parameters.Add(New OleDbParameter("@InventoryItemID", System.Data.OleDb.OleDbType.Integer, 20, "InventoryItemID"))
                cmd.Parameters("@MenuID").Value = selMenuID
                cmd.Parameters("@InventoryItemID").Value = selInventoryID
                rdr = cmd.ExecuteReader()

                If rdr.Read Then
                    Dim updMapItems As String = "UPDATE ItemAssignments SET IsDeleted = 0 where MenuItemID=@MenuID  AND  InventoryItemID = @InventoryItemID and IsDeleted = 1"

                    cmd = New OleDbCommand(selMapDelete)
                    cmd.Connection = con
                    cmd.Parameters.Add(New OleDbParameter("@MenuID", System.Data.OleDb.OleDbType.Integer, 20, "MenuID"))
                    cmd.Parameters.Add(New OleDbParameter("@InventoryItemID", System.Data.OleDb.OleDbType.Integer, 20, "InventoryItemID"))
                    cmd.Parameters("@MenuID").Value = selMenuID
                    cmd.Parameters("@InventoryItemID").Value = selInventoryID
                    RowsAffected = cmd.ExecuteNonQuery()
                    MessageBox.Show("Successfully saved", "Menu Items Details", MessageBoxButtons.OK, MessageBoxIcon.Information)


                Else
                   

                    Dim cb As String = "insert into ItemAssignments(MenuItemID,InventoryItemID,Required_Qty, IsDeleted) VALUES (@ItemName,@CategoryID,@RequiredQty, 0)"

                    cmd = New OleDbCommand(cb)

                    cmd.Connection = con

                    cmd.Parameters.Add(New OleDbParameter("@MenuItemID", System.Data.OleDb.OleDbType.Integer, 11, "MenuItemID"))
                    cmd.Parameters.Add(New OleDbParameter("@InventoryItemID", System.Data.OleDb.OleDbType.Integer, 11, "InventoryItemID"))
                    cmd.Parameters.Add(New OleDbParameter("@RequiredQty", System.Data.OleDb.OleDbType.Integer, 11, "Required_Qty"))



                    cmd.Parameters("@MenuItemID").Value = selMenuID
                    cmd.Parameters("@InventoryItemID").Value = selInventoryID
                    cmd.Parameters("@RequiredQty").Value = Convert.ToInt32(txtQuantityNeeded.Text)


                    cmd.ExecuteReader()
                    MessageBox.Show("Successfully saved", "Menu Items Details", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    btnSaveMenuItem.Enabled = False
                    chkMapMenuItem.Checked = False

                    If con.State = ConnectionState.Open Then
                        con.Close()
                    End If

                    con.Close()
                    clear()
                End If
            End If



        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            If con.State = ConnectionState.Open Then
                con.Close()
            End If
            clear()
        End Try
    End Sub

    Private Sub btnHome_Click(sender As System.Object, e As System.EventArgs) Handles btnHome.Click
        If MessageBox.Show("Click on ok to navigate to main page?", "Are you sure to Exit?", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = Windows.Forms.DialogResult.OK Then
            Me.Hide()
            clear()
            MainForm.Show()
        End If
    End Sub

    Private Sub btnGetItemDetails_Click(sender As System.Object, e As System.EventArgs) Handles btnGetItemDetails.Click

        Me.Hide()
        MenuItemsUnMap.Show()

    End Sub

    Private Sub btnUnMap_Click(sender As System.Object, e As System.EventArgs) Handles btnUnMap.Click
        Dim RowsAffected As Integer = 0

        con = New OleDbConnection(SqlHelper.strConnect)
        con.Open()

        Dim ct As String = "UPDATE ItemAssignments set IsDeleted = 1 where MenuItemID=@MenuItemID and InventoryItemID = @InventoryID"
        cmd = New OleDbCommand(ct)

        cmd.Connection = con
        cmd.Parameters.Add(New OleDbParameter("@MenuItemID", System.Data.OleDb.OleDbType.Integer, 20, "MenuItemID"))
        cmd.Parameters.Add(New OleDbParameter("@InventoryID", System.Data.OleDb.OleDbType.Integer, 20, "InventoryItemID"))
        cmd.Parameters("@MenuItemID").Value = unmapMenuID
        cmd.Parameters("@InventoryID").Value = unmapInventoryID
        RowsAffected = cmd.ExecuteNonQuery()
        MessageBox.Show("Unmapping is successful")
        chkUnMap.Checked = False
    End Sub
End Class