﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MenuItemsUnMap
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuItemTabControl = New System.Windows.Forms.TabControl()
        Me.TabPage1 = New System.Windows.Forms.TabPage()
        Me.btnExportAll = New System.Windows.Forms.Button()
        Me.btnGetAll = New System.Windows.Forms.Button()
        Me.dgItemAssignmentsData = New System.Windows.Forms.DataGridView()
        Me.btnResetAll = New System.Windows.Forms.Button()
        Me.TabPage2 = New System.Windows.Forms.TabPage()
        Me.dgvGetbyMenuName = New System.Windows.Forms.DataGridView()
        Me.GroupBox10 = New System.Windows.Forms.GroupBox()
        Me.txtMenuItemName = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.GroupBox3 = New System.Windows.Forms.GroupBox()
        Me.btnInventoryExport = New System.Windows.Forms.Button()
        Me.btnResetInventory = New System.Windows.Forms.Button()
        Me.TabPage4 = New System.Windows.Forms.TabPage()
        Me.dgvGetbyInventoryName = New System.Windows.Forms.DataGridView()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnResetExport = New System.Windows.Forms.Button()
        Me.btnResetCategory = New System.Windows.Forms.Button()
        Me.GroupBox7 = New System.Windows.Forms.GroupBox()
        Me.txtInventoryName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.MenuItemTabControl.SuspendLayout()
        Me.TabPage1.SuspendLayout()
        CType(Me.dgItemAssignmentsData, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.TabPage2.SuspendLayout()
        CType(Me.dgvGetbyMenuName, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox10.SuspendLayout()
        Me.GroupBox3.SuspendLayout()
        Me.TabPage4.SuspendLayout()
        CType(Me.dgvGetbyInventoryName, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.GroupBox7.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuItemTabControl
        '
        Me.MenuItemTabControl.Controls.Add(Me.TabPage1)
        Me.MenuItemTabControl.Controls.Add(Me.TabPage2)
        Me.MenuItemTabControl.Controls.Add(Me.TabPage4)
        Me.MenuItemTabControl.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.MenuItemTabControl.Location = New System.Drawing.Point(2, 11)
        Me.MenuItemTabControl.Margin = New System.Windows.Forms.Padding(2)
        Me.MenuItemTabControl.Name = "MenuItemTabControl"
        Me.MenuItemTabControl.SelectedIndex = 0
        Me.MenuItemTabControl.Size = New System.Drawing.Size(573, 510)
        Me.MenuItemTabControl.TabIndex = 4
        '
        'TabPage1
        '
        Me.TabPage1.Controls.Add(Me.btnExportAll)
        Me.TabPage1.Controls.Add(Me.btnGetAll)
        Me.TabPage1.Controls.Add(Me.dgItemAssignmentsData)
        Me.TabPage1.Controls.Add(Me.btnResetAll)
        Me.TabPage1.Location = New System.Drawing.Point(4, 26)
        Me.TabPage1.Margin = New System.Windows.Forms.Padding(2)
        Me.TabPage1.Name = "TabPage1"
        Me.TabPage1.Padding = New System.Windows.Forms.Padding(2)
        Me.TabPage1.Size = New System.Drawing.Size(565, 480)
        Me.TabPage1.TabIndex = 0
        Me.TabPage1.Text = "All Data"
        Me.TabPage1.UseVisualStyleBackColor = True
        '
        'btnExportAll
        '
        Me.btnExportAll.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExportAll.Location = New System.Drawing.Point(157, 17)
        Me.btnExportAll.Margin = New System.Windows.Forms.Padding(2)
        Me.btnExportAll.Name = "btnExportAll"
        Me.btnExportAll.Size = New System.Drawing.Size(63, 26)
        Me.btnExportAll.TabIndex = 2
        Me.btnExportAll.Text = "&Export Excel"
        Me.btnExportAll.UseVisualStyleBackColor = True
        '
        'btnGetAll
        '
        Me.btnGetAll.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGetAll.Location = New System.Drawing.Point(11, 17)
        Me.btnGetAll.Margin = New System.Windows.Forms.Padding(2)
        Me.btnGetAll.Name = "btnGetAll"
        Me.btnGetAll.Size = New System.Drawing.Size(63, 26)
        Me.btnGetAll.TabIndex = 0
        Me.btnGetAll.Text = "&Get Data"
        Me.btnGetAll.UseVisualStyleBackColor = True
        '
        'dgItemAssignmentsData
        '
        Me.dgItemAssignmentsData.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgItemAssignmentsData.Location = New System.Drawing.Point(5, 61)
        Me.dgItemAssignmentsData.Margin = New System.Windows.Forms.Padding(2)
        Me.dgItemAssignmentsData.MultiSelect = False
        Me.dgItemAssignmentsData.Name = "dgItemAssignmentsData"
        Me.dgItemAssignmentsData.Size = New System.Drawing.Size(548, 309)
        Me.dgItemAssignmentsData.TabIndex = 32
        '
        'btnResetAll
        '
        Me.btnResetAll.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnResetAll.Location = New System.Drawing.Point(84, 17)
        Me.btnResetAll.Margin = New System.Windows.Forms.Padding(2)
        Me.btnResetAll.Name = "btnResetAll"
        Me.btnResetAll.Size = New System.Drawing.Size(63, 26)
        Me.btnResetAll.TabIndex = 1
        Me.btnResetAll.Text = "&Reset"
        Me.btnResetAll.UseVisualStyleBackColor = True
        '
        'TabPage2
        '
        Me.TabPage2.Controls.Add(Me.dgvGetbyMenuName)
        Me.TabPage2.Controls.Add(Me.GroupBox10)
        Me.TabPage2.Controls.Add(Me.GroupBox3)
        Me.TabPage2.Location = New System.Drawing.Point(4, 26)
        Me.TabPage2.Margin = New System.Windows.Forms.Padding(2)
        Me.TabPage2.Name = "TabPage2"
        Me.TabPage2.Padding = New System.Windows.Forms.Padding(2)
        Me.TabPage2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.TabPage2.Size = New System.Drawing.Size(565, 480)
        Me.TabPage2.TabIndex = 1
        Me.TabPage2.Text = "By Menu Item Name"
        Me.TabPage2.UseVisualStyleBackColor = True
        '
        'dgvGetbyMenuName
        '
        Me.dgvGetbyMenuName.AllowUserToAddRows = False
        Me.dgvGetbyMenuName.AllowUserToDeleteRows = False
        Me.dgvGetbyMenuName.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvGetbyMenuName.Location = New System.Drawing.Point(5, 63)
        Me.dgvGetbyMenuName.Margin = New System.Windows.Forms.Padding(2)
        Me.dgvGetbyMenuName.MultiSelect = False
        Me.dgvGetbyMenuName.Name = "dgvGetbyMenuName"
        Me.dgvGetbyMenuName.ReadOnly = True
        Me.dgvGetbyMenuName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.dgvGetbyMenuName.Size = New System.Drawing.Size(552, 309)
        Me.dgvGetbyMenuName.TabIndex = 35
        '
        'GroupBox10
        '
        Me.GroupBox10.Controls.Add(Me.txtMenuItemName)
        Me.GroupBox10.Controls.Add(Me.Label6)
        Me.GroupBox10.Location = New System.Drawing.Point(5, 4)
        Me.GroupBox10.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox10.Name = "GroupBox10"
        Me.GroupBox10.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox10.Size = New System.Drawing.Size(185, 57)
        Me.GroupBox10.TabIndex = 34
        Me.GroupBox10.TabStop = False
        '
        'txtMenuItemName
        '
        Me.txtMenuItemName.Location = New System.Drawing.Point(16, 29)
        Me.txtMenuItemName.Margin = New System.Windows.Forms.Padding(2)
        Me.txtMenuItemName.Name = "txtMenuItemName"
        Me.txtMenuItemName.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.txtMenuItemName.Size = New System.Drawing.Size(155, 24)
        Me.txtMenuItemName.TabIndex = 7
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(14, 10)
        Me.Label6.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(107, 18)
        Me.Label6.TabIndex = 6
        Me.Label6.Text = "Search by Name"
        '
        'GroupBox3
        '
        Me.GroupBox3.Controls.Add(Me.btnInventoryExport)
        Me.GroupBox3.Controls.Add(Me.btnResetInventory)
        Me.GroupBox3.Location = New System.Drawing.Point(229, 4)
        Me.GroupBox3.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox3.Name = "GroupBox3"
        Me.GroupBox3.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox3.Size = New System.Drawing.Size(149, 57)
        Me.GroupBox3.TabIndex = 33
        Me.GroupBox3.TabStop = False
        '
        'btnInventoryExport
        '
        Me.btnInventoryExport.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnInventoryExport.Location = New System.Drawing.Point(77, 17)
        Me.btnInventoryExport.Margin = New System.Windows.Forms.Padding(2)
        Me.btnInventoryExport.Name = "btnInventoryExport"
        Me.btnInventoryExport.Size = New System.Drawing.Size(63, 26)
        Me.btnInventoryExport.TabIndex = 2
        Me.btnInventoryExport.Text = "&Export Excel"
        Me.btnInventoryExport.UseVisualStyleBackColor = True
        '
        'btnResetInventory
        '
        Me.btnResetInventory.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnResetInventory.Location = New System.Drawing.Point(11, 17)
        Me.btnResetInventory.Margin = New System.Windows.Forms.Padding(2)
        Me.btnResetInventory.Name = "btnResetInventory"
        Me.btnResetInventory.Size = New System.Drawing.Size(63, 26)
        Me.btnResetInventory.TabIndex = 1
        Me.btnResetInventory.Text = "&Reset"
        Me.btnResetInventory.UseVisualStyleBackColor = True
        '
        'TabPage4
        '
        Me.TabPage4.Controls.Add(Me.dgvGetbyInventoryName)
        Me.TabPage4.Controls.Add(Me.GroupBox2)
        Me.TabPage4.Controls.Add(Me.GroupBox7)
        Me.TabPage4.Location = New System.Drawing.Point(4, 26)
        Me.TabPage4.Margin = New System.Windows.Forms.Padding(2)
        Me.TabPage4.Name = "TabPage4"
        Me.TabPage4.Padding = New System.Windows.Forms.Padding(2)
        Me.TabPage4.Size = New System.Drawing.Size(565, 480)
        Me.TabPage4.TabIndex = 3
        Me.TabPage4.Text = "By Inventory Name"
        Me.TabPage4.UseVisualStyleBackColor = True
        '
        'dgvGetbyInventoryName
        '
        Me.dgvGetbyInventoryName.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvGetbyInventoryName.Location = New System.Drawing.Point(5, 63)
        Me.dgvGetbyInventoryName.Margin = New System.Windows.Forms.Padding(2)
        Me.dgvGetbyInventoryName.MultiSelect = False
        Me.dgvGetbyInventoryName.Name = "dgvGetbyInventoryName"
        Me.dgvGetbyInventoryName.Size = New System.Drawing.Size(549, 309)
        Me.dgvGetbyInventoryName.TabIndex = 34
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnResetExport)
        Me.GroupBox2.Controls.Add(Me.btnResetCategory)
        Me.GroupBox2.Location = New System.Drawing.Point(239, 4)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(153, 57)
        Me.GroupBox2.TabIndex = 32
        Me.GroupBox2.TabStop = False
        '
        'btnResetExport
        '
        Me.btnResetExport.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnResetExport.Location = New System.Drawing.Point(78, 19)
        Me.btnResetExport.Margin = New System.Windows.Forms.Padding(2)
        Me.btnResetExport.Name = "btnResetExport"
        Me.btnResetExport.Size = New System.Drawing.Size(63, 26)
        Me.btnResetExport.TabIndex = 2
        Me.btnResetExport.Text = "&Export Excel"
        Me.btnResetExport.UseVisualStyleBackColor = True
        '
        'btnResetCategory
        '
        Me.btnResetCategory.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnResetCategory.Location = New System.Drawing.Point(11, 19)
        Me.btnResetCategory.Margin = New System.Windows.Forms.Padding(2)
        Me.btnResetCategory.Name = "btnResetCategory"
        Me.btnResetCategory.Size = New System.Drawing.Size(63, 26)
        Me.btnResetCategory.TabIndex = 1
        Me.btnResetCategory.Text = "&Reset"
        Me.btnResetCategory.UseVisualStyleBackColor = True
        '
        'GroupBox7
        '
        Me.GroupBox7.Controls.Add(Me.txtInventoryName)
        Me.GroupBox7.Controls.Add(Me.Label3)
        Me.GroupBox7.Location = New System.Drawing.Point(5, 4)
        Me.GroupBox7.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox7.Name = "GroupBox7"
        Me.GroupBox7.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox7.Size = New System.Drawing.Size(219, 57)
        Me.GroupBox7.TabIndex = 31
        Me.GroupBox7.TabStop = False
        '
        'txtInventoryName
        '
        Me.txtInventoryName.Location = New System.Drawing.Point(23, 24)
        Me.txtInventoryName.Name = "txtInventoryName"
        Me.txtInventoryName.Size = New System.Drawing.Size(164, 24)
        Me.txtInventoryName.TabIndex = 10
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("Palatino Linotype", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label3.Location = New System.Drawing.Point(4, 0)
        Me.Label3.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(125, 21)
        Me.Label3.TabIndex = 9
        Me.Label3.Text = "Search by Name"
        '
        'MenuItemsUnMap
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(577, 529)
        Me.Controls.Add(Me.MenuItemTabControl)
        Me.Name = "MenuItemsUnMap"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Menu Items UnMap"
        Me.MenuItemTabControl.ResumeLayout(False)
        Me.TabPage1.ResumeLayout(False)
        CType(Me.dgItemAssignmentsData, System.ComponentModel.ISupportInitialize).EndInit()
        Me.TabPage2.ResumeLayout(False)
        CType(Me.dgvGetbyMenuName, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox10.ResumeLayout(False)
        Me.GroupBox10.PerformLayout()
        Me.GroupBox3.ResumeLayout(False)
        Me.TabPage4.ResumeLayout(False)
        CType(Me.dgvGetbyInventoryName, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.GroupBox7.ResumeLayout(False)
        Me.GroupBox7.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents MenuItemTabControl As System.Windows.Forms.TabControl
    Friend WithEvents TabPage1 As System.Windows.Forms.TabPage
    Friend WithEvents btnExportAll As System.Windows.Forms.Button
    Friend WithEvents btnGetAll As System.Windows.Forms.Button
    Friend WithEvents dgItemAssignmentsData As System.Windows.Forms.DataGridView
    Friend WithEvents btnResetAll As System.Windows.Forms.Button
    Friend WithEvents TabPage2 As System.Windows.Forms.TabPage
    Friend WithEvents dgvGetbyMenuName As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox10 As System.Windows.Forms.GroupBox
    Friend WithEvents txtMenuItemName As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents GroupBox3 As System.Windows.Forms.GroupBox
    Friend WithEvents btnInventoryExport As System.Windows.Forms.Button
    Friend WithEvents btnResetInventory As System.Windows.Forms.Button
    Friend WithEvents TabPage4 As System.Windows.Forms.TabPage
    Friend WithEvents dgvGetbyInventoryName As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnResetExport As System.Windows.Forms.Button
    Friend WithEvents btnResetCategory As System.Windows.Forms.Button
    Friend WithEvents GroupBox7 As System.Windows.Forms.GroupBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtInventoryName As System.Windows.Forms.TextBox
End Class
