﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PromoDetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.dgvPromoDetails = New System.Windows.Forms.DataGridView()
        Me.GroupBox2 = New System.Windows.Forms.GroupBox()
        Me.btnGetPromoDetails = New System.Windows.Forms.Button()
        Me.btnExport = New System.Windows.Forms.Button()
        Me.btnResetPromo = New System.Windows.Forms.Button()
        Me.cmbPromoStatus = New System.Windows.Forms.ComboBox()
        Me.Label1 = New System.Windows.Forms.Label()
        CType(Me.dgvPromoDetails, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.GroupBox2.SuspendLayout()
        Me.SuspendLayout()
        '
        'dgvPromoDetails
        '
        Me.dgvPromoDetails.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvPromoDetails.Location = New System.Drawing.Point(1, 68)
        Me.dgvPromoDetails.Margin = New System.Windows.Forms.Padding(2)
        Me.dgvPromoDetails.MultiSelect = False
        Me.dgvPromoDetails.Name = "dgvPromoDetails"
        Me.dgvPromoDetails.Size = New System.Drawing.Size(549, 309)
        Me.dgvPromoDetails.TabIndex = 35
        '
        'GroupBox2
        '
        Me.GroupBox2.Controls.Add(Me.btnGetPromoDetails)
        Me.GroupBox2.Controls.Add(Me.btnExport)
        Me.GroupBox2.Controls.Add(Me.btnResetPromo)
        Me.GroupBox2.Location = New System.Drawing.Point(283, 8)
        Me.GroupBox2.Margin = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Name = "GroupBox2"
        Me.GroupBox2.Padding = New System.Windows.Forms.Padding(2)
        Me.GroupBox2.Size = New System.Drawing.Size(256, 57)
        Me.GroupBox2.TabIndex = 36
        Me.GroupBox2.TabStop = False
        '
        'btnGetPromoDetails
        '
        Me.btnGetPromoDetails.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnGetPromoDetails.Location = New System.Drawing.Point(18, 19)
        Me.btnGetPromoDetails.Margin = New System.Windows.Forms.Padding(2)
        Me.btnGetPromoDetails.Name = "btnGetPromoDetails"
        Me.btnGetPromoDetails.Size = New System.Drawing.Size(63, 26)
        Me.btnGetPromoDetails.TabIndex = 3
        Me.btnGetPromoDetails.Text = "&Get Data"
        Me.btnGetPromoDetails.UseVisualStyleBackColor = True
        '
        'btnExport
        '
        Me.btnExport.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnExport.Location = New System.Drawing.Point(175, 19)
        Me.btnExport.Margin = New System.Windows.Forms.Padding(2)
        Me.btnExport.Name = "btnExport"
        Me.btnExport.Size = New System.Drawing.Size(63, 26)
        Me.btnExport.TabIndex = 2
        Me.btnExport.Text = "&Go to Order"
        Me.btnExport.UseVisualStyleBackColor = True
        '
        'btnResetPromo
        '
        Me.btnResetPromo.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnResetPromo.Location = New System.Drawing.Point(95, 19)
        Me.btnResetPromo.Margin = New System.Windows.Forms.Padding(2)
        Me.btnResetPromo.Name = "btnResetPromo"
        Me.btnResetPromo.Size = New System.Drawing.Size(63, 26)
        Me.btnResetPromo.TabIndex = 1
        Me.btnResetPromo.Text = "&Reset"
        Me.btnResetPromo.UseVisualStyleBackColor = True
        '
        'cmbPromoStatus
        '
        Me.cmbPromoStatus.FormattingEnabled = True
        Me.cmbPromoStatus.Items.AddRange(New Object() {"Active", "InActive"})
        Me.cmbPromoStatus.Location = New System.Drawing.Point(133, 27)
        Me.cmbPromoStatus.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbPromoStatus.Name = "cmbPromoStatus"
        Me.cmbPromoStatus.Size = New System.Drawing.Size(96, 21)
        Me.cmbPromoStatus.TabIndex = 37
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(39, 27)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(82, 17)
        Me.Label1.TabIndex = 38
        Me.Label1.Text = "Promo Status"
        '
        'PromoDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(547, 374)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmbPromoStatus)
        Me.Controls.Add(Me.GroupBox2)
        Me.Controls.Add(Me.dgvPromoDetails)
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "PromoDetails"
        Me.Text = "PromoDetails"
        CType(Me.dgvPromoDetails, System.ComponentModel.ISupportInitialize).EndInit()
        Me.GroupBox2.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents dgvPromoDetails As System.Windows.Forms.DataGridView
    Friend WithEvents GroupBox2 As System.Windows.Forms.GroupBox
    Friend WithEvents btnExport As System.Windows.Forms.Button
    Friend WithEvents btnResetPromo As System.Windows.Forms.Button
    Friend WithEvents btnGetPromoDetails As System.Windows.Forms.Button
    Friend WithEvents cmbPromoStatus As System.Windows.Forms.ComboBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
End Class
