﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MenuItems
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.ActionPanel = New System.Windows.Forms.Panel()
        Me.btnNewMenuItem = New System.Windows.Forms.Button()
        Me.btnMenuDelete = New System.Windows.Forms.Button()
        Me.btnSaveMenuItem = New System.Windows.Forms.Button()
        Me.btnMenuUpdate = New System.Windows.Forms.Button()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.btnUnMap = New System.Windows.Forms.Button()
        Me.chkUnMap = New System.Windows.Forms.CheckBox()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.txtunInventoryID = New System.Windows.Forms.TextBox()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.btnGetItemDetails = New System.Windows.Forms.Button()
        Me.txtunMenuID = New System.Windows.Forms.TextBox()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.btnMap = New System.Windows.Forms.Button()
        Me.chkMapMenuItem = New System.Windows.Forms.CheckBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtQuantityNeeded = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.btnInventoryID = New System.Windows.Forms.Button()
        Me.txtInventoryName = New System.Windows.Forms.TextBox()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.btnMenuItemID = New System.Windows.Forms.Button()
        Me.txtMenuName = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.txtUnitPrice = New System.Windows.Forms.TextBox()
        Me.btnSearchMenuItemID = New System.Windows.Forms.Button()
        Me.cmbCategoryName = New System.Windows.Forms.ComboBox()
        Me.txtMenuItemName = New System.Windows.Forms.TextBox()
        Me.txtMenuItemID = New System.Windows.Forms.TextBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.btnHome = New System.Windows.Forms.Button()
        Me.ActionPanel.SuspendLayout()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'ActionPanel
        '
        Me.ActionPanel.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.ActionPanel.Controls.Add(Me.btnNewMenuItem)
        Me.ActionPanel.Controls.Add(Me.btnMenuDelete)
        Me.ActionPanel.Controls.Add(Me.btnSaveMenuItem)
        Me.ActionPanel.Controls.Add(Me.btnMenuUpdate)
        Me.ActionPanel.Location = New System.Drawing.Point(747, 53)
        Me.ActionPanel.Name = "ActionPanel"
        Me.ActionPanel.Size = New System.Drawing.Size(101, 164)
        Me.ActionPanel.TabIndex = 3
        '
        'btnNewMenuItem
        '
        Me.btnNewMenuItem.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnNewMenuItem.Location = New System.Drawing.Point(11, 12)
        Me.btnNewMenuItem.Name = "btnNewMenuItem"
        Me.btnNewMenuItem.Size = New System.Drawing.Size(75, 29)
        Me.btnNewMenuItem.TabIndex = 0
        Me.btnNewMenuItem.Text = "&New"
        Me.btnNewMenuItem.UseVisualStyleBackColor = True
        '
        'btnMenuDelete
        '
        Me.btnMenuDelete.Enabled = False
        Me.btnMenuDelete.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMenuDelete.Location = New System.Drawing.Point(11, 121)
        Me.btnMenuDelete.Name = "btnMenuDelete"
        Me.btnMenuDelete.Size = New System.Drawing.Size(75, 29)
        Me.btnMenuDelete.TabIndex = 3
        Me.btnMenuDelete.Text = "&Delete"
        Me.btnMenuDelete.UseVisualStyleBackColor = True
        '
        'btnSaveMenuItem
        '
        Me.btnSaveMenuItem.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSaveMenuItem.Location = New System.Drawing.Point(11, 50)
        Me.btnSaveMenuItem.Name = "btnSaveMenuItem"
        Me.btnSaveMenuItem.Size = New System.Drawing.Size(75, 29)
        Me.btnSaveMenuItem.TabIndex = 1
        Me.btnSaveMenuItem.Text = "&Save"
        Me.btnSaveMenuItem.UseVisualStyleBackColor = True
        '
        'btnMenuUpdate
        '
        Me.btnMenuUpdate.Enabled = False
        Me.btnMenuUpdate.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMenuUpdate.Location = New System.Drawing.Point(11, 86)
        Me.btnMenuUpdate.Name = "btnMenuUpdate"
        Me.btnMenuUpdate.Size = New System.Drawing.Size(75, 29)
        Me.btnMenuUpdate.TabIndex = 2
        Me.btnMenuUpdate.Text = "&Update"
        Me.btnMenuUpdate.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.btnUnMap)
        Me.GroupBox1.Controls.Add(Me.chkUnMap)
        Me.GroupBox1.Controls.Add(Me.Label9)
        Me.GroupBox1.Controls.Add(Me.txtunInventoryID)
        Me.GroupBox1.Controls.Add(Me.Label11)
        Me.GroupBox1.Controls.Add(Me.btnGetItemDetails)
        Me.GroupBox1.Controls.Add(Me.txtunMenuID)
        Me.GroupBox1.Controls.Add(Me.Label12)
        Me.GroupBox1.Controls.Add(Me.btnMap)
        Me.GroupBox1.Controls.Add(Me.chkMapMenuItem)
        Me.GroupBox1.Controls.Add(Me.Label7)
        Me.GroupBox1.Controls.Add(Me.txtQuantityNeeded)
        Me.GroupBox1.Controls.Add(Me.Label6)
        Me.GroupBox1.Controls.Add(Me.btnInventoryID)
        Me.GroupBox1.Controls.Add(Me.txtInventoryName)
        Me.GroupBox1.Controls.Add(Me.Label5)
        Me.GroupBox1.Controls.Add(Me.btnMenuItemID)
        Me.GroupBox1.Controls.Add(Me.txtMenuName)
        Me.GroupBox1.Controls.Add(Me.Label3)
        Me.GroupBox1.Controls.Add(Me.txtUnitPrice)
        Me.GroupBox1.Controls.Add(Me.btnSearchMenuItemID)
        Me.GroupBox1.Controls.Add(Me.cmbCategoryName)
        Me.GroupBox1.Controls.Add(Me.txtMenuItemName)
        Me.GroupBox1.Controls.Add(Me.txtMenuItemID)
        Me.GroupBox1.Controls.Add(Me.Label4)
        Me.GroupBox1.Controls.Add(Me.Label8)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(38, 39)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(626, 528)
        Me.GroupBox1.TabIndex = 2
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "Menu Item Details"
        '
        'btnUnMap
        '
        Me.btnUnMap.Enabled = False
        Me.btnUnMap.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnUnMap.Location = New System.Drawing.Point(383, 446)
        Me.btnUnMap.Name = "btnUnMap"
        Me.btnUnMap.Size = New System.Drawing.Size(75, 29)
        Me.btnUnMap.TabIndex = 33
        Me.btnUnMap.Text = "&Un Map"
        Me.btnUnMap.UseVisualStyleBackColor = True
        '
        'chkUnMap
        '
        Me.chkUnMap.AutoSize = True
        Me.chkUnMap.Location = New System.Drawing.Point(7, 367)
        Me.chkUnMap.Name = "chkUnMap"
        Me.chkUnMap.Size = New System.Drawing.Size(132, 21)
        Me.chkUnMap.TabIndex = 32
        Me.chkUnMap.Text = "UnMap Menu Item"
        Me.chkUnMap.UseVisualStyleBackColor = True
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(15, 367)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(94, 17)
        Me.Label9.TabIndex = 31
        Me.Label9.Text = "Map MenuItem"
        '
        'txtunInventoryID
        '
        Me.txtunInventoryID.Enabled = False
        Me.txtunInventoryID.Location = New System.Drawing.Point(143, 446)
        Me.txtunInventoryID.Name = "txtunInventoryID"
        Me.txtunInventoryID.ReadOnly = True
        Me.txtunInventoryID.Size = New System.Drawing.Size(189, 24)
        Me.txtunInventoryID.TabIndex = 27
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(12, 448)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(81, 17)
        Me.Label11.TabIndex = 26
        Me.Label11.Text = "Inventory ID"
        '
        'btnGetItemDetails
        '
        Me.btnGetItemDetails.Enabled = False
        Me.btnGetItemDetails.Location = New System.Drawing.Point(341, 409)
        Me.btnGetItemDetails.Name = "btnGetItemDetails"
        Me.btnGetItemDetails.Size = New System.Drawing.Size(29, 25)
        Me.btnGetItemDetails.TabIndex = 25
        Me.btnGetItemDetails.Text = "<"
        Me.btnGetItemDetails.UseVisualStyleBackColor = True
        '
        'txtunMenuID
        '
        Me.txtunMenuID.Enabled = False
        Me.txtunMenuID.Location = New System.Drawing.Point(143, 410)
        Me.txtunMenuID.Name = "txtunMenuID"
        Me.txtunMenuID.ReadOnly = True
        Me.txtunMenuID.Size = New System.Drawing.Size(189, 24)
        Me.txtunMenuID.TabIndex = 24
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(12, 412)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(87, 17)
        Me.Label12.TabIndex = 23
        Me.Label12.Text = "Menu Item ID"
        '
        'btnMap
        '
        Me.btnMap.Enabled = False
        Me.btnMap.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnMap.Location = New System.Drawing.Point(383, 319)
        Me.btnMap.Name = "btnMap"
        Me.btnMap.Size = New System.Drawing.Size(75, 29)
        Me.btnMap.TabIndex = 22
        Me.btnMap.Text = "&Map"
        Me.btnMap.UseVisualStyleBackColor = True
        '
        'chkMapMenuItem
        '
        Me.chkMapMenuItem.AutoSize = True
        Me.chkMapMenuItem.Location = New System.Drawing.Point(7, 196)
        Me.chkMapMenuItem.Name = "chkMapMenuItem"
        Me.chkMapMenuItem.Size = New System.Drawing.Size(116, 21)
        Me.chkMapMenuItem.TabIndex = 21
        Me.chkMapMenuItem.Text = "Map Menu Item"
        Me.chkMapMenuItem.UseVisualStyleBackColor = True
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(15, 196)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(94, 17)
        Me.Label7.TabIndex = 20
        Me.Label7.Text = "Map MenuItem"
        '
        'txtQuantityNeeded
        '
        Me.txtQuantityNeeded.Enabled = False
        Me.txtQuantityNeeded.Location = New System.Drawing.Point(143, 319)
        Me.txtQuantityNeeded.Name = "txtQuantityNeeded"
        Me.txtQuantityNeeded.Size = New System.Drawing.Size(189, 24)
        Me.txtQuantityNeeded.TabIndex = 18
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(12, 319)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(101, 17)
        Me.Label6.TabIndex = 19
        Me.Label6.Text = "Quantity Needed"
        '
        'btnInventoryID
        '
        Me.btnInventoryID.Enabled = False
        Me.btnInventoryID.Location = New System.Drawing.Point(341, 274)
        Me.btnInventoryID.Name = "btnInventoryID"
        Me.btnInventoryID.Size = New System.Drawing.Size(29, 25)
        Me.btnInventoryID.TabIndex = 17
        Me.btnInventoryID.Text = "<"
        Me.btnInventoryID.UseVisualStyleBackColor = True
        '
        'txtInventoryName
        '
        Me.txtInventoryName.Enabled = False
        Me.txtInventoryName.Location = New System.Drawing.Point(143, 275)
        Me.txtInventoryName.Name = "txtInventoryName"
        Me.txtInventoryName.ReadOnly = True
        Me.txtInventoryName.Size = New System.Drawing.Size(189, 24)
        Me.txtInventoryName.TabIndex = 16
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(12, 277)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(81, 17)
        Me.Label5.TabIndex = 15
        Me.Label5.Text = "Inventory ID"
        '
        'btnMenuItemID
        '
        Me.btnMenuItemID.Enabled = False
        Me.btnMenuItemID.Location = New System.Drawing.Point(341, 238)
        Me.btnMenuItemID.Name = "btnMenuItemID"
        Me.btnMenuItemID.Size = New System.Drawing.Size(29, 25)
        Me.btnMenuItemID.TabIndex = 14
        Me.btnMenuItemID.Text = "<"
        Me.btnMenuItemID.UseVisualStyleBackColor = True
        '
        'txtMenuName
        '
        Me.txtMenuName.Enabled = False
        Me.txtMenuName.Location = New System.Drawing.Point(143, 239)
        Me.txtMenuName.Name = "txtMenuName"
        Me.txtMenuName.ReadOnly = True
        Me.txtMenuName.Size = New System.Drawing.Size(189, 24)
        Me.txtMenuName.TabIndex = 13
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(12, 241)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(87, 17)
        Me.Label3.TabIndex = 12
        Me.Label3.Text = "Menu Item ID"
        '
        'txtUnitPrice
        '
        Me.txtUnitPrice.Location = New System.Drawing.Point(143, 136)
        Me.txtUnitPrice.Name = "txtUnitPrice"
        Me.txtUnitPrice.Size = New System.Drawing.Size(91, 24)
        Me.txtUnitPrice.TabIndex = 3
        '
        'btnSearchMenuItemID
        '
        Me.btnSearchMenuItemID.Location = New System.Drawing.Point(341, 30)
        Me.btnSearchMenuItemID.Name = "btnSearchMenuItemID"
        Me.btnSearchMenuItemID.Size = New System.Drawing.Size(29, 25)
        Me.btnSearchMenuItemID.TabIndex = 5
        Me.btnSearchMenuItemID.Text = "<"
        Me.btnSearchMenuItemID.UseVisualStyleBackColor = True
        '
        'cmbCategoryName
        '
        Me.cmbCategoryName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.Suggest
        Me.cmbCategoryName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.ListItems
        Me.cmbCategoryName.FormattingEnabled = True
        Me.cmbCategoryName.Location = New System.Drawing.Point(143, 99)
        Me.cmbCategoryName.Name = "cmbCategoryName"
        Me.cmbCategoryName.Size = New System.Drawing.Size(302, 25)
        Me.cmbCategoryName.TabIndex = 1
        '
        'txtMenuItemName
        '
        Me.txtMenuItemName.Location = New System.Drawing.Point(143, 65)
        Me.txtMenuItemName.Name = "txtMenuItemName"
        Me.txtMenuItemName.Size = New System.Drawing.Size(376, 24)
        Me.txtMenuItemName.TabIndex = 0
        '
        'txtMenuItemID
        '
        Me.txtMenuItemID.Location = New System.Drawing.Point(143, 31)
        Me.txtMenuItemID.Name = "txtMenuItemID"
        Me.txtMenuItemID.ReadOnly = True
        Me.txtMenuItemID.Size = New System.Drawing.Size(189, 24)
        Me.txtMenuItemID.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(12, 101)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(95, 17)
        Me.Label4.TabIndex = 11
        Me.Label4.Text = "Category Name"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(12, 139)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(61, 17)
        Me.Label8.TabIndex = 10
        Me.Label8.Text = "Unit Price"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(12, 65)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(105, 17)
        Me.Label2.TabIndex = 1
        Me.Label2.Text = "Menu Item Name"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(12, 33)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(87, 17)
        Me.Label1.TabIndex = 0
        Me.Label1.Text = "Menu Item ID"
        '
        'btnHome
        '
        Me.btnHome.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHome.Location = New System.Drawing.Point(759, 503)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(129, 29)
        Me.btnHome.TabIndex = 5
        Me.btnHome.Text = "&Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'MenuItems
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(923, 602)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.ActionPanel)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "MenuItems"
        Me.Text = "MenuItems"
        Me.ActionPanel.ResumeLayout(False)
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ActionPanel As System.Windows.Forms.Panel
    Friend WithEvents btnNewMenuItem As System.Windows.Forms.Button
    Friend WithEvents btnMenuDelete As System.Windows.Forms.Button
    Friend WithEvents btnSaveMenuItem As System.Windows.Forms.Button
    Friend WithEvents btnMenuUpdate As System.Windows.Forms.Button
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtUnitPrice As System.Windows.Forms.TextBox
    Friend WithEvents btnSearchMenuItemID As System.Windows.Forms.Button
    Friend WithEvents cmbCategoryName As System.Windows.Forms.ComboBox
    Friend WithEvents txtMenuItemName As System.Windows.Forms.TextBox
    Friend WithEvents txtMenuItemID As System.Windows.Forms.TextBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents btnInventoryID As System.Windows.Forms.Button
    Friend WithEvents txtInventoryName As System.Windows.Forms.TextBox
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents btnMenuItemID As System.Windows.Forms.Button
    Friend WithEvents txtMenuName As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents txtQuantityNeeded As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents chkMapMenuItem As System.Windows.Forms.CheckBox
    Friend WithEvents btnMap As System.Windows.Forms.Button
    Friend WithEvents btnHome As System.Windows.Forms.Button
    Friend WithEvents btnUnMap As System.Windows.Forms.Button
    Friend WithEvents chkUnMap As System.Windows.Forms.CheckBox
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents txtunInventoryID As System.Windows.Forms.TextBox
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents btnGetItemDetails As System.Windows.Forms.Button
    Friend WithEvents txtunMenuID As System.Windows.Forms.TextBox
    Friend WithEvents Label12 As System.Windows.Forms.Label
End Class
