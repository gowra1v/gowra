﻿Public Class EmployeeTodo
    Dim sqlHelper As SqlHelper
    Dim NewUserName As String
    Dim NewUserPassword As String
    Dim NewUserFirstName As String
    Dim NewUserLastName As String
    Dim NewUserDateOfBirth As Date
    Dim NewUserAddress As String
    Dim NewUserCity As String
    Dim NewUserState As String
    Dim NewUserCountry As String
    Dim NewUserZipCode As String
    Dim NewUserEmailID As String
    Dim NewUserMobileNumber As String
    Dim NewUserType As String

    Public Sub New()

    End Sub
    Public Sub New(ByVal UserName As String, ByVal UserPassword As String, ByVal UserFirstName As String, ByVal UserLastName As String, ByVal UserDateOfBirth As Date, ByVal UserAddress As String, ByVal UserCity As String, ByVal UserState As String, ByVal UserCountry As String, ByVal UserZipCode As String, ByVal UserEmailID As String, ByVal UserMobileNumber As String, Optional ByVal UserType As String = "Cashier")
        NewUserName = UserName
        NewUserPassword = UserPassword
        NewUserFirstName = UserFirstName
        NewUserLastName = UserLastName
        NewUserDateOfBirth = UserDateOfBirth
        NewUserAddress = UserAddress
        NewUserCity = UserCity
        NewUserState = UserState
        NewUserCountry = UserCountry
        NewUserZipCode = UserZipCode
        NewUserEmailID = UserEmailID
        NewUserMobileNumber = UserMobileNumber
        NewUserType = "Admin"
    End Sub

    Public Function insertUserLoginDetails() As Integer
        Dim insertStatus As Integer = 0
        Try
            Dim sqlQuery As String
            sqlHelper = New SqlHelper()
            sqlQuery = "INSERT INTO Login (UserName, Password, UserType) VALUES ('" & NewUserName & "','" & NewUserPassword & "','" & NewUserType & "')"
            insertStatus = sqlHelper.ExecuteInsUpdDel(sqlQuery, True)
            If insertStatus > 0 Then
                sqlQuery = "INSERT INTO Employee (FirstName,LastName,DateOfBirth,Address,City, State,ZIPCode, Country, EmailID,MobileNumber) VALUES ( '" & NewUserName & "', '" & NewUserPassword & "', '" & NewUserFirstName & "', '" & NewUserLastName & "','" & NewUserDateOfBirth & "', '" & NewUserAddress & "', '" & NewUserCity & "', '" & NewUserState & "','" & NewUserCountry & "', " & Integer.Parse(NewUserZipCode) & ", '" & NewUserEmailID & "','" & NewUserMobileNumber & "' )"
                insertStatus = sqlHelper.ExecuteInsUpdDel(sqlQuery, True)
            End If
        Catch ex As Exception
            MessageBox.Show("New User details are not saved successfully. Please try again to save details", "New User Details", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        Return insertStatus

    End Function

    Public Function GetUserLoginDetails(ByVal UserName As String, ByVal Password As String, ByVal Role As String) As DataTable
        Dim dtLoginDetails As DataTable = Nothing
        Try
            Dim selectQuery As String
            sqlHelper = New SqlHelper()
            selectQuery = "Select * from Login where UserName ='" & UserName & "' and Password ='" & Password & "' "
            'and UserType='" & Role & "'"
            dtLoginDetails = sqlHelper.ExecuteSelectTable(selectQuery)
        Catch ex As Exception

        End Try
        Return dtLoginDetails
    End Function
    Public Function ValidateUser(ByVal UserName As String) As Boolean
        Dim dtLoginDetails As DataTable
        Dim valid As Boolean = False
        Try
            Dim selectQuery As String
            sqlHelper = New SqlHelper()
            selectQuery = "Select * from Login where LCase(UserName) ='" & UserName.ToLower() & "'"
            dtLoginDetails = sqlHelper.ExecuteSelectTable(selectQuery)
            If dtLoginDetails.Rows.Count > 0 Then
                valid = False
            Else
                valid = True
            End If
            Return valid
        Catch ex As Exception

        End Try
        Return valid
        'Return dtLoginDetails
    End Function
End Class
