﻿Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel

Public Class MenuItemsUnMap

    Dim rdr As OleDbDataReader = Nothing
    Dim dtable As DataTable
    Dim con As OleDbConnection = Nothing
    Dim adp As OleDbDataAdapter
    Dim ds As DataSet
    Dim cmd As OleDbCommand = Nothing
    Dim dt As New DataTable
    Dim MenuName As String

    Private Sub btnGetAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetAll.Click
        con = New OleDbConnection(SqlHelper.strConnect)

        Try

            con.Open()
            cmd = New OleDbCommand("SELECT MenuItems.ItemName AS MenuName, InventoryItems.InventoryName, MenuItems.MenuID, InventoryItems.InventoryID FROM MenuItems INNER JOIN (InventoryItems INNER JOIN ItemAssignments ON InventoryItems.InventoryID = ItemAssignments.InventoryItemID) ON MenuItems.MenuID = ItemAssignments.MenuItemID where ItemAssignments.IsDeleted = 0 order by MenuItems.ItemName ;", con)

            Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()

            myDA.Fill(myDataSet, "MenuItems")
            dgItemAssignmentsData.DataSource = myDataSet.Tables("MenuItems").DefaultView

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub btnExportAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExportAll.Click
        If dgItemAssignmentsData.RowCount = Nothing Then
            MessageBox.Show("Sorry nothing to export into excel sheet.." & vbCrLf & "Please retrieve data in datagridview", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        Dim rowsTotal, colsTotal As Short
        Dim I, j, iC As Short
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Dim xlApp As New Excel.Application

        Try
            Dim excelBook As Excel.Workbook = xlApp.Workbooks.Add
            Dim excelWorksheet As Excel.Worksheet = CType(excelBook.Worksheets(1), Excel.Worksheet)
            xlApp.Visible = True

            rowsTotal = dgItemAssignmentsData.RowCount - 1
            colsTotal = dgItemAssignmentsData.Columns.Count - 1
            With excelWorksheet
                .Cells.Select()
                .Cells.Delete()
                For iC = 0 To colsTotal
                    .Cells(1, iC + 1).Value = dgItemAssignmentsData.Columns(iC).HeaderText
                Next
                For I = 0 To rowsTotal - 1
                    For j = 0 To colsTotal
                        .Cells(I + 2, j + 1).value = dgItemAssignmentsData.Rows(I).Cells(j).Value
                    Next j
                Next I
                .Rows("1:1").Font.FontStyle = "Bold"
                .Rows("1:1").Font.Size = 12

                .Cells.Columns.AutoFit()
                .Cells.Select()
                .Cells.EntireColumn.AutoFit()
                .Cells(1, 1).Select()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            'RELEASE ALLOACTED RESOURCES
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            xlApp = Nothing
        End Try
    End Sub

    Private Sub btnInventoryExport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInventoryExport.Click
        If dgvGetbyMenuName.RowCount = Nothing Then
            MessageBox.Show("Sorry nothing to export into excel sheet.." & vbCrLf & "Please retrieve data in datagridview", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        Dim rowsTotal, colsTotal As Short
        Dim I, j, iC As Short
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Dim xlApp As New Excel.Application

        Try
            Dim excelBook As Excel.Workbook = xlApp.Workbooks.Add
            Dim excelWorksheet As Excel.Worksheet = CType(excelBook.Worksheets(1), Excel.Worksheet)
            xlApp.Visible = True

            rowsTotal = dgvGetbyMenuName.RowCount - 1
            colsTotal = dgvGetbyMenuName.Columns.Count - 1
            With excelWorksheet
                .Cells.Select()
                .Cells.Delete()
                For iC = 0 To colsTotal
                    .Cells(1, iC + 1).Value = dgvGetbyMenuName.Columns(iC).HeaderText
                Next
                For I = 0 To rowsTotal - 1
                    For j = 0 To colsTotal
                        .Cells(I + 2, j + 1).value = dgvGetbyMenuName.Rows(I).Cells(j).Value
                    Next j
                Next I
                .Rows("1:1").Font.FontStyle = "Bold"
                .Rows("1:1").Font.Size = 12

                .Cells.Columns.AutoFit()
                .Cells.Select()
                .Cells.EntireColumn.AutoFit()
                .Cells(1, 1).Select()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            'RELEASE ALLOACTED RESOURCES
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            xlApp = Nothing
        End Try
    End Sub


    Private Sub btnResetExport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnResetExport.Click
        If dgvGetbyInventoryName.RowCount = Nothing Then
            MessageBox.Show("Sorry nothing to export into excel sheet.." & vbCrLf & "Please retrieve data in datagridview", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        Dim rowsTotal, colsTotal As Short
        Dim I, j, iC As Short
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Dim xlApp As New Excel.Application

        Try
            Dim excelBook As Excel.Workbook = xlApp.Workbooks.Add
            Dim excelWorksheet As Excel.Worksheet = CType(excelBook.Worksheets(1), Excel.Worksheet)
            xlApp.Visible = True

            rowsTotal = dgvGetbyInventoryName.RowCount - 1
            colsTotal = dgvGetbyInventoryName.Columns.Count - 1
            With excelWorksheet
                .Cells.Select()
                .Cells.Delete()
                For iC = 0 To colsTotal
                    .Cells(1, iC + 1).Value = dgvGetbyInventoryName.Columns(iC).HeaderText
                Next
                For I = 0 To rowsTotal - 1
                    For j = 0 To colsTotal
                        .Cells(I + 2, j + 1).value = dgvGetbyInventoryName.Rows(I).Cells(j).Value
                    Next j
                Next I
                .Rows("1:1").Font.FontStyle = "Bold"
                .Rows("1:1").Font.Size = 12

                .Cells.Columns.AutoFit()
                .Cells.Select()
                .Cells.EntireColumn.AutoFit()
                .Cells(1, 1).Select()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            'RELEASE ALLOACTED RESOURCES
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            xlApp = Nothing
        End Try
    End Sub

    Private Sub btnResetCategory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnResetCategory.Click
        dgvGetbyInventoryName.DataBindings.Clear()
        dgvGetbyInventoryName.DataSource = Nothing

    End Sub


    Private Sub btnResetInventory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnResetInventory.Click

        txtMenuItemName.Text = ""
        dgvGetbyMenuName.DataBindings.Clear()
        dgvGetbyMenuName.DataSource = Nothing
    End Sub

    Private Sub btnResetAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnResetAll.Click
        dgItemAssignmentsData.DataBindings.Clear()
        dgItemAssignmentsData.DataSource = Nothing
    End Sub

    Private Sub InventoryTabControl_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles MenuItemTabControl.Click

        dgvGetbyInventoryName.DataBindings.Clear()
        dgvGetbyInventoryName.DataSource = Nothing
        txtMenuItemName.Text = ""
        txtInventoryName.Text = ""
        dgvGetbyMenuName.DataBindings.Clear()
        dgItemAssignmentsData.DataBindings.Clear()
        dgvGetbyMenuName.DataSource = Nothing
        dgItemAssignmentsData.DataSource = Nothing
    End Sub


    Private Sub selMenuItem(frmMenuItem As String)
        MenuName = frmMenuItem
        dgvGetbyInventoryName.DataBindings.Clear()
        dgvGetbyInventoryName.DataSource = Nothing
        txtMenuItemName.Text = ""
        dgvGetbyMenuName.DataBindings.Clear()
        dgvGetbyMenuName.DataSource = Nothing
        dgItemAssignmentsData.DataBindings.Clear()
        dgItemAssignmentsData.DataSource = Nothing

    End Sub



    Private Sub MenuItemsUnMap_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Me.Hide()
        MenuItems.Show()
    End Sub


    Private Sub txtMenuItemName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtMenuItemName.TextChanged
        con = New OleDbConnection(SqlHelper.strConnect)
        Try
            con.Open()

            cmd = New OleDbCommand("SELECT MenuItems.ItemName AS MenuName, InventoryItems.InventoryName, MenuItems.MenuID, InventoryItems.InventoryID FROM MenuItems INNER JOIN (InventoryItems INNER JOIN ItemAssignments ON InventoryItems.InventoryID = ItemAssignments.InventoryItemID) ON MenuItems.MenuID = ItemAssignments.MenuItemID WHERE MenuItems.ItemName like '%" & txtMenuItemName.Text & "%' and ItemAssignments.IsDeleted = 0 order by MenuItems.ItemName", con)

            Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()

            myDA.Fill(myDataSet, "MenuItems")
            dgvGetbyMenuName.DataSource = myDataSet.Tables("MenuItems").DefaultView

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub txtInventoryName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtInventoryName.TextChanged
        con = New OleDbConnection(SqlHelper.strConnect)
        Try
            con.Open()

            cmd = New OleDbCommand("SELECT MenuItems.ItemName AS MenuName, InventoryItems.InventoryName, MenuItems.MenuID, InventoryItems.InventoryID FROM MenuItems INNER JOIN (InventoryItems INNER JOIN ItemAssignments ON InventoryItems.InventoryID = ItemAssignments.InventoryItemID) ON MenuItems.MenuID = ItemAssignments.MenuItemID WHERE InventoryItems.InventoryName like '%" & txtInventoryName.Text & "%' and ItemAssignments.IsDeleted = 0  order by MenuItems.ItemName", con)

            Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()

            myDA.Fill(myDataSet, "MenuItems")
            dgvGetbyMenuName.DataSource = myDataSet.Tables("MenuItems").DefaultView

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub dgItemAssignmentsData_RowHeaderMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgItemAssignmentsData.RowHeaderMouseClick
        Try
            Dim dr As DataGridViewRow = dgItemAssignmentsData.SelectedRows(0)

            MenuItems.txtunMenuID.Text = dr.Cells(0).Value.ToString()
            MenuItems.txtunInventoryID.Text = dr.Cells(1).Value.ToString()

            MenuItems.unmapMenuID = Convert.ToInt32(dr.Cells(2).Value)
            MenuItems.unmapInventoryID = Convert.ToInt32(dr.Cells(3).Value)

            Me.Hide()
            MenuItems.Show()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgvGetbyMenuName_RowHeaderMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgvGetbyMenuName.RowHeaderMouseClick
        Try
            Dim dr As DataGridViewRow = dgItemAssignmentsData.SelectedRows(0)

            MenuItems.txtunMenuID.Text = dr.Cells(0).Value.ToString()
            MenuItems.txtunInventoryID.Text = dr.Cells(1).Value.ToString()

            MenuItems.unmapMenuID = Convert.ToInt32(dr.Cells(2).Value)
            MenuItems.unmapInventoryID = Convert.ToInt32(dr.Cells(3).Value)

            Me.Hide()
            MenuItems.Show()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub



    Private Sub dgvGetbyInventoryName_RowHeaderMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgvGetbyInventoryName.RowHeaderMouseClick
        Try
            Dim dr As DataGridViewRow = dgItemAssignmentsData.SelectedRows(0)

            MenuItems.txtunMenuID.Text = dr.Cells(0).Value.ToString()
            MenuItems.txtunInventoryID.Text = dr.Cells(1).Value.ToString()

            MenuItems.unmapMenuID = Convert.ToInt32(dr.Cells(2).Value)
            MenuItems.unmapInventoryID = Convert.ToInt32(dr.Cells(3).Value)

            Me.Hide()
            MenuItems.Show()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

End Class