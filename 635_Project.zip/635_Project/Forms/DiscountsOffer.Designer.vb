﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class DiscountsOffer
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.dtpValidTo = New System.Windows.Forms.DateTimePicker()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.dtpValidityFrom = New System.Windows.Forms.DateTimePicker()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtDiscount = New System.Windows.Forms.TextBox()
        Me.txtDescriptionPromotion = New System.Windows.Forms.TextBox()
        Me.txtPromotionID = New System.Windows.Forms.TextBox()
        Me.PromotionDiscountLabel = New System.Windows.Forms.Label()
        Me.PromotionDescriptionLabel = New System.Windows.Forms.Label()
        Me.PromotionIDLabel = New System.Windows.Forms.Label()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnCreate = New System.Windows.Forms.Button()
        Me.CancelButton = New System.Windows.Forms.Button()
        Me.UnitPriceTextBox = New System.Windows.Forms.TextBox()
        Me.btnSendtoUsers = New System.Windows.Forms.Button()
        Me.GroupBox1.SuspendLayout()
        Me.SuspendLayout()
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.dtpValidTo)
        Me.GroupBox1.Controls.Add(Me.Label2)
        Me.GroupBox1.Controls.Add(Me.dtpValidityFrom)
        Me.GroupBox1.Controls.Add(Me.Label1)
        Me.GroupBox1.Controls.Add(Me.txtDiscount)
        Me.GroupBox1.Controls.Add(Me.txtDescriptionPromotion)
        Me.GroupBox1.Controls.Add(Me.txtPromotionID)
        Me.GroupBox1.Controls.Add(Me.PromotionDiscountLabel)
        Me.GroupBox1.Controls.Add(Me.PromotionDescriptionLabel)
        Me.GroupBox1.Controls.Add(Me.PromotionIDLabel)
        Me.GroupBox1.Location = New System.Drawing.Point(56, 12)
        Me.GroupBox1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.GroupBox1.Size = New System.Drawing.Size(581, 409)
        Me.GroupBox1.TabIndex = 32
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "New Promotional Offer"
        '
        'dtpValidTo
        '
        Me.dtpValidTo.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpValidTo.Location = New System.Drawing.Point(248, 290)
        Me.dtpValidTo.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpValidTo.Name = "dtpValidTo"
        Me.dtpValidTo.Size = New System.Drawing.Size(116, 24)
        Me.dtpValidTo.TabIndex = 33
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(141, 290)
        Me.Label2.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(71, 17)
        Me.Label2.TabIndex = 32
        Me.Label2.Text = "Validity To:"
        '
        'dtpValidityFrom
        '
        Me.dtpValidityFrom.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpValidityFrom.Location = New System.Drawing.Point(248, 239)
        Me.dtpValidityFrom.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpValidityFrom.Name = "dtpValidityFrom"
        Me.dtpValidityFrom.Size = New System.Drawing.Size(116, 24)
        Me.dtpValidityFrom.TabIndex = 31
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(141, 239)
        Me.Label1.Margin = New System.Windows.Forms.Padding(2, 0, 2, 0)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(85, 17)
        Me.Label1.TabIndex = 30
        Me.Label1.Text = "Validity From:"
        '
        'txtDiscount
        '
        Me.txtDiscount.Location = New System.Drawing.Point(248, 192)
        Me.txtDiscount.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtDiscount.Name = "txtDiscount"
        Me.txtDiscount.Size = New System.Drawing.Size(152, 24)
        Me.txtDiscount.TabIndex = 29
        '
        'txtDescriptionPromotion
        '
        Me.txtDescriptionPromotion.Location = New System.Drawing.Point(248, 107)
        Me.txtDescriptionPromotion.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtDescriptionPromotion.Multiline = True
        Me.txtDescriptionPromotion.Name = "txtDescriptionPromotion"
        Me.txtDescriptionPromotion.Size = New System.Drawing.Size(152, 77)
        Me.txtDescriptionPromotion.TabIndex = 28
        '
        'txtPromotionID
        '
        Me.txtPromotionID.Enabled = False
        Me.txtPromotionID.Location = New System.Drawing.Point(248, 57)
        Me.txtPromotionID.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPromotionID.Name = "txtPromotionID"
        Me.txtPromotionID.Size = New System.Drawing.Size(152, 24)
        Me.txtPromotionID.TabIndex = 4
        '
        'PromotionDiscountLabel
        '
        Me.PromotionDiscountLabel.AutoSize = True
        Me.PromotionDiscountLabel.Location = New System.Drawing.Point(141, 192)
        Me.PromotionDiscountLabel.Name = "PromotionDiscountLabel"
        Me.PromotionDiscountLabel.Size = New System.Drawing.Size(56, 17)
        Me.PromotionDiscountLabel.TabIndex = 2
        Me.PromotionDiscountLabel.Text = "Discount"
        '
        'PromotionDescriptionLabel
        '
        Me.PromotionDescriptionLabel.AutoSize = True
        Me.PromotionDescriptionLabel.Location = New System.Drawing.Point(141, 112)
        Me.PromotionDescriptionLabel.Name = "PromotionDescriptionLabel"
        Me.PromotionDescriptionLabel.Size = New System.Drawing.Size(70, 17)
        Me.PromotionDescriptionLabel.TabIndex = 1
        Me.PromotionDescriptionLabel.Text = "Description"
        '
        'PromotionIDLabel
        '
        Me.PromotionIDLabel.AutoSize = True
        Me.PromotionIDLabel.Location = New System.Drawing.Point(141, 57)
        Me.PromotionIDLabel.Name = "PromotionIDLabel"
        Me.PromotionIDLabel.Size = New System.Drawing.Size(85, 17)
        Me.PromotionIDLabel.TabIndex = 0
        Me.PromotionIDLabel.Text = "Promotion ID"
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(369, 443)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(87, 30)
        Me.btnClear.TabIndex = 35
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnCreate
        '
        Me.btnCreate.Location = New System.Drawing.Point(264, 443)
        Me.btnCreate.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnCreate.Name = "btnCreate"
        Me.btnCreate.Size = New System.Drawing.Size(87, 30)
        Me.btnCreate.TabIndex = 33
        Me.btnCreate.Text = "&Create"
        Me.btnCreate.UseVisualStyleBackColor = True
        '
        'CancelButton
        '
        Me.CancelButton.Location = New System.Drawing.Point(640, 443)
        Me.CancelButton.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.CancelButton.Name = "CancelButton"
        Me.CancelButton.Size = New System.Drawing.Size(87, 30)
        Me.CancelButton.TabIndex = 34
        Me.CancelButton.Text = "&Home"
        Me.CancelButton.UseVisualStyleBackColor = True
        '
        'UnitPriceTextBox
        '
        Me.UnitPriceTextBox.Location = New System.Drawing.Point(226, 224)
        Me.UnitPriceTextBox.Margin = New System.Windows.Forms.Padding(4, 5, 4, 5)
        Me.UnitPriceTextBox.Name = "UnitPriceTextBox"
        Me.UnitPriceTextBox.Size = New System.Drawing.Size(148, 20)
        Me.UnitPriceTextBox.TabIndex = 29
        '
        'btnSendtoUsers
        '
        Me.btnSendtoUsers.Enabled = False
        Me.btnSendtoUsers.Location = New System.Drawing.Point(490, 443)
        Me.btnSendtoUsers.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnSendtoUsers.Name = "btnSendtoUsers"
        Me.btnSendtoUsers.Size = New System.Drawing.Size(87, 30)
        Me.btnSendtoUsers.TabIndex = 36
        Me.btnSendtoUsers.Text = "&Send"
        Me.btnSendtoUsers.UseVisualStyleBackColor = True
        '
        'DiscountsOffer
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(776, 510)
        Me.Controls.Add(Me.btnSendtoUsers)
        Me.Controls.Add(Me.GroupBox1)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnCreate)
        Me.Controls.Add(Me.CancelButton)
        Me.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(2)
        Me.Name = "DiscountsOffer"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "DiscountsOffer"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
    Friend WithEvents txtDiscount As System.Windows.Forms.TextBox
    Friend WithEvents txtDescriptionPromotion As System.Windows.Forms.TextBox
    Friend WithEvents txtPromotionID As System.Windows.Forms.TextBox
    Friend WithEvents PromotionDiscountLabel As System.Windows.Forms.Label
    Friend WithEvents PromotionDescriptionLabel As System.Windows.Forms.Label
    Friend WithEvents PromotionIDLabel As System.Windows.Forms.Label
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnCreate As System.Windows.Forms.Button
    Friend WithEvents CancelButton As System.Windows.Forms.Button
    Friend WithEvents dtpValidityFrom As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents dtpValidTo As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents UnitPriceTextBox As System.Windows.Forms.TextBox
    Friend WithEvents btnSendtoUsers As System.Windows.Forms.Button
End Class
