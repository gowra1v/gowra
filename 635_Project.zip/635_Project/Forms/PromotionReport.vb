﻿Imports System.Text
Imports System.Globalization


Public Class PromotionReport
    Dim reportTodo As ReportTodoList

    Private Sub PromotionReport_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'cmbPromotionStatus.SelectedText = "Active"
        Try
            Dim docXML As String = ""
            Dim reportData As String = ""
            
            Dim dtPromotionReport As New DataTable
            reportTodo = New ReportTodoList()
            dtPromotionReport = reportTodo.SelectPromotionsForReport()
            If dtPromotionReport.Rows.Count > 0 Then
                reportData = buildXMLContent(dtPromotionReport)
            End If
            docXML = "<?xml version=""1.0"" encoding=""utf-8""?>"
            docXML += "<html>"
            docXML += "<head>"
            docXML += "<style type=""text/css"">"
            docXML += "body { margin-top: 100px, margin-bottom: 40px, margin-right: 40px; margin-left: 40px; font-family: arial;font-size: 16pt;}"
            docXML += " th { font-style: italic; } th, td { border: 1px solid black; padding: 10 px; text-align: center;}"
            docXML += "tr.odd { background: rgb(244,244,244); } tr.even { background: rgb(232,232,232); }"
            docXML += "table {border-collapse:collapse;}"
            docXML += "</style>"
            docXML += "</head>"
            docXML += "<body> <h1>Promotion Report</h1> <h2></h2>"
            docXML += "<table><tr class=""even""><th>Promotion ID</th><th>Description</th><th>Discount</th><th>Active</th></tr>"
            docXML += "</table>"
            docXML += "</body>"
            docXML += "</html>"
            If reportData.Trim.Length = 0 Then
                WebBrowser1.DocumentText = docXML.ToString()
            Else
                WebBrowser1.DocumentText = reportData.ToString()
                WebBrowser1.Visible = True
            End If
        Catch ex As Exception
            MessageBox.Show("Error in loading data for report... please try after sometime", "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Function buildXMLContent(ByVal dtTable As DataTable) As String
        Dim docXML As String = ""
        Dim reportData As String = ""
        Dim tagClass As String = "odd"
        'Dim finalXML As Xml.XmlText
        Dim rowCount As Integer = 0
        Dim TimesOut As Integer = 0
        Dim battingAverage As Decimal = 0D
        Dim bowlingAverage As Decimal = 0D
        docXML = "<?xml version=""1.0"" encoding=""utf-8""?>"
        docXML += "<html>"
        docXML += "<head>"
        docXML += "<style type=""text/css"">"
        docXML += "body { margin: 40px; font-family: arial;font-size: 16pt;}"
        docXML += " th { font-style: italic; } th, td { border: 1px solid black; padding: 10 px; text-align: center;}"
        docXML += "tr.odd { background: rgb(244,244,244); } tr.even { background: rgb(232,232,232); }"
        docXML += "table {border-collapse:collapse;}"
        docXML += "</style>"
        docXML += "</head>"
        docXML += "<body> <h1>Promotion Report</h1> <h2></h2>"
        docXML += "<table><tr class=""even""><th>Promotion ID</th><th>Description</th><th>Discount</th><th>Active</th></tr>"
        For Each dr As DataRow In dtTable.Rows
            If rowCount = 0 Then
                tagClass = "odd"
            ElseIf (rowCount Mod 2) = 0 Then
                tagClass = "even"
            End If

            reportData += "<tr class=" & tagClass & ">"
            reportData += "<td>" & dr.Item("PromotionID").ToString() & "</td>"
            reportData += "<td>" & dr.Item("PromotionDescription").ToString() & "</td>"
            reportData += "<td>" & dr.Item("PromotionDiscount").ToString() & "</td>"
            reportData += "<td>" & If(dr.Item("Active").ToString() = "False", "No", "Yes") & "</td>"
            reportData += "</tr>"
            rowCount += 1
        Next
        reportData += "</table>"
        reportData += "</body>"
        reportData += "</html>"
        Return (docXML.ToString() & " " & reportData.ToString())
    End Function


    Private Sub PromotionReport_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Me.Hide()
        MainForm.Show()
    End Sub

    Private Sub btnClose_Click(sender As System.Object, e As System.EventArgs) Handles btnClose.Click
        Me.Hide()
        MainForm.Show()
    End Sub

    Private Sub rbActive_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles rbActive.CheckedChanged
        If rbActive.Checked Then
            Try
                Dim txtSearch As String = ""
                Dim docXML As String = ""
                Dim reportData As String = ""
                Dim PromotionStatus As String = ""
                'txtSearch = txtSearchbyCode.Text
                Dim dtPromotions As New DataTable
                reportTodo = New ReportTodoList()
                'PromotionStatus = IIf(cmbPromotionStatus.Text = "", "", cmbPromotionStatus.Text)
                dtPromotions = reportTodo.SelectPromotionDetailsForReport("Active")
                If dtPromotions.Rows.Count > 0 Then
                    reportData = buildXMLContent(dtPromotions)
                End If
                docXML = "<?xml version=""1.0"" encoding=""utf-8""?>"
                docXML += "<html>"
                docXML += "<head>"
                docXML += "<style type=""text/css"">"
                'docXML += "body { margin: 40px; font-family: arial;font-size: 16pt;}"
                docXML += "body { margin-top: 100px, margin-bottom: 40px, margin-right: 40px; margin-left: 40px; font-family: arial;font-size: 16pt;}"
                docXML += " th { font-style: italic; } th, td { border: 1px solid black; padding: 10 px; text-align: center;}"
                docXML += "tr.odd { background: rgb(244,244,244); } tr.even { background: rgb(232,232,232); }"
                docXML += "table {border-collapse:collapse;}"
                docXML += "</style>"
                docXML += "</head>"
                docXML += "<body> <h1>Promotion Report</h1> <h2></h2>"
                docXML += "<table><tr class=""even""><th>Promotion ID</th><th>Description</th><th>Discount</th><th>Active</th></tr>"
                docXML += "<table><tr class=""odd"" Colspan=""4""> No User Data Found</tr>"
                docXML += "</table>"
                docXML += "</body>"
                docXML += "</html>"
                If reportData.Trim.Length = 0 Then
                    WebBrowser1.DocumentText = docXML.ToString()
                Else
                    WebBrowser1.DocumentText = reportData.ToString()
                End If
            Catch Ex As Exception
                MessageBox.Show("Error in loading data for report... please try after sometime", "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If

    End Sub

    Private Sub rbInActive_CheckedChanged(sender As System.Object, e As System.EventArgs) Handles rbInActive.CheckedChanged
        If rbInActive.Checked Then
            Try
                Dim txtSearch As String = ""
                Dim docXML As String = ""
                Dim reportData As String = ""
                Dim PromotionStatus As String = ""
                'txtSearch = txtSearchbyCode.Text
                Dim dtPromotions As New DataTable
                reportTodo = New ReportTodoList()
                'PromotionStatus = IIf(cmbPromotionStatus.Text = "", "", cmbPromotionStatus.Text)
                dtPromotions = reportTodo.SelectPromotionDetailsForReport("InActive")
                If dtPromotions.Rows.Count > 0 Then
                    reportData = buildXMLContent(dtPromotions)
                End If
                docXML = "<?xml version=""1.0"" encoding=""utf-8""?>"
                docXML += "<html>"
                docXML += "<head>"
                docXML += "<style type=""text/css"">"
                'docXML += "body { margin: 40px; font-family: arial;font-size: 16pt;}"
                docXML += "body { margin-top: 100px, margin-bottom: 40px, margin-right: 40px; margin-left: 40px; font-family: arial;font-size: 16pt;}"
                docXML += " th { font-style: italic; } th, td { border: 1px solid black; padding: 10 px; text-align: center;}"
                docXML += "tr.odd { background: rgb(244,244,244); } tr.even { background: rgb(232,232,232); }"
                docXML += "table {border-collapse:collapse;}"
                docXML += "</style>"
                docXML += "</head>"
                docXML += "<body> <h1>Task Report</h1> <h2></h2>"
                docXML += "<table><tr class=""even""><th>Promotion ID</th><th>Description</th><th>Discount</th><th>Active</th></tr>"
                docXML += "<table><tr class=""odd"" Colspan=""4""> No User Data Found</tr>"
                docXML += "</table>"
                docXML += "</body>"
                docXML += "</html>"
                If reportData.Trim.Length = 0 Then
                    WebBrowser1.DocumentText = docXML.ToString()
                Else
                    WebBrowser1.DocumentText = reportData.ToString()
                End If
            Catch Ex As Exception
                MessageBox.Show("Error in loading data for report... please try after sometime", "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End Try
        End If
    End Sub
End Class