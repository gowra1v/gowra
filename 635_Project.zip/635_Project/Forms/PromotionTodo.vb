﻿
Public Class PromotionTodo
    Dim sql As SqlHelper
    Public Property InPromotionID As Integer
    Public Property InValidFrom As Date
    Public Property InValidTo As Date
    Public Property InDescription As String
    Public Property InDiscount As Integer

    Public Sub New()

    End Sub
    Public Sub New(ByVal Description As String, ByVal Discount As Integer, ByVal ValidFrom As Date, ByVal ValidTo As Date, Optional ByVal PromotionID As Integer = 0)

        InValidFrom = ValidFrom
        InValidTo = ValidTo
        InDescription = Description
        InDiscount = Discount
        If PromotionID = 0 Then
            InPromotionID = -1
        Else
            InPromotionID = PromotionID
        End If

    End Sub

    Public Function InsertPromotionsIntoDatabase() As Integer
        sql = New SqlHelper()
        Dim insertStr As String
        Dim InsertSuccess As Integer
        insertStr = " INSERT INTO Promotions (PromotionDescription, PromotionDiscount, PromotionStartDate, PromotionEndDate) VALUES ('" & InDescription & "'," & InDiscount & ",'" & InValidFrom & "','" & InValidTo & "')"
        InsertSuccess = sql.ExecuteInsUpdDel(insertStr, True) REM True, it is Insert
        Return InsertSuccess
    End Function

    Public Function UpdateInventoryItemsIntoDatabase() As Integer
        sql = New SqlHelper()
        Dim updateStr As String
        Dim UpdateSuccess As Integer
        updateStr = "UPDATE Promotions SET PromotionDescription = '" & InDescription & "', PromotionDiscount = " & InDiscount & ", ValidFrom = " & InValidFrom & ",ValidTo = " & InValidTo & " WHERE PromotionID = " & InPromotionID & ""

        UpdateSuccess = sql.ExecuteInsUpdDel(updateStr) REM True, it is Insert

        Return UpdateSuccess
    End Function

    Public Function DeletePromotionsFromDatabase(ByVal InPromoID As Integer) As Integer
        sql = New SqlHelper()
        Dim deleteStr As String
        deleteStr = "UPDATE Promotions  set Active = 'False' WHERE active  = " & InPromoID
        Dim deleteStatus As Integer = sql.ExecuteInsUpdDel(deleteStr)
        Return deleteStatus
    End Function

    Public Function GetPromotionsID() As Integer
        Dim GetMaxID As Integer
        Dim selectStr As String
        sql = New SqlHelper()
        selectStr = "select Max(PromotionID) as MaxID from Promotions"
        GetMaxID = sql.GetMaxID(selectStr)
        Return GetMaxID
    End Function

    Public Function LoadPromotionItemsDetails(ByVal InPromoID As Integer) As DataTable
        sql = New SqlHelper()
        Dim selectStr As String
        Dim dt As DataTable
        selectStr = "select * from Promotions where PromotionID = " & InPromoID & ""
        dt = sql.ExecuteSelectTable(selectStr)
        Return dt
    End Function




    Public Function GetCustomerEmailIds() As DataTable
        sql = New SqlHelper()
        Dim selectStr As String
        Dim dt As DataTable
        selectStr = "select EmailID from customer where EmailID is not null "
        dt = sql.ExecuteSelectTable(selectStr)
        Return dt
    End Function
    Public Function LoadCustomerList() As DataTable
        sql = New SqlHelper()
        Dim selectStr As String
        Dim dt As DataTable
        selectStr = "select Promotion from Promotions"
        dt = sql.ExecuteSelectTable(selectStr)
        Return dt
    End Function

    


End Class
