﻿Imports System.Data.OleDB
Public Class InventoryCategory
    Dim InventoryTo As InventoryTodo
    Dim readerCategory As OleDbDataReader = Nothing
    Dim con As OleDbConnection = Nothing
    Dim cmdCategory As OleDbCommand = Nothing


    Private Sub InventoryCategory_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        suggestionCode()
        txtCategoryName.Focus()
        clrCategoryDetails()
    End Sub

    Private Sub btnGetCategoryID_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetCategoryID.Click
        Me.Hide()
        clrCategoryDetails()
        InventoryCategoryRecord.dgvCategoryDetails.DataSource = Nothing
        InventoryCategoryRecord.Show()
    End Sub

    Private Sub btnNewCategory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewCategory.Click
        txtCategoryID.Text = ""
        txtCategoryName.Text = ""
        btnSave.Enabled = True
        btnDelete.Enabled = False
        btnUpdate.Enabled = False
        txtCategoryName.Focus()
        txtCategoryID.Text = Convert.ToInt32(InventoryTo.GetCategoryItemID())
    End Sub

    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click
        InventoryTo = New InventoryTodo
        If Len(Trim(txtCategoryName.Text)) = 0 Then
            MessageBox.Show("Please enter category name", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtCategoryName.Focus()
            Exit Sub
        End If

        Try
            con = New OleDbConnection(SqlHelper.strConnect)
            con.Open()
            Dim ct As String = "select CategoryName from ItemCategories where CategoryName=@find"

            cmdCategory = New OleDbCommand(ct)
            cmdCategory.Connection = con
            cmdCategory.Parameters.Add(New OleDbParameter("@find", System.Data.OleDb.OleDbType.VarChar, 150, "CategoryName"))
            cmdCategory.Parameters("@find").Value = txtCategoryName.Text
            readerCategory = cmdCategory.ExecuteReader()

            If readerCategory.Read Then
                MessageBox.Show("Category name Already Exists", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtCategoryName.Text = ""
                txtCategoryName.Focus()
                If Not readerCategory Is Nothing Then
                    readerCategory.Close()
                End If

                If con.State = ConnectionState.Open Then
                    con.Close()
                End If
                con.Close()
                Exit Sub
            Else

                con = New OleDbConnection(SqlHelper.strConnect)
                con.Open()
                Dim insertItemCategory As String = "insert into ItemCategories(CategoryName) VALUES (@CategoryName)"
                cmdCategory = New OleDbCommand(insertItemCategory)
                cmdCategory.Connection = con
                cmdCategory.Parameters.Add(New OleDbParameter("@CategoryName", System.Data.OleDb.OleDbType.VarChar, 150, "CategoryName"))
                cmdCategory.Parameters("@CategoryName").Value = txtCategoryName.Text
                cmdCategory.ExecuteReader()
                MessageBox.Show("Successfully saved", "Category Details", MessageBoxButtons.OK, MessageBoxIcon.Information)
                txtCategoryID.Text = (Convert.ToInt32(InventoryTo.GetCategoryItemID()) - 1).ToString()
                btnSave.Enabled = False
                suggestionCode()
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If

                con.Close()
            End If



        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Try

            con = New OleDbConnection(SqlHelper.strConnect)
            con.Open()

            Dim updCategoryName As String = "update ItemCategories set CategoryName='" & txtCategoryName.Text & "' where CategoryID = " & Convert.ToInt32(txtCategoryID.Text) & ""

            cmdCategory = New OleDbCommand(updCategoryName)
            cmdCategory.Connection = con
            cmdCategory.ExecuteReader()
            MessageBox.Show("Successfully updated", "Category Details", MessageBoxButtons.OK, MessageBoxIcon.Information)

            If con.State = ConnectionState.Open Then
                con.Close()
            End If

            con.Close()

            btnUpdate.Enabled = False
            suggestionCode()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub btnDelete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            If MessageBox.Show("Do you really want to delete the record?", "Inventory Category", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
                delCategories()
                suggestionCode()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub delCategories()
        Try
            Dim RowsAffected As Integer = 0
            con = New OleDbConnection(SqlHelper.strConnect)
            con.Open()
            Dim cq As String = "delete from ItemCategories where CategoryID=@CategoryID;"

            cmdCategory = New OleDbCommand(cq)
            cmdCategory.Connection = con
            cmdCategory.Parameters.Add(New OleDbParameter("@CategoryID", System.Data.OleDb.OleDbType.Integer, 10, "CategoryID"))
            cmdCategory.Parameters("@CategoryID").Value = Trim(txtCategoryID.Text)
            RowsAffected = cmdCategory.ExecuteNonQuery()
            If RowsAffected > 0 Then
                MessageBox.Show("Successfully deleted", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
                clrCategoryDetails()
                txtCategoryName.Focus()
                btnUpdate.Enabled = False
                btnDelete.Enabled = False
                suggestionCode()
            Else
                MessageBox.Show("No record found", "Sorry", MessageBoxButtons.OK, MessageBoxIcon.Information)
                clrCategoryDetails()
                txtCategoryName.Focus()
                btnUpdate.Enabled = False
                btnDelete.Enabled = False
                suggestionCode()
                If con.State = ConnectionState.Open Then
                    con.Close()
                End If


            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            con.Close()
        End Try
    End Sub



    Private Sub suggestionCode()
        Try
            con = New OleDbConnection(SqlHelper.strConnect)
            con.Open()
            Dim cmd As New OleDbCommand("SELECT CategoryName FROM ItemCategories", con)
            Dim dsCategory As New DataSet
            Dim daCategory As New OleDbDataAdapter(cmd)
            daCategory.Fill(dsCategory, "My List") 'list can be any name u want
            Dim colSuggestion As New AutoCompleteStringCollection
            Dim rowCategory As Integer
            For rowCategory = 0 To dsCategory.Tables(0).Rows.Count - 1
                colSuggestion.Add(dsCategory.Tables(0).Rows(rowCategory)("Categoryname").ToString())
            Next
            txtCategoryName.AutoCompleteSource = AutoCompleteSource.CustomSource
            txtCategoryName.AutoCompleteCustomSource = colSuggestion
            txtCategoryName.AutoCompleteMode = AutoCompleteMode.Suggest

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub btnHome_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHome.Click
        If MessageBox.Show("Please save any unsaved changes and then navigate to main menu view?", "Are you sure to Exit?", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = Windows.Forms.DialogResult.OK Then
            Me.Hide()
            clrCategoryDetails()
            MainForm.Show()
        End If
    End Sub

    Private Sub frmInventoryCategory_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If MessageBox.Show("Please save any unsaved changes and then navigate to main menu view?", "Are you sure to Exit?", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = Windows.Forms.DialogResult.OK Then
            clrCategoryDetails()
            MainForm.Show()
        Else
            e.Cancel = True
        End If
    End Sub


    Private Sub clrCategoryDetails()
        txtCategoryID.Text = ""
        txtCategoryName.Text = ""
    End Sub

    
End Class