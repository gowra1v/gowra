﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class PromotionReport
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.WebBrowser1 = New System.Windows.Forms.WebBrowser()
        Me.lblSelectCountry = New System.Windows.Forms.Label()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.rbActive = New System.Windows.Forms.RadioButton()
        Me.rbInActive = New System.Windows.Forms.RadioButton()
        Me.SuspendLayout()
        '
        'WebBrowser1
        '
        Me.WebBrowser1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.WebBrowser1.Location = New System.Drawing.Point(0, 0)
        Me.WebBrowser1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.WebBrowser1.MinimumSize = New System.Drawing.Size(23, 27)
        Me.WebBrowser1.Name = "WebBrowser1"
        Me.WebBrowser1.Size = New System.Drawing.Size(837, 517)
        Me.WebBrowser1.TabIndex = 0
        '
        'lblSelectCountry
        '
        Me.lblSelectCountry.AutoSize = True
        Me.lblSelectCountry.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.lblSelectCountry.Location = New System.Drawing.Point(12, 9)
        Me.lblSelectCountry.Name = "lblSelectCountry"
        Me.lblSelectCountry.Size = New System.Drawing.Size(159, 24)
        Me.lblSelectCountry.TabIndex = 2
        Me.lblSelectCountry.Text = "Promotion Status"
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(659, 3)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(107, 30)
        Me.btnClose.TabIndex = 5
        Me.btnClose.Text = "&Home"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'rbActive
        '
        Me.rbActive.AutoSize = True
        Me.rbActive.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.rbActive.Location = New System.Drawing.Point(219, 8)
        Me.rbActive.Name = "rbActive"
        Me.rbActive.Size = New System.Drawing.Size(89, 28)
        Me.rbActive.TabIndex = 6
        Me.rbActive.Text = "Active"
        Me.rbActive.UseVisualStyleBackColor = False
        '
        'rbInActive
        '
        Me.rbInActive.AutoSize = True
        Me.rbInActive.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.rbInActive.Location = New System.Drawing.Point(332, 9)
        Me.rbInActive.Name = "rbInActive"
        Me.rbInActive.Size = New System.Drawing.Size(112, 28)
        Me.rbInActive.TabIndex = 7
        Me.rbInActive.Text = "In Active"
        Me.rbInActive.UseVisualStyleBackColor = False
        '
        'PromotionReport
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(11.0!, 24.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(837, 517)
        Me.Controls.Add(Me.rbInActive)
        Me.Controls.Add(Me.rbActive)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.lblSelectCountry)
        Me.Controls.Add(Me.WebBrowser1)
        Me.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "PromotionReport"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Promotion Report"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents WebBrowser1 As System.Windows.Forms.WebBrowser
    Friend WithEvents lblSelectCountry As System.Windows.Forms.Label
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents rbActive As System.Windows.Forms.RadioButton
    Friend WithEvents rbInActive As System.Windows.Forms.RadioButton
End Class
