﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class CreateNewEmployee
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.gbPersonalInfo = New System.Windows.Forms.GroupBox()
        Me.txtCountry = New System.Windows.Forms.TextBox()
        Me.CountryLabel = New System.Windows.Forms.Label()
        Me.txtCity = New System.Windows.Forms.TextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtState = New System.Windows.Forms.TextBox()
        Me.dtpDateOfBirth = New System.Windows.Forms.DateTimePicker()
        Me.txtMobileNo = New System.Windows.Forms.TextBox()
        Me.txtZIPCode = New System.Windows.Forms.TextBox()
        Me.txtEmailID = New System.Windows.Forms.TextBox()
        Me.lblMobileNo = New System.Windows.Forms.Label()
        Me.txtAddress = New System.Windows.Forms.TextBox()
        Me.lblDateOfBirth = New System.Windows.Forms.Label()
        Me.lblZIPCode = New System.Windows.Forms.Label()
        Me.lblState = New System.Windows.Forms.Label()
        Me.lblAddress = New System.Windows.Forms.Label()
        Me.lblEmailID = New System.Windows.Forms.Label()
        Me.gbLoginInfo = New System.Windows.Forms.GroupBox()
        Me.cmbLoginType = New System.Windows.Forms.ComboBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.txtConfirmPassword = New System.Windows.Forms.TextBox()
        Me.txtPassword = New System.Windows.Forms.TextBox()
        Me.txtLastName = New System.Windows.Forms.TextBox()
        Me.txtFirstName = New System.Windows.Forms.TextBox()
        Me.txtUserName = New System.Windows.Forms.TextBox()
        Me.lblConfirmPassword = New System.Windows.Forms.Label()
        Me.lblPassword = New System.Windows.Forms.Label()
        Me.lblLastName = New System.Windows.Forms.Label()
        Me.lblFirstName = New System.Windows.Forms.Label()
        Me.lblUserName = New System.Windows.Forms.Label()
        Me.btnSignIn = New System.Windows.Forms.Button()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.btnSignUp = New System.Windows.Forms.Button()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.gbPersonalInfo.SuspendLayout()
        Me.gbLoginInfo.SuspendLayout()
        Me.SuspendLayout()
        '
        'gbPersonalInfo
        '
        Me.gbPersonalInfo.Controls.Add(Me.txtCountry)
        Me.gbPersonalInfo.Controls.Add(Me.CountryLabel)
        Me.gbPersonalInfo.Controls.Add(Me.txtCity)
        Me.gbPersonalInfo.Controls.Add(Me.Label1)
        Me.gbPersonalInfo.Controls.Add(Me.txtState)
        Me.gbPersonalInfo.Controls.Add(Me.dtpDateOfBirth)
        Me.gbPersonalInfo.Controls.Add(Me.txtMobileNo)
        Me.gbPersonalInfo.Controls.Add(Me.txtZIPCode)
        Me.gbPersonalInfo.Controls.Add(Me.txtEmailID)
        Me.gbPersonalInfo.Controls.Add(Me.lblMobileNo)
        Me.gbPersonalInfo.Controls.Add(Me.txtAddress)
        Me.gbPersonalInfo.Controls.Add(Me.lblDateOfBirth)
        Me.gbPersonalInfo.Controls.Add(Me.lblZIPCode)
        Me.gbPersonalInfo.Controls.Add(Me.lblState)
        Me.gbPersonalInfo.Controls.Add(Me.lblAddress)
        Me.gbPersonalInfo.Controls.Add(Me.lblEmailID)
        Me.gbPersonalInfo.Font = New System.Drawing.Font("Palatino Linotype", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbPersonalInfo.Location = New System.Drawing.Point(579, 90)
        Me.gbPersonalInfo.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.gbPersonalInfo.Name = "gbPersonalInfo"
        Me.gbPersonalInfo.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.gbPersonalInfo.Size = New System.Drawing.Size(444, 455)
        Me.gbPersonalInfo.TabIndex = 29
        Me.gbPersonalInfo.TabStop = False
        Me.gbPersonalInfo.Text = "Personal Information"
        '
        'txtCountry
        '
        Me.txtCountry.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCountry.Location = New System.Drawing.Point(167, 270)
        Me.txtCountry.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCountry.Name = "txtCountry"
        Me.txtCountry.Size = New System.Drawing.Size(168, 24)
        Me.txtCountry.TabIndex = 15
        '
        'CountryLabel
        '
        Me.CountryLabel.AutoSize = True
        Me.CountryLabel.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.CountryLabel.Location = New System.Drawing.Point(31, 273)
        Me.CountryLabel.Name = "CountryLabel"
        Me.CountryLabel.Size = New System.Drawing.Size(57, 17)
        Me.CountryLabel.TabIndex = 16
        Me.CountryLabel.Text = "Country:"
        '
        'txtCity
        '
        Me.txtCity.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtCity.Location = New System.Drawing.Point(167, 198)
        Me.txtCity.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtCity.Name = "txtCity"
        Me.txtCity.Size = New System.Drawing.Size(168, 24)
        Me.txtCity.TabIndex = 13
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(31, 202)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(34, 17)
        Me.Label1.TabIndex = 14
        Me.Label1.Text = "City:"
        '
        'txtState
        '
        Me.txtState.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtState.Location = New System.Drawing.Point(167, 234)
        Me.txtState.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtState.Name = "txtState"
        Me.txtState.Size = New System.Drawing.Size(168, 24)
        Me.txtState.TabIndex = 8
        '
        'dtpDateOfBirth
        '
        Me.dtpDateOfBirth.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dtpDateOfBirth.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpDateOfBirth.Location = New System.Drawing.Point(167, 49)
        Me.dtpDateOfBirth.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.dtpDateOfBirth.Name = "dtpDateOfBirth"
        Me.dtpDateOfBirth.Size = New System.Drawing.Size(170, 24)
        Me.dtpDateOfBirth.TabIndex = 6
        '
        'txtMobileNo
        '
        Me.txtMobileNo.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtMobileNo.Location = New System.Drawing.Point(167, 379)
        Me.txtMobileNo.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtMobileNo.Name = "txtMobileNo"
        Me.txtMobileNo.Size = New System.Drawing.Size(168, 24)
        Me.txtMobileNo.TabIndex = 11
        '
        'txtZIPCode
        '
        Me.txtZIPCode.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtZIPCode.Location = New System.Drawing.Point(167, 307)
        Me.txtZIPCode.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtZIPCode.Name = "txtZIPCode"
        Me.txtZIPCode.Size = New System.Drawing.Size(168, 24)
        Me.txtZIPCode.TabIndex = 9
        '
        'txtEmailID
        '
        Me.txtEmailID.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtEmailID.Location = New System.Drawing.Point(166, 344)
        Me.txtEmailID.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtEmailID.Name = "txtEmailID"
        Me.txtEmailID.Size = New System.Drawing.Size(168, 24)
        Me.txtEmailID.TabIndex = 10
        '
        'lblMobileNo
        '
        Me.lblMobileNo.AutoSize = True
        Me.lblMobileNo.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMobileNo.Location = New System.Drawing.Point(33, 386)
        Me.lblMobileNo.Name = "lblMobileNo"
        Me.lblMobileNo.Size = New System.Drawing.Size(66, 17)
        Me.lblMobileNo.TabIndex = 12
        Me.lblMobileNo.Text = "MobileNo:"
        '
        'txtAddress
        '
        Me.txtAddress.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtAddress.Location = New System.Drawing.Point(168, 108)
        Me.txtAddress.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtAddress.Multiline = True
        Me.txtAddress.Name = "txtAddress"
        Me.txtAddress.Size = New System.Drawing.Size(168, 77)
        Me.txtAddress.TabIndex = 7
        '
        'lblDateOfBirth
        '
        Me.lblDateOfBirth.AutoSize = True
        Me.lblDateOfBirth.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDateOfBirth.Location = New System.Drawing.Point(33, 56)
        Me.lblDateOfBirth.Name = "lblDateOfBirth"
        Me.lblDateOfBirth.Size = New System.Drawing.Size(85, 17)
        Me.lblDateOfBirth.TabIndex = 12
        Me.lblDateOfBirth.Text = "Date Of Birth:"
        '
        'lblZIPCode
        '
        Me.lblZIPCode.AutoSize = True
        Me.lblZIPCode.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblZIPCode.Location = New System.Drawing.Point(33, 313)
        Me.lblZIPCode.Name = "lblZIPCode"
        Me.lblZIPCode.Size = New System.Drawing.Size(64, 17)
        Me.lblZIPCode.TabIndex = 12
        Me.lblZIPCode.Text = "ZIP Code:"
        '
        'lblState
        '
        Me.lblState.AutoSize = True
        Me.lblState.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblState.Location = New System.Drawing.Point(31, 238)
        Me.lblState.Name = "lblState"
        Me.lblState.Size = New System.Drawing.Size(38, 17)
        Me.lblState.TabIndex = 12
        Me.lblState.Text = "State:"
        '
        'lblAddress
        '
        Me.lblAddress.AutoSize = True
        Me.lblAddress.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblAddress.Location = New System.Drawing.Point(33, 114)
        Me.lblAddress.Name = "lblAddress"
        Me.lblAddress.Size = New System.Drawing.Size(55, 17)
        Me.lblAddress.TabIndex = 12
        Me.lblAddress.Text = "Address:"
        '
        'lblEmailID
        '
        Me.lblEmailID.AutoSize = True
        Me.lblEmailID.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblEmailID.Location = New System.Drawing.Point(31, 351)
        Me.lblEmailID.Name = "lblEmailID"
        Me.lblEmailID.Size = New System.Drawing.Size(56, 17)
        Me.lblEmailID.TabIndex = 12
        Me.lblEmailID.Text = "EmailID:"
        '
        'gbLoginInfo
        '
        Me.gbLoginInfo.Controls.Add(Me.cmbLoginType)
        Me.gbLoginInfo.Controls.Add(Me.Label2)
        Me.gbLoginInfo.Controls.Add(Me.txtConfirmPassword)
        Me.gbLoginInfo.Controls.Add(Me.txtPassword)
        Me.gbLoginInfo.Controls.Add(Me.txtLastName)
        Me.gbLoginInfo.Controls.Add(Me.txtFirstName)
        Me.gbLoginInfo.Controls.Add(Me.txtUserName)
        Me.gbLoginInfo.Controls.Add(Me.lblConfirmPassword)
        Me.gbLoginInfo.Controls.Add(Me.lblPassword)
        Me.gbLoginInfo.Controls.Add(Me.lblLastName)
        Me.gbLoginInfo.Controls.Add(Me.lblFirstName)
        Me.gbLoginInfo.Controls.Add(Me.lblUserName)
        Me.gbLoginInfo.Font = New System.Drawing.Font("Palatino Linotype", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.gbLoginInfo.Location = New System.Drawing.Point(75, 90)
        Me.gbLoginInfo.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.gbLoginInfo.Name = "gbLoginInfo"
        Me.gbLoginInfo.Padding = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.gbLoginInfo.Size = New System.Drawing.Size(450, 455)
        Me.gbLoginInfo.TabIndex = 28
        Me.gbLoginInfo.TabStop = False
        Me.gbLoginInfo.Text = "Login Info"
        '
        'cmbLoginType
        '
        Me.cmbLoginType.FormattingEnabled = True
        Me.cmbLoginType.Items.AddRange(New Object() {"Admin", "Manager", "Cashier"})
        Me.cmbLoginType.Location = New System.Drawing.Point(176, 363)
        Me.cmbLoginType.Margin = New System.Windows.Forms.Padding(2)
        Me.cmbLoginType.Name = "cmbLoginType"
        Me.cmbLoginType.Size = New System.Drawing.Size(168, 24)
        Me.cmbLoginType.TabIndex = 15
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label2.Location = New System.Drawing.Point(43, 363)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(75, 17)
        Me.Label2.TabIndex = 14
        Me.Label2.Text = "Login Type:"
        '
        'txtConfirmPassword
        '
        Me.txtConfirmPassword.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtConfirmPassword.Location = New System.Drawing.Point(175, 166)
        Me.txtConfirmPassword.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtConfirmPassword.Name = "txtConfirmPassword"
        Me.txtConfirmPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtConfirmPassword.Size = New System.Drawing.Size(168, 24)
        Me.txtConfirmPassword.TabIndex = 3
        '
        'txtPassword
        '
        Me.txtPassword.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtPassword.Location = New System.Drawing.Point(176, 112)
        Me.txtPassword.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtPassword.Name = "txtPassword"
        Me.txtPassword.PasswordChar = Global.Microsoft.VisualBasic.ChrW(42)
        Me.txtPassword.Size = New System.Drawing.Size(168, 24)
        Me.txtPassword.TabIndex = 2
        '
        'txtLastName
        '
        Me.txtLastName.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtLastName.Location = New System.Drawing.Point(175, 291)
        Me.txtLastName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtLastName.Name = "txtLastName"
        Me.txtLastName.Size = New System.Drawing.Size(168, 24)
        Me.txtLastName.TabIndex = 5
        '
        'txtFirstName
        '
        Me.txtFirstName.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtFirstName.Location = New System.Drawing.Point(175, 228)
        Me.txtFirstName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtFirstName.Name = "txtFirstName"
        Me.txtFirstName.Size = New System.Drawing.Size(168, 24)
        Me.txtFirstName.TabIndex = 4
        '
        'txtUserName
        '
        Me.txtUserName.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtUserName.Location = New System.Drawing.Point(175, 53)
        Me.txtUserName.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtUserName.Name = "txtUserName"
        Me.txtUserName.Size = New System.Drawing.Size(168, 24)
        Me.txtUserName.TabIndex = 1
        '
        'lblConfirmPassword
        '
        Me.lblConfirmPassword.AutoSize = True
        Me.lblConfirmPassword.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblConfirmPassword.Location = New System.Drawing.Point(41, 170)
        Me.lblConfirmPassword.Name = "lblConfirmPassword"
        Me.lblConfirmPassword.Size = New System.Drawing.Size(112, 17)
        Me.lblConfirmPassword.TabIndex = 13
        Me.lblConfirmPassword.Text = "Confirm Password:"
        '
        'lblPassword
        '
        Me.lblPassword.AutoSize = True
        Me.lblPassword.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPassword.Location = New System.Drawing.Point(41, 115)
        Me.lblPassword.Name = "lblPassword"
        Me.lblPassword.Size = New System.Drawing.Size(63, 17)
        Me.lblPassword.TabIndex = 13
        Me.lblPassword.Text = "Password:"
        '
        'lblLastName
        '
        Me.lblLastName.AutoSize = True
        Me.lblLastName.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLastName.Location = New System.Drawing.Point(41, 299)
        Me.lblLastName.Name = "lblLastName"
        Me.lblLastName.Size = New System.Drawing.Size(70, 17)
        Me.lblLastName.TabIndex = 12
        Me.lblLastName.Text = "Last Name:"
        '
        'lblFirstName
        '
        Me.lblFirstName.AutoSize = True
        Me.lblFirstName.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFirstName.Location = New System.Drawing.Point(41, 236)
        Me.lblFirstName.Name = "lblFirstName"
        Me.lblFirstName.Size = New System.Drawing.Size(71, 17)
        Me.lblFirstName.TabIndex = 12
        Me.lblFirstName.Text = "First Name:"
        '
        'lblUserName
        '
        Me.lblUserName.AutoSize = True
        Me.lblUserName.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUserName.Location = New System.Drawing.Point(41, 61)
        Me.lblUserName.Name = "lblUserName"
        Me.lblUserName.Size = New System.Drawing.Size(72, 17)
        Me.lblUserName.TabIndex = 12
        Me.lblUserName.Text = "User Name:"
        '
        'btnSignIn
        '
        Me.btnSignIn.Location = New System.Drawing.Point(908, 576)
        Me.btnSignIn.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnSignIn.Name = "btnSignIn"
        Me.btnSignIn.Size = New System.Drawing.Size(115, 30)
        Me.btnSignIn.TabIndex = 14
        Me.btnSignIn.Text = "&Home"
        Me.ToolTip1.SetToolTip(Me.btnSignIn, "Click here to get redirected to Sign-in page")
        Me.btnSignIn.UseVisualStyleBackColor = True
        '
        'btnClear
        '
        Me.btnClear.Location = New System.Drawing.Point(469, 576)
        Me.btnClear.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(87, 30)
        Me.btnClear.TabIndex = 13
        Me.btnClear.Text = "&Clear"
        Me.ToolTip1.SetToolTip(Me.btnClear, "Click here to clear entered data")
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'btnSignUp
        '
        Me.btnSignUp.Location = New System.Drawing.Point(338, 576)
        Me.btnSignUp.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnSignUp.Name = "btnSignUp"
        Me.btnSignUp.Size = New System.Drawing.Size(87, 30)
        Me.btnSignUp.TabIndex = 12
        Me.btnSignUp.Text = "&Create Admin"
        Me.ToolTip1.SetToolTip(Me.btnSignUp, "Click to save user details")
        Me.btnSignUp.UseVisualStyleBackColor = True
        '
        'CreateNewEmployee
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(1112, 673)
        Me.Controls.Add(Me.gbPersonalInfo)
        Me.Controls.Add(Me.gbLoginInfo)
        Me.Controls.Add(Me.btnSignIn)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.btnSignUp)
        Me.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "CreateNewEmployee"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Create New User Account"
        Me.gbPersonalInfo.ResumeLayout(False)
        Me.gbPersonalInfo.PerformLayout()
        Me.gbLoginInfo.ResumeLayout(False)
        Me.gbLoginInfo.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents gbPersonalInfo As System.Windows.Forms.GroupBox
    Friend WithEvents dtpDateOfBirth As System.Windows.Forms.DateTimePicker
    Friend WithEvents txtMobileNo As System.Windows.Forms.TextBox
    Friend WithEvents txtZIPCode As System.Windows.Forms.TextBox
    Friend WithEvents txtEmailID As System.Windows.Forms.TextBox
    Friend WithEvents lblMobileNo As System.Windows.Forms.Label
    Friend WithEvents txtAddress As System.Windows.Forms.TextBox
    Friend WithEvents lblDateOfBirth As System.Windows.Forms.Label
    Friend WithEvents lblZIPCode As System.Windows.Forms.Label
    Friend WithEvents lblState As System.Windows.Forms.Label
    Friend WithEvents lblAddress As System.Windows.Forms.Label
    Friend WithEvents lblEmailID As System.Windows.Forms.Label
    Friend WithEvents gbLoginInfo As System.Windows.Forms.GroupBox
    Friend WithEvents txtConfirmPassword As System.Windows.Forms.TextBox
    Friend WithEvents txtPassword As System.Windows.Forms.TextBox
    Friend WithEvents txtLastName As System.Windows.Forms.TextBox
    Friend WithEvents txtFirstName As System.Windows.Forms.TextBox
    Friend WithEvents txtUserName As System.Windows.Forms.TextBox
    Friend WithEvents lblConfirmPassword As System.Windows.Forms.Label
    Friend WithEvents lblPassword As System.Windows.Forms.Label
    Friend WithEvents lblLastName As System.Windows.Forms.Label
    Friend WithEvents lblFirstName As System.Windows.Forms.Label
    Friend WithEvents lblUserName As System.Windows.Forms.Label
    Friend WithEvents btnSignIn As System.Windows.Forms.Button
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents btnSignUp As System.Windows.Forms.Button
    Friend WithEvents txtState As System.Windows.Forms.TextBox
    Friend WithEvents ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents txtCountry As System.Windows.Forms.TextBox
    Friend WithEvents CountryLabel As System.Windows.Forms.Label
    Friend WithEvents txtCity As System.Windows.Forms.TextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents cmbLoginType As System.Windows.Forms.ComboBox
End Class
