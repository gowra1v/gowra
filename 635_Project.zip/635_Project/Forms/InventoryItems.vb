﻿Imports System.Data.OleDb
Imports System.Security.Cryptography
Imports System.Text

Public Class InventoryItems
    Dim drInventoryItem As OleDbDataReader = Nothing
    Dim dtInventoryItem As DataTable
    Dim con As OleDbConnection = Nothing
    Dim daInventoryItem As OleDbDataAdapter
    Dim dsInventoryItem As DataSet
    Dim cmd As OleDbCommand = Nothing
    Dim dtInventory As New DataTable
    Dim InventoryTo As InventoryTodo
    Dim getInventoryID As Integer


    Private Sub InventoryItems_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        InventoryTo = New InventoryTodo()
        getInventoryID = InventoryTo.GetInventoryItemID()
        clear()
        sugInventoryNames()
    End Sub


    Private Sub btnNewItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnNewItem.Click
        clear()
        txtInventoryName.Focus()
        btnSave.Enabled = True
        btnUpdate.Enabled = False
        btnDelete.Enabled = False
        txtReOrderPoint.Enabled = True
        Dim InventoryID As Integer

        InventoryTo = New InventoryTodo()
        InventoryID = InventoryTo.GetInventoryItemID()
        If InventoryID > 0 Then
            txtInventoryID.Text = InventoryID
        Else
            txtInventoryID.Text = -1
        End If
    End Sub


    Private Sub btnSave_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSave.Click

        getInventoryID = InventoryTo.GetInventoryItemID()
        If Len(Trim(txtInventoryName.Text)) = 0 Then
            MessageBox.Show("Please enter Inventory name", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtInventoryName.Focus()
            Exit Sub
        End If
        If Len(Trim(txtCaseCount.Text)) = 0 Then
            MessageBox.Show("Please enter value for case count", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtCaseCount.Focus()
            Exit Sub
        End If
        If Len(Trim(txtAvailableQty.Text)) = 0 Then
            MessageBox.Show("Please enter Availability Quantity", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtAvailableQty.Focus()
            Exit Sub
        End If
        If Len(Trim(txtReOrderPoint.Text)) = 0 Then
            MessageBox.Show("Please enter Reorder point", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtReOrderPoint.Focus()
            Exit Sub
        End If
        If Len(Trim(txtUnitPrice.Text)) = 0 Then
            MessageBox.Show("Please enter Unit price", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
            txtUnitPrice.Focus()
            Exit Sub
        End If


        Try
            con = New OleDbConnection(SqlHelper.strConnect)
            con.Open()
            Dim ct1 As String = "select InventoryName from InventoryItems where InventoryName = '" & txtInventoryName.Text & "'"

            cmd = New OleDbCommand(ct1)
            cmd.Connection = con
            drInventoryItem = cmd.ExecuteReader()

            If drInventoryItem.Read Then
                MessageBox.Show("Entry for new Inventory already exists" & vbCrLf & "You can not make duplicate entry" & vbCrLf & "for the same Inventory Item" & vbCrLf & "please update the details of Inventory Item", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)

                If Not drInventoryItem Is Nothing Then
                    drInventoryItem.Close()
                End If
                Exit Sub
            End If

            con = New OleDbConnection(SqlHelper.strConnect)
            con.Open()

            Dim cb As String = "Insert into InventoryItems(InventoryID,InventoryName,AvailableQty,ReOrderPoint,UnitPrice, CaseCount) VALUES (@InventoryID,@InventoryName,@AvailableQty,@ReOrderPoint,@UnitPrice , @CaseCount)"

            cmd = New OleDbCommand(cb)

            cmd.Connection = con
            cmd.Parameters.Add(New OleDbParameter("@InventoryID", System.Data.OleDb.OleDbType.Integer, 11, "InventoryID"))
            cmd.Parameters.Add(New OleDbParameter("@InventoryName", System.Data.OleDb.OleDbType.VarChar, 20, "InventoryName"))
            cmd.Parameters.Add(New OleDbParameter("@AvailableQty", System.Data.OleDb.OleDbType.Integer, 11, "AvailableQty"))
            cmd.Parameters.Add(New OleDbParameter("@ReOrderPoint", System.Data.OleDb.OleDbType.Integer, 11, "ReOrderPoint"))
            cmd.Parameters.Add(New OleDbParameter("@UnitPrice", System.Data.OleDb.OleDbType.Decimal, 10, "UnitPrice"))
            cmd.Parameters.Add(New OleDbParameter("@CaseCount", System.Data.OleDb.OleDbType.VarChar, 20, "CaseCount"))

            cmd.Parameters("@InventoryID").Value = getInventoryID
            cmd.Parameters("@InventoryName").Value = txtInventoryName.Text
            cmd.Parameters("@CaseCount").Value = txtCaseCount.Text
            cmd.Parameters("@AvailableQty").Value = Convert.ToInt32(txtAvailableQty.Text)
            cmd.Parameters("@ReOrderPoint").Value = Convert.ToInt32(txtReOrderPoint.Text)
            cmd.Parameters("@UnitPrice").Value = Convert.ToDecimal(txtUnitPrice.Text)


            cmd.ExecuteReader()
            MessageBox.Show("Successfully saved " & vbNewLine & " Please click on New button to create new Inventory item", "Inventory Details", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnSave.Enabled = False
            getCategories()


            sugInventoryNames()
           
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            con.Close()
            clear()
        End Try
    End Sub

    Private Sub btnUpdate_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdate.Click
        Try
            con = New OleDbConnection(SqlHelper.strConnect)
            con.Open()

            Dim cb As String = "UPDATE InventoryItems SET InventoryName = '" & txtInventoryName.Text & "', AvailableQty= " & Convert.ToInt32(txtAvailableQty.Text) & ", ReOrderPoint = " & Convert.ToInt32(txtReOrderPoint.Text) & ", UnitPrice = '" & Convert.ToDecimal(txtUnitPrice.Text) & "', CaseCount = '" & txtCaseCount.Text & "' WHERE InventoryID = " & Convert.ToInt32(txtInventoryID.Text) & ""

            cmd = New OleDbCommand(cb)
            cmd.Connection = con
            cmd.ExecuteReader()
            MessageBox.Show("Successfully updated", "Inventory Item Details", MessageBoxButtons.OK, MessageBoxIcon.Information)
            btnUpdate.Enabled = False
            getCategories()
            sugInventoryNames()

          
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            con.Close()
            clear()
        End Try
    End Sub

    Private Sub Delete_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDelete.Click
        Try
            If MessageBox.Show("Do you really want to delete the record?", "Inventory Item Record", MessageBoxButtons.YesNo, MessageBoxIcon.Warning) = Windows.Forms.DialogResult.Yes Then
                delInventoryItems()
                clear()
                sugInventoryNames()
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub btnSearchInventoryID_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearchInventoryID.Click
        Me.clear()
        InventoryItemsRecord.fillInventoryDetails()
        InventoryItemsRecord.cmbInventoryName.Text = ""
        InventoryItemsRecord.txtInventoryName.Text = ""
        InventoryItemsRecord.dgvInventoryDetails.DataSource = Nothing
        InventoryItemsRecord.dgvInventoryData.DataSource = Nothing
        InventoryItemsRecord.Show()
    End Sub

    Private Sub delInventoryItems()
        Try
            Dim RowsAffected As Integer = 0

            con = New OleDbConnection(SqlHelper.strConnect)
            con.Open()

            Dim delIAssign As String = "DELETE FROM ItemAssignments WHERE InventoryItemID=@InventoryItemID"
            cmd = New OleDbCommand(delIAssign)
            cmd.Connection = con
            cmd.Parameters.Add(New OleDbParameter("@InventoryItemID", System.Data.OleDb.OleDbType.Integer, 20, "InventoryItemID"))
            cmd.Parameters("@InventoryItemID").Value = Convert.ToInt32(txtInventoryID.Text)
            RowsAffected = cmd.ExecuteNonQuery()


            Dim delIventoryItems As String = "DELETE FROM InventoryItems WHERE InventoryID=@InventoryID;"
            cmd = New OleDbCommand(delIventoryItems)
            cmd.Connection = con
            cmd.Parameters.Add(New OleDbParameter("@InventoryID", System.Data.OleDb.OleDbType.Integer, 20, "InventoryID"))
            cmd.Parameters("@InventoryID").Value = Convert.ToInt32(Trim(txtInventoryID.Text))
            RowsAffected = cmd.ExecuteNonQuery()

            If RowsAffected > 0 Then
                MessageBox.Show("Successfully deleted", "Record", MessageBoxButtons.OK, MessageBoxIcon.Information)
                clear()
                btnUpdate.Enabled = False
                btnDelete.Enabled = False
                getCategories()
                sugInventoryNames()
            Else
                MessageBox.Show("No record found", "Sorry", MessageBoxButtons.OK, MessageBoxIcon.Information)
                clear()
                btnUpdate.Enabled = False
                btnDelete.Enabled = False

                If con.State = ConnectionState.Open Then

                    con.Close()
                End If

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            con.Close()
        End Try

    End Sub
    Sub getCategories()
        Try
            Dim cnFill As New OleDbConnection(SqlHelper.strConnect)

            cnFill.Open()
            daInventoryItem = New OleDbDataAdapter()
            daInventoryItem.SelectCommand = New OleDbCommand("SELECT CategoryID,CategoryName FROM ItemCategories", cnFill)
            dsInventoryItem = New DataSet("ds")

            daInventoryItem.Fill(dsInventoryItem)
            dtInventoryItem = dsInventoryItem.Tables(0)
            cnFill.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        
        End Try
    End Sub



    Private Sub sugInventoryNames()
        con = New OleDbConnection(SqlHelper.strConnect)
        con.Open()

        Dim cmd As New OleDbCommand("SELECT InventoryName FROM InventoryItems", con)
        Dim dsNames As New DataSet
        Dim daNames As New OleDbDataAdapter(cmd)
        daNames.Fill(dsNames, "My List") 'list can be any name u want

        Dim sugNames As New AutoCompleteStringCollection
        Dim dsRow As Integer
        For dsRow = 0 To dsNames.Tables(0).Rows.Count - 1
            sugNames.Add(dsNames.Tables(0).Rows(dsRow)("InventoryName").ToString())

        Next
        txtInventoryName.AutoCompleteSource = AutoCompleteSource.CustomSource
        txtInventoryName.AutoCompleteCustomSource = sugNames
        txtInventoryName.AutoCompleteMode = AutoCompleteMode.Suggest

        con.Close()
    End Sub

    Private Sub InventoryItems_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing

        If MessageBox.Show("Please save any unsaved changes and then navigate to main menu view?", "Are you sure to Exit?", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = Windows.Forms.DialogResult.OK Then
            clear()
            ' Me.Hide()
            MainForm.Show()
        Else
            e.Cancel = True
        End If
    End Sub
    


    Private Sub txtUnitPrice_KeyPress(ByVal sender As Object, ByVal e As System.Windows.Forms.KeyPressEventArgs) Handles txtUnitPrice.KeyPress
        Dim keyChar = e.KeyChar
        If Char.IsControl(keyChar) Then
            'Allow all control characters.
        ElseIf Char.IsDigit(keyChar) OrElse keyChar = "."c Then
            Dim text = Me.txtUnitPrice.Text
            Dim selectionStart = Me.txtUnitPrice.SelectionStart
            Dim selectionLength = Me.txtUnitPrice.SelectionLength

            text = text.Substring(0, selectionStart) & keyChar & text.Substring(selectionStart + selectionLength)

            If Integer.TryParse(text, New Integer) AndAlso text.Length > 16 Then
                'Reject an integer that is longer than 16 digits.
                e.Handled = True
            ElseIf Double.TryParse(text, New Double) AndAlso text.IndexOf("."c) < text.Length - 3 Then
                'Reject a real number with two many decimal places.
                e.Handled = False
            End If
        Else
            'Reject all other characters.
            e.Handled = True
        End If
    End Sub


    Private Sub btnHome_Click(sender As System.Object, e As System.EventArgs) Handles btnHome.Click
        If MessageBox.Show("Please save any unsaved changes and then navigate to main menu view?", "Are you sure to Exit?", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = Windows.Forms.DialogResult.OK Then
            Me.Hide()
            clear()
            MainForm.Show()
        End If
    End Sub

    Private Sub clear()
        txtInventoryID.Text = ""
        txtInventoryName.Text = ""
        txtCaseCount.Text = ""
        txtAvailableQty.Text = ""
        txtReOrderPoint.Text = ""
        txtUnitPrice.Text = ""
        
    End Sub
End Class