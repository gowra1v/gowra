Imports System.Net.Mail
Public Class SendPromotions
    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim smtpServer As New SmtpClient()
        Dim mail As New MailMessage
        Dim mobile As String = ""
        Dim smsCarriers(3) As String
        smsCarriers(0) = "@txt.att.net"
        smsCarriers(1) = "@vtext.com"
        smsCarriers(2) = "@tmomail.net"
        smsCarriers(3) = "@messaging.sprintpcs.com"

        ' Display.
        
        smtpServer.Credentials = New Net.NetworkCredential("popeyes.mtpleasant@gmail.com", "bisgroup3")
        smtpServer.Port = 587
        smtpServer.Host = "smtp.gmail.com"
        smtpServer.EnableSsl = True
        mail.From = New MailAddress("popeyes.mtpleasant@gmail.com", "Popeyes Chicken")
        If rbSMS.Checked = True Then
            If (txtToEmailID.Text = "") Then
                MessageBox.Show("Please enter 10-digit mobile number to send SMS", "Phone Number Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtToEmailID.Focus()
                Exit Sub
            ElseIf txtToEmailID.Text.Trim().Length > 10 Then
                MessageBox.Show("Please enter 10-digit mobile number to send SMS", "Phone Number Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtToEmailID.Focus()
                Exit Sub
            End If
            mail.To.Add(txtToEmailID.Text & "@vtext.com")
        ElseIf rbMail.Checked = True Then
            If (txtToEmailID.Text = "") Then
                MessageBox.Show("Please enter email id to send email", "EmailID Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                txtToEmailID.Focus()
                Exit Sub
            Else
                mail.To.Add(txtToEmailID.Text)
            End If
        End If
        If rbSMS.Checked Then
            For Each element As String In smsCarriers
                mail.Subject = txtEmailSubject.Text
                mail.Body = txtEmailMessage.Text()
                mobile = txtToEmailID.Text & element
                mail.To.Add(mobile)
                smtpServer.Send(mail)
            Next
            'mail.Subject = txtEmailSubject.Text
            'mail.Body = txtEmailMessage.Text()

            'mail.To.Add(txtToEmailID.Text & "@vtext.com")
            'smtpServer.Send(mail)
            MsgBox("SMS is sent successfully", MsgBoxStyle.OkOnly, "Message Sent")

            Exit Sub
        End If
            mail.Subject = txtEmailSubject.Text
            mail.Body = txtEmailMessage.Text()
            smtpServer.Send(mail)
        MsgBox("Mail is sent", MsgBoxStyle.OkOnly, "Mail")
    End Sub

    Private Sub rbSMS_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbSMS.CheckedChanged
        txtToEmailID.Enabled = True
    End Sub

    Private Sub rbMail_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rbMail.CheckedChanged
        txtToEmailID.Enabled = True
    End Sub
    Private Sub txtToEmailID_KeyPress(sender As System.Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtToEmailID.KeyPress
        If rbSMS.Checked Then
            If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Then
                e.Handled = False
            Else
                e.Handled = True
                MessageBox.Show("Please enter numbers and Mobile Number cannot be more than 10 characters", "MobileNumber", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If
        End If
    End Sub

    Private Sub Button2_Click(sender As System.Object, e As System.EventArgs) Handles btnClose.Click
        Me.Hide()
        MainForm.Show()
    End Sub
    Sub Clear()
        txtEmailMessage.Text = ""
        txtEmailSubject.Text = ""
        txtToEmailID.Text = ""
        rbMail.Checked = False
        rbSMS.Checked = False
    End Sub

    Private Sub SendPromotions_FormClosing(sender As System.Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Me.Hide()
        Clear()
        MainForm.Show()
    End Sub

    Private Sub SendPromotions_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

    End Sub
End Class
