﻿Imports System.Data.OleDB
Public Class InventoryCategoryRecord
    Dim drCategory As OleDbDataReader = Nothing
    Dim con As OleDbConnection = Nothing
    Dim cmdCategory As OleDbCommand = Nothing

    Private ReadOnly Property Connection() As OleDbConnection
        Get
            Dim getConnection As New OleDbConnection(SqlHelper.strConnect)
            getConnection.Open()
            Return getConnection
        End Get
    End Property
    Public Function GetData() As DataView
        Dim selCategories = "SELECT (CategoryID) as [Category ID],(CategoryName) as [Category Name] from ItemCategories order by CategoryID"

        Dim dsCategories As New DataSet
        Dim dvCategories As DataView
        Try
            Dim SampleCommand As New OleDbCommand()
            Dim SampleDataAdapter = New OleDbDataAdapter()
            SampleCommand.CommandText = selCategories
            SampleCommand.Connection = Connection
            SampleDataAdapter.SelectCommand = SampleCommand
            SampleDataAdapter.Fill(dsCategories)
            dvCategories = dsCategories.Tables(0).DefaultView
        Catch ex As Exception
            Throw ex
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
        Return dvCategories
    End Function
    Private Sub btnResetCategories_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnResetCategories.Click
        dgvCategoryDetails.DataBindings.Clear()
        dgvCategoryDetails.DataSource = Nothing

    End Sub

    Private Sub btnGetCategories_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetCategories.Click
        dgvCategoryDetails.DataBindings.Clear()
        dgvCategoryDetails.DataSource = GetData()
    End Sub

    Private Sub frmInventoryCategoryRecord_FormClosing(ByVal sender As Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Me.Hide()
        InventoryCategory.Show()
    End Sub

    Private Sub dgvCategoryDetails_MouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.MouseEventArgs) Handles dgvCategoryDetails.MouseClick
        Try
            Dim dgvCategoryrow As DataGridViewRow = dgvCategoryDetails.SelectedRows(0)
            Me.Hide()
            InventoryCategory.Show()
            InventoryCategory.txtCategoryID.Text = dgvCategoryrow.Cells(0).Value.ToString()
            InventoryCategory.txtCategoryName.Text = dgvCategoryrow.Cells(1).Value.ToString()
            InventoryCategory.btnUpdate.Enabled = True
            InventoryCategory.btnDelete.Enabled = True
            InventoryCategory.btnSave.Enabled = False
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub btnBack_Click(sender As System.Object, e As System.EventArgs) Handles btnBack.Click
        Me.Hide()
        InventoryCategory.Show()
    End Sub
End Class