﻿Imports System.Data.OleDB
Imports Excel = Microsoft.Office.Interop.Excel
Public Class InventoryItemsRecord
    Dim drItemRecord As OleDbDataReader = Nothing
    Dim dtItemRecord As DataTable
    Dim con As OleDbConnection = Nothing
    Dim daItemRecord As OleDbDataAdapter
    Dim dsItemRecord As DataSet
    Dim cmd As OleDbCommand = Nothing
    Dim dt As New DataTable

    Dim InventoryName As String

    Sub selInventoryName(frmInventoryName As String)
        InventoryName = frmInventoryName
        cmbInventoryName.Text = ""
        txtInventoryName.Text = ""
        dgvInventoryData.DataBindings.Clear()
        dgvInventoryDetails.DataBindings.Clear()
        dgvInventoryDetails.DataSource = Nothing
        dgvInventoryData.DataSource = Nothing
        fillInventoryDetails()

    End Sub

    Private Sub btnGetAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetAll.Click
        con = New OleDbConnection(SqlHelper.strConnect)
        Try

            con.Open()
            cmd = New OleDbCommand("SELECT (InventoryID) as [Inventory ID],(InventoryName) as [Inventory Name],(CaseCount) As [Case Count],(AvailableQty) as [Available Quantity], (ReorderPoint) as [Reorder Point],(UnitPrice) as [UnitPrice] from InventoryItems order by InventoryName", con)

            Dim daItems As OleDbDataAdapter = New OleDbDataAdapter(cmd)
            Dim dsItems As DataSet = New DataSet()

            daItems.Fill(dsItems, "InventoryItems")
            dgvInventoryData.DataSource = dsItems.Tables("InventoryItems").DefaultView

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub btnExportAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExportAll.Click
        If dgvInventoryData.RowCount = Nothing Then
            MessageBox.Show("Sorry nothing to export into excel sheet.." & vbCrLf & "Please retrieve data in datagridview", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        Dim rowsTotal, colsTotal As Short
        Dim rowIndex, colindex, rowColumn As Short
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Dim xlApp As New Excel.Application

        Try
            Dim excelBook As Excel.Workbook = xlApp.Workbooks.Add
            Dim excelWorksheet As Excel.Worksheet = CType(excelBook.Worksheets(1), Excel.Worksheet)
            xlApp.Visible = True

            rowsTotal = dgvInventoryData.RowCount - 1
            colsTotal = dgvInventoryData.Columns.Count - 1
            With excelWorksheet
                .Cells.Select()
                .Cells.Delete()
                For rowColumn = 0 To colsTotal
                    .Cells(1, rowColumn + 1).Value = dgvInventoryData.Columns(rowColumn).HeaderText
                Next
                For rowIndex = 0 To rowsTotal - 1
                    For colindex = 0 To colsTotal
                        .Cells(rowIndex + 2, colindex + 1).value = dgvInventoryData.Rows(rowIndex).Cells(colindex).Value
                    Next colindex
                Next rowIndex
                .Rows("1:1").Font.FontStyle = "Bold"
                .Rows("1:1").Font.Size = 12

                .Cells.Columns.AutoFit()
                .Cells.Select()
                .Cells.EntireColumn.AutoFit()
                .Cells(1, 1).Select()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            'RELEASE ALLOACTED RESOURCES
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            xlApp = Nothing
        End Try
    End Sub

    Private Sub btnInventoryExport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInventoryExport.Click
        If dgvInventoryDetails.RowCount = Nothing Then
            MessageBox.Show("Sorry nothing to export into excel sheet.." & vbCrLf & "Please retrieve data in datagridview", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        Dim rowsTotal, colsTotal As Short
        'Dim rowIndex, colindex, rowColumn As Short
        Dim rowIndex, colindex, rowColumn As Short
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Dim xlApp As New Excel.Application

        Try
            Dim excelBook As Excel.Workbook = xlApp.Workbooks.Add
            Dim excelWorksheet As Excel.Worksheet = CType(excelBook.Worksheets(1), Excel.Worksheet)
            xlApp.Visible = True

            rowsTotal = dgvInventoryDetails.RowCount - 1
            colsTotal = dgvInventoryDetails.Columns.Count - 1
            With excelWorksheet
                .Cells.Select()
                .Cells.Delete()
                For rowColumn = 0 To colsTotal
                    .Cells(1, rowColumn + 1).Value = dgvInventoryDetails.Columns(rowColumn).HeaderText
                Next
                For rowIndex = 0 To rowsTotal - 1
                    For colindex = 0 To colsTotal
                        .Cells(rowIndex + 2, colindex + 1).value = dgvInventoryDetails.Rows(rowIndex).Cells(colindex).Value
                    Next colindex
                Next rowIndex
                .Rows("1:1").Font.FontStyle = "Bold"
                .Rows("1:1").Font.Size = 12

                .Cells.Columns.AutoFit()
                .Cells.Select()
                .Cells.EntireColumn.AutoFit()
                .Cells(1, 1).Select()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            'RELEASE ALLOACTED RESOURCES
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            xlApp = Nothing
        End Try
    End Sub

    Private Sub btnResetInventory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnResetInventory.Click
        cmbInventoryName.Text = ""
        txtInventoryName.Text = ""

        dgvInventoryDetails.DataBindings.Clear()
        dgvInventoryDetails.DataSource = Nothing
    End Sub

    Private Sub btnResetAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnResetAll.Click
        dgvInventoryData.DataBindings.Clear()
        dgvInventoryData.DataSource = Nothing
    End Sub

    Private Sub InventoryTabControl_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles InventoryTabControl.Click

        cmbInventoryName.Text = ""
        txtInventoryName.Text = ""
        dgvInventoryDetails.DataBindings.Clear()
        dgvInventoryData.DataBindings.Clear()
        dgvInventoryDetails.DataSource = Nothing
        dgvInventoryData.DataSource = Nothing
    End Sub
    Sub fillInventoryDetails()
        Dim conn As New OleDbConnection(SqlHelper.strConnect)
        Try
            conn.Open()
            daItemRecord = New OleDbDataAdapter()
            daItemRecord.SelectCommand = New OleDbCommand("SELECT InventoryID, InventoryName FROM InventoryItems", conn)
            dsItemRecord = New DataSet("ds")

            daItemRecord.Fill(dsItemRecord)
            dtItemRecord = dsItemRecord.Tables(0)

            cmbInventoryName.DataBindings.Clear()
            cmbInventoryName.DataSource = Nothing

            With cmbInventoryName
                .DataSource = dtItemRecord
                .DisplayMember = "InventoryName"
                .ValueMember = "InventoryID"

            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            conn.Close()
        End Try

    End Sub

    Sub fillCategoryDetails()
        Dim conn As New OleDbConnection(SqlHelper.strConnect)
        Try
            conn.Open()
            daItemRecord = New OleDbDataAdapter()
            daItemRecord.SelectCommand = New OleDbCommand("SELECT CategoryID,CategoryName FROM ItemCategories", conn)
            dsItemRecord = New DataSet("ds")

            daItemRecord.Fill(dsItemRecord)
            dtItemRecord = dsItemRecord.Tables(0)

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub InventoryItemsRecord_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        If InventoryName = "selInventoryID" Then
            MenuItems.Show()
            InventoryName = ""
        Else
            InventoryItems.Show()
            InventoryName = ""
        End If
    End Sub


    Private Sub cmbInventoryName_SelectionChangeCommitted(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbInventoryName.SelectionChangeCommitted
        con = New OleDbConnection(SqlHelper.strConnect)
        Try
            con.Open()
            cmd = New OleDbCommand("SELECT (InventoryID) as [Inventory ID],(InventoryName) as [Inventory Name],(CaseCount) As [Case Count],(AvailableQty) as [Available Quantity],(ReOrderPoint) as [Reorder Point] ,(UnitPrice) as [Unit Price] from InventoryItems WHERE InventoryName= '" & cmbInventoryName.Text & "' order by InventoryName", con)
            Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()
            myDA.Fill(myDataSet, "InventoryItems")
            dgvInventoryDetails.DataSource = myDataSet.Tables("InventoryItems").DefaultView
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub txtInventoryName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtInventoryName.TextChanged
        con = New OleDbConnection(SqlHelper.strConnect)
        Try
            con.Open()
            cmd = New OleDbCommand("SELECT (InventoryID) as [Inventory ID],(InventoryName) as [Inventory Name],(CaseCount) As [Case Count],(AvailableQty) as [Available Quantity],(UnitPrice) as [Unit Price] from InventoryItems WHERE InventoryName like '%" & txtInventoryName.Text & "%' order by InventoryName", con)

            Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()

            myDA.Fill(myDataSet, "InventoryItems")
            dgvInventoryDetails.DataSource = myDataSet.Tables("InventoryItems").DefaultView

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            con.Close()
        End Try
    End Sub

  
    Private Sub dgvInventoryData_RowHeaderMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgvInventoryData.RowHeaderMouseClick
        Try
            Dim dr As DataGridViewRow = dgvInventoryData.SelectedRows(0)
            Me.Hide()

            If InventoryName = "selInventoryID" Then
                MenuItems.txtInventoryName.Text = dr.Cells(1).Value.ToString()
                MenuItems.setInventoryID(Convert.ToInt32(dr.Cells(0).Value.ToString()))
                MenuItems.Show()

            Else

                InventoryItems.Show()
                InventoryItems.txtInventoryID.Text = dr.Cells(0).Value.ToString()
                InventoryItems.txtInventoryName.Text = dr.Cells(1).Value.ToString()
                InventoryItems.txtCaseCount.Text = dr.Cells(2).Value.ToString()
                InventoryItems.txtAvailableQty.Text = dr.Cells(3).Value.ToString()
                InventoryItems.txtReOrderPoint.Text = dr.Cells(4).Value.ToString()
                InventoryItems.txtUnitPrice.Text = dr.Cells(5).Value.ToString()
                InventoryItems.btnUpdate.Enabled = True
                InventoryItems.btnDelete.Enabled = True
                InventoryItems.btnSave.Enabled = False

            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgvInventoryDetails_RowHeaderMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgvInventoryDetails.RowHeaderMouseClick
        Try
            Dim dr As DataGridViewRow = dgvInventoryDetails.SelectedRows(0)
            Me.Hide()
            InventoryItems.Show()

            InventoryItems.txtInventoryID.Text = dr.Cells(0).Value.ToString()
            InventoryItems.txtInventoryName.Text = dr.Cells(1).Value.ToString()
            InventoryItems.txtCaseCount.Text = dr.Cells(2).Value.ToString()
            InventoryItems.txtAvailableQty.Text = dr.Cells(3).Value.ToString()
            InventoryItems.txtReOrderPoint.Text = dr.Cells(4).Value.ToString()
            InventoryItems.txtUnitPrice.Text = dr.Cells(5).Value.ToString()
            InventoryItems.btnUpdate.Enabled = True
            InventoryItems.btnDelete.Enabled = True
            InventoryItems.btnSave.Enabled = False

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

End Class