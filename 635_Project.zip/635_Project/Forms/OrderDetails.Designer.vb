﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class OrderDetails
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(OrderDetails))
        Me.Label6 = New System.Windows.Forms.Label()
        Me.MenuItemsComboBox = New System.Windows.Forms.ComboBox()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.txtQuantity = New System.Windows.Forms.TextBox()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtUnitPrice = New System.Windows.Forms.TextBox()
        Me.btnAddMenuItems = New System.Windows.Forms.Button()
        Me.OrderDetailsListView = New System.Windows.Forms.ListView()
        Me.ItemID = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.ItemName = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.Quantity = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.UnitPrice = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.TotalAmount = CType(New System.Windows.Forms.ColumnHeader(), System.Windows.Forms.ColumnHeader)
        Me.btnRemove = New System.Windows.Forms.Button()
        Me.PlaceOrderButton = New System.Windows.Forms.Button()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.cmbPaymentType = New System.Windows.Forms.ComboBox()
        Me.btnApply = New System.Windows.Forms.Button()
        Me.btnSearchPromoCode = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.txtPromoDiscount = New System.Windows.Forms.TextBox()
        Me.lblPromotionCode = New System.Windows.Forms.Label()
        Me.txtPrmotionCode = New System.Windows.Forms.TextBox()
        Me.txtTotalPayment = New System.Windows.Forms.TextBox()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.payment = New System.Windows.Forms.Label()
        Me.txtTotal = New System.Windows.Forms.TextBox()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.txtTaxAmt = New System.Windows.Forms.TextBox()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.txtTaxPer = New System.Windows.Forms.TextBox()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.txtSubTotal = New System.Windows.Forms.TextBox()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.btnPayment = New System.Windows.Forms.Button()
        Me.txtOrderID = New System.Windows.Forms.TextBox()
        Me.OrderIDLbs = New System.Windows.Forms.Label()
        Me.OrderDateLbs = New System.Windows.Forms.Label()
        Me.dtpOrderDate = New System.Windows.Forms.DateTimePicker()
        Me.btnClear = New System.Windows.Forms.Button()
        Me.PrintPreviewDialog1 = New System.Windows.Forms.PrintPreviewDialog()
        Me.PrintOrderDocument = New System.Drawing.Printing.PrintDocument()
        Me.btnHome = New System.Windows.Forms.Button()
        Me.Panel2.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Font = New System.Drawing.Font("Palatino Linotype", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label6.Location = New System.Drawing.Point(72, 99)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(31, 16)
        Me.Label6.TabIndex = 52
        Me.Label6.Text = "Item"
        '
        'MenuItemsComboBox
        '
        Me.MenuItemsComboBox.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.MenuItemsComboBox.Location = New System.Drawing.Point(39, 124)
        Me.MenuItemsComboBox.Name = "MenuItemsComboBox"
        Me.MenuItemsComboBox.Size = New System.Drawing.Size(121, 21)
        Me.MenuItemsComboBox.TabIndex = 53
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Font = New System.Drawing.Font("Palatino Linotype", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label7.Location = New System.Drawing.Point(216, 99)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(51, 16)
        Me.Label7.TabIndex = 54
        Me.Label7.Text = "Quantity"
        '
        'txtQuantity
        '
        Me.txtQuantity.Location = New System.Drawing.Point(208, 124)
        Me.txtQuantity.Name = "txtQuantity"
        Me.txtQuantity.Size = New System.Drawing.Size(76, 20)
        Me.txtQuantity.TabIndex = 55
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Palatino Linotype", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(363, 99)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(58, 16)
        Me.Label8.TabIndex = 56
        Me.Label8.Text = "Unit Price"
        '
        'txtUnitPrice
        '
        Me.txtUnitPrice.Location = New System.Drawing.Point(351, 125)
        Me.txtUnitPrice.Name = "txtUnitPrice"
        Me.txtUnitPrice.ReadOnly = True
        Me.txtUnitPrice.Size = New System.Drawing.Size(88, 20)
        Me.txtUnitPrice.TabIndex = 57
        '
        'btnAddMenuItems
        '
        Me.btnAddMenuItems.BackColor = System.Drawing.SystemColors.Control
        Me.btnAddMenuItems.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnAddMenuItems.Location = New System.Drawing.Point(479, 122)
        Me.btnAddMenuItems.Name = "btnAddMenuItems"
        Me.btnAddMenuItems.Size = New System.Drawing.Size(83, 23)
        Me.btnAddMenuItems.TabIndex = 58
        Me.btnAddMenuItems.Text = "&Add"
        Me.btnAddMenuItems.UseVisualStyleBackColor = False
        '
        'OrderDetailsListView
        '
        Me.OrderDetailsListView.Columns.AddRange(New System.Windows.Forms.ColumnHeader() {Me.ItemID, Me.ItemName, Me.Quantity, Me.UnitPrice, Me.TotalAmount})
        Me.OrderDetailsListView.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OrderDetailsListView.FullRowSelect = True
        Me.OrderDetailsListView.GridLines = True
        Me.OrderDetailsListView.Location = New System.Drawing.Point(25, 188)
        Me.OrderDetailsListView.Name = "OrderDetailsListView"
        Me.OrderDetailsListView.Size = New System.Drawing.Size(662, 273)
        Me.OrderDetailsListView.TabIndex = 97
        Me.OrderDetailsListView.UseCompatibleStateImageBehavior = False
        Me.OrderDetailsListView.View = System.Windows.Forms.View.Details
        '
        'ItemID
        '
        Me.ItemID.Text = "Item ID"
        Me.ItemID.Width = 125
        '
        'ItemName
        '
        Me.ItemName.Text = "Item Name"
        Me.ItemName.Width = 125
        '
        'Quantity
        '
        Me.Quantity.Text = "Quantity"
        Me.Quantity.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.Quantity.Width = 145
        '
        'UnitPrice
        '
        Me.UnitPrice.Text = "Unit Price"
        Me.UnitPrice.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.UnitPrice.Width = 130
        '
        'TotalAmount
        '
        Me.TotalAmount.Text = "Total Amount"
        Me.TotalAmount.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        Me.TotalAmount.Width = 130
        '
        'btnRemove
        '
        Me.btnRemove.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnRemove.Location = New System.Drawing.Point(581, 122)
        Me.btnRemove.Name = "btnRemove"
        Me.btnRemove.Size = New System.Drawing.Size(89, 23)
        Me.btnRemove.TabIndex = 99
        Me.btnRemove.Text = "&Remove"
        Me.btnRemove.UseVisualStyleBackColor = True
        '
        'PlaceOrderButton
        '
        Me.PlaceOrderButton.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.PlaceOrderButton.Location = New System.Drawing.Point(764, 370)
        Me.PlaceOrderButton.Name = "PlaceOrderButton"
        Me.PlaceOrderButton.Size = New System.Drawing.Size(99, 29)
        Me.PlaceOrderButton.TabIndex = 100
        Me.PlaceOrderButton.Text = "&Place Order"
        Me.PlaceOrderButton.UseVisualStyleBackColor = True
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.cmbPaymentType)
        Me.Panel2.Controls.Add(Me.btnApply)
        Me.Panel2.Controls.Add(Me.btnSearchPromoCode)
        Me.Panel2.Controls.Add(Me.Label1)
        Me.Panel2.Controls.Add(Me.txtPromoDiscount)
        Me.Panel2.Controls.Add(Me.lblPromotionCode)
        Me.Panel2.Controls.Add(Me.txtPrmotionCode)
        Me.Panel2.Controls.Add(Me.txtTotalPayment)
        Me.Panel2.Controls.Add(Me.Label19)
        Me.Panel2.Controls.Add(Me.payment)
        Me.Panel2.Controls.Add(Me.txtTotal)
        Me.Panel2.Controls.Add(Me.Label16)
        Me.Panel2.Controls.Add(Me.txtTaxAmt)
        Me.Panel2.Controls.Add(Me.Label24)
        Me.Panel2.Controls.Add(Me.txtTaxPer)
        Me.Panel2.Controls.Add(Me.Label15)
        Me.Panel2.Controls.Add(Me.txtSubTotal)
        Me.Panel2.Controls.Add(Me.Label14)
        Me.Panel2.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Panel2.Location = New System.Drawing.Point(754, 99)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(371, 259)
        Me.Panel2.TabIndex = 98
        '
        'cmbPaymentType
        '
        Me.cmbPaymentType.Enabled = False
        Me.cmbPaymentType.FormattingEnabled = True
        Me.cmbPaymentType.Location = New System.Drawing.Point(133, 207)
        Me.cmbPaymentType.Name = "cmbPaymentType"
        Me.cmbPaymentType.Size = New System.Drawing.Size(111, 25)
        Me.cmbPaymentType.TabIndex = 103
        '
        'btnApply
        '
        Me.btnApply.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnApply.Location = New System.Drawing.Point(254, 80)
        Me.btnApply.Name = "btnApply"
        Me.btnApply.Size = New System.Drawing.Size(61, 25)
        Me.btnApply.TabIndex = 102
        Me.btnApply.Text = "Apply Code"
        Me.btnApply.UseVisualStyleBackColor = True
        '
        'btnSearchPromoCode
        '
        Me.btnSearchPromoCode.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnSearchPromoCode.Location = New System.Drawing.Point(254, 50)
        Me.btnSearchPromoCode.Name = "btnSearchPromoCode"
        Me.btnSearchPromoCode.Size = New System.Drawing.Size(61, 25)
        Me.btnSearchPromoCode.TabIndex = 101
        Me.btnSearchPromoCode.Text = "Check"
        Me.btnSearchPromoCode.UseVisualStyleBackColor = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(19, 82)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(97, 17)
        Me.Label1.TabIndex = 99
        Me.Label1.Text = "Promo Discount"
        '
        'txtPromoDiscount
        '
        Me.txtPromoDiscount.BackColor = System.Drawing.SystemColors.Control
        Me.txtPromoDiscount.Location = New System.Drawing.Point(133, 81)
        Me.txtPromoDiscount.Name = "txtPromoDiscount"
        Me.txtPromoDiscount.Size = New System.Drawing.Size(109, 24)
        Me.txtPromoDiscount.TabIndex = 100
        '
        'lblPromotionCode
        '
        Me.lblPromotionCode.AutoSize = True
        Me.lblPromotionCode.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPromotionCode.Location = New System.Drawing.Point(19, 53)
        Me.lblPromotionCode.Name = "lblPromotionCode"
        Me.lblPromotionCode.Size = New System.Drawing.Size(78, 17)
        Me.lblPromotionCode.TabIndex = 4
        Me.lblPromotionCode.Text = "Promo Code"
        '
        'txtPrmotionCode
        '
        Me.txtPrmotionCode.BackColor = System.Drawing.SystemColors.Control
        Me.txtPrmotionCode.Location = New System.Drawing.Point(133, 51)
        Me.txtPrmotionCode.Name = "txtPrmotionCode"
        Me.txtPrmotionCode.Size = New System.Drawing.Size(109, 24)
        Me.txtPrmotionCode.TabIndex = 8
        '
        'txtTotalPayment
        '
        Me.txtTotalPayment.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.txtTotalPayment.Enabled = False
        Me.txtTotalPayment.Location = New System.Drawing.Point(133, 176)
        Me.txtTotalPayment.Name = "txtTotalPayment"
        Me.txtTotalPayment.Size = New System.Drawing.Size(111, 24)
        Me.txtTotalPayment.TabIndex = 1
        '
        'Label19
        '
        Me.Label19.AutoSize = True
        Me.Label19.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label19.Location = New System.Drawing.Point(19, 207)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(89, 17)
        Me.Label19.TabIndex = 96
        Me.Label19.Text = "Payment Type"
        '
        'payment
        '
        Me.payment.AutoSize = True
        Me.payment.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.payment.Location = New System.Drawing.Point(19, 176)
        Me.payment.Name = "payment"
        Me.payment.Size = New System.Drawing.Size(89, 17)
        Me.payment.TabIndex = 95
        Me.payment.Text = "Total Payment"
        '
        'txtTotal
        '
        Me.txtTotal.Location = New System.Drawing.Point(133, 147)
        Me.txtTotal.Name = "txtTotal"
        Me.txtTotal.ReadOnly = True
        Me.txtTotal.Size = New System.Drawing.Size(111, 24)
        Me.txtTotal.TabIndex = 3
        '
        'Label16
        '
        Me.Label16.AutoSize = True
        Me.Label16.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label16.Location = New System.Drawing.Point(19, 148)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(75, 17)
        Me.Label16.TabIndex = 94
        Me.Label16.Text = "Grand Total"
        '
        'txtTaxAmt
        '
        Me.txtTaxAmt.Location = New System.Drawing.Point(237, 112)
        Me.txtTaxAmt.Name = "txtTaxAmt"
        Me.txtTaxAmt.ReadOnly = True
        Me.txtTaxAmt.Size = New System.Drawing.Size(80, 24)
        Me.txtTaxAmt.TabIndex = 2
        '
        'Label24
        '
        Me.Label24.AutoSize = True
        Me.Label24.BackColor = System.Drawing.Color.White
        Me.Label24.Font = New System.Drawing.Font("Palatino Linotype", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label24.ForeColor = System.Drawing.Color.Black
        Me.Label24.Location = New System.Drawing.Point(191, 112)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(23, 22)
        Me.Label24.TabIndex = 92
        Me.Label24.Text = "%"
        '
        'txtTaxPer
        '
        Me.txtTaxPer.BackColor = System.Drawing.SystemColors.Control
        Me.txtTaxPer.Location = New System.Drawing.Point(133, 114)
        Me.txtTaxPer.Name = "txtTaxPer"
        Me.txtTaxPer.Size = New System.Drawing.Size(52, 24)
        Me.txtTaxPer.TabIndex = 0
        '
        'Label15
        '
        Me.Label15.AutoSize = True
        Me.Label15.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label15.Location = New System.Drawing.Point(19, 115)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(27, 17)
        Me.Label15.TabIndex = 90
        Me.Label15.Text = "Tax"
        '
        'txtSubTotal
        '
        Me.txtSubTotal.Location = New System.Drawing.Point(133, 16)
        Me.txtSubTotal.Name = "txtSubTotal"
        Me.txtSubTotal.ReadOnly = True
        Me.txtSubTotal.Size = New System.Drawing.Size(184, 24)
        Me.txtSubTotal.TabIndex = 7
        '
        'Label14
        '
        Me.Label14.AutoSize = True
        Me.Label14.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label14.Location = New System.Drawing.Point(19, 16)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(61, 17)
        Me.Label14.TabIndex = 77
        Me.Label14.Text = "Sub Total"
        '
        'btnPayment
        '
        Me.btnPayment.Enabled = False
        Me.btnPayment.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnPayment.Location = New System.Drawing.Point(890, 370)
        Me.btnPayment.Name = "btnPayment"
        Me.btnPayment.Size = New System.Drawing.Size(98, 29)
        Me.btnPayment.TabIndex = 102
        Me.btnPayment.Text = "&Pay"
        Me.btnPayment.UseVisualStyleBackColor = True
        '
        'txtOrderID
        '
        Me.txtOrderID.BackColor = System.Drawing.SystemColors.Control
        Me.txtOrderID.Enabled = False
        Me.txtOrderID.Location = New System.Drawing.Point(138, 33)
        Me.txtOrderID.Name = "txtOrderID"
        Me.txtOrderID.Size = New System.Drawing.Size(100, 20)
        Me.txtOrderID.TabIndex = 6
        '
        'OrderIDLbs
        '
        Me.OrderIDLbs.AutoSize = True
        Me.OrderIDLbs.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OrderIDLbs.Location = New System.Drawing.Point(43, 36)
        Me.OrderIDLbs.Name = "OrderIDLbs"
        Me.OrderIDLbs.Size = New System.Drawing.Size(59, 17)
        Me.OrderIDLbs.TabIndex = 0
        Me.OrderIDLbs.Text = "Order ID"
        '
        'OrderDateLbs
        '
        Me.OrderDateLbs.AutoSize = True
        Me.OrderDateLbs.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.OrderDateLbs.Location = New System.Drawing.Point(281, 36)
        Me.OrderDateLbs.Name = "OrderDateLbs"
        Me.OrderDateLbs.Size = New System.Drawing.Size(70, 17)
        Me.OrderDateLbs.TabIndex = 3
        Me.OrderDateLbs.Text = "Order Date"
        '
        'dtpOrderDate
        '
        Me.dtpOrderDate.Format = System.Windows.Forms.DateTimePickerFormat.[Short]
        Me.dtpOrderDate.Location = New System.Drawing.Point(365, 32)
        Me.dtpOrderDate.Margin = New System.Windows.Forms.Padding(2)
        Me.dtpOrderDate.Name = "dtpOrderDate"
        Me.dtpOrderDate.Size = New System.Drawing.Size(100, 20)
        Me.dtpOrderDate.TabIndex = 12
        '
        'btnClear
        '
        Me.btnClear.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnClear.Location = New System.Drawing.Point(1009, 370)
        Me.btnClear.Name = "btnClear"
        Me.btnClear.Size = New System.Drawing.Size(102, 29)
        Me.btnClear.TabIndex = 103
        Me.btnClear.Text = "&Clear"
        Me.btnClear.UseVisualStyleBackColor = True
        '
        'PrintPreviewDialog1
        '
        Me.PrintPreviewDialog1.AutoScrollMargin = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.AutoScrollMinSize = New System.Drawing.Size(0, 0)
        Me.PrintPreviewDialog1.ClientSize = New System.Drawing.Size(400, 300)
        Me.PrintPreviewDialog1.Enabled = True
        Me.PrintPreviewDialog1.Icon = CType(resources.GetObject("PrintPreviewDialog1.Icon"), System.Drawing.Icon)
        Me.PrintPreviewDialog1.Name = "PrintPreviewDialog1"
        Me.PrintPreviewDialog1.Visible = False
        '
        'PrintOrderDocument
        '
        '
        'btnHome
        '
        Me.btnHome.Font = New System.Drawing.Font("Palatino Linotype", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnHome.Location = New System.Drawing.Point(967, 28)
        Me.btnHome.Name = "btnHome"
        Me.btnHome.Size = New System.Drawing.Size(129, 29)
        Me.btnHome.TabIndex = 105
        Me.btnHome.Text = "&Home"
        Me.btnHome.UseVisualStyleBackColor = True
        '
        'OrderDetails
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(1137, 482)
        Me.Controls.Add(Me.btnHome)
        Me.Controls.Add(Me.btnClear)
        Me.Controls.Add(Me.dtpOrderDate)
        Me.Controls.Add(Me.txtOrderID)
        Me.Controls.Add(Me.OrderIDLbs)
        Me.Controls.Add(Me.btnPayment)
        Me.Controls.Add(Me.OrderDateLbs)
        Me.Controls.Add(Me.btnRemove)
        Me.Controls.Add(Me.PlaceOrderButton)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.OrderDetailsListView)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.MenuItemsComboBox)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.txtQuantity)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.txtUnitPrice)
        Me.Controls.Add(Me.btnAddMenuItems)
        Me.Name = "OrderDetails"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Order Details"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents MenuItemsComboBox As System.Windows.Forms.ComboBox
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents txtQuantity As System.Windows.Forms.TextBox
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents txtUnitPrice As System.Windows.Forms.TextBox
    Friend WithEvents btnAddMenuItems As System.Windows.Forms.Button
    Friend WithEvents OrderDetailsListView As System.Windows.Forms.ListView
    Friend WithEvents ItemID As System.Windows.Forms.ColumnHeader
    Friend WithEvents ItemName As System.Windows.Forms.ColumnHeader
    Friend WithEvents Quantity As System.Windows.Forms.ColumnHeader
    Friend WithEvents UnitPrice As System.Windows.Forms.ColumnHeader
    Friend WithEvents TotalAmount As System.Windows.Forms.ColumnHeader
    Friend WithEvents btnRemove As System.Windows.Forms.Button
    Friend WithEvents PlaceOrderButton As System.Windows.Forms.Button
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents txtTotalPayment As System.Windows.Forms.TextBox
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents payment As System.Windows.Forms.Label
    Friend WithEvents txtTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents txtTaxAmt As System.Windows.Forms.TextBox
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents txtTaxPer As System.Windows.Forms.TextBox
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents txtSubTotal As System.Windows.Forms.TextBox
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents btnPayment As System.Windows.Forms.Button
    Friend WithEvents txtOrderID As System.Windows.Forms.TextBox
    Friend WithEvents OrderIDLbs As System.Windows.Forms.Label
    Friend WithEvents OrderDateLbs As System.Windows.Forms.Label
    Friend WithEvents lblPromotionCode As System.Windows.Forms.Label
    Friend WithEvents txtPrmotionCode As System.Windows.Forms.TextBox
    Friend WithEvents dtpOrderDate As System.Windows.Forms.DateTimePicker
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents txtPromoDiscount As System.Windows.Forms.TextBox
    Friend WithEvents btnSearchPromoCode As System.Windows.Forms.Button
    Friend WithEvents btnApply As System.Windows.Forms.Button
    Friend WithEvents cmbPaymentType As System.Windows.Forms.ComboBox
    Friend WithEvents btnClear As System.Windows.Forms.Button
    Friend WithEvents PrintPreviewDialog1 As System.Windows.Forms.PrintPreviewDialog
    Friend WithEvents PrintOrderDocument As System.Drawing.Printing.PrintDocument
    Friend WithEvents btnHome As System.Windows.Forms.Button
End Class
