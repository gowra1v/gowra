﻿
Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel
Public Class PromoDetails

    Dim rdr As OleDbDataReader = Nothing
    Dim dtable As DataTable
    Dim con As OleDbConnection = Nothing
    Dim adp As OleDbDataAdapter
    Dim ds As DataSet
    Dim cmd As OleDbCommand = Nothing
    Dim dt As New DataTable
    Public Shared frmEditOrders As String


    Private Sub btnGetPromoDetails_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetPromoDetails.Click
        Try

            con = New OleDbConnection(SqlHelper.strConnect)

            con.Open()
            cmd = New OleDbCommand("SELECT (PromotionID) as [Promotion ID],(PromotionDescription) as [Promotion Name],(PromotionDiscount) as [Discount],(PromotionStartDate) as [Valid From],(PromotionEndDate) as [Valid To] from Promotions WHERE Active = True", con)

            Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)

            Dim myDataSet As DataSet = New DataSet()

            myDA.Fill(myDataSet, "Promotions")

            dgvPromoDetails.DataSource = myDataSet.Tables("Promotions").DefaultView


            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub


    Private Sub dgvPromoDetails_RowHeaderMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgvPromoDetails.RowHeaderMouseClick
        Try
            Dim dr As DataGridViewRow = dgvPromoDetails.SelectedRows(0)

            If frmEditOrders = "EditOrders" Then
                EditOrderDetails.txtPrmotionCode.Text = dr.Cells(0).Value.ToString()
                EditOrderDetails.txtPromoDiscount.Text = dr.Cells(2).Value.ToString()
                Me.Hide()
                EditOrderDetails.Show()
                frmEditOrders = ""
            Else
                OrderDetails.txtPrmotionCode.Text = dr.Cells(0).Value.ToString()
                OrderDetails.txtPromoDiscount.Text = dr.Cells(2).Value.ToString()
                Me.Hide()
                OrderDetails.Show()
                frmEditOrders = ""

            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnExport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExport.Click
        Me.Hide()
        OrderDetails.Show()
       
    End Sub

    Private Sub cmbPromoStatus_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles cmbPromoStatus.SelectionChangeCommitted
        Try

            con = New OleDbConnection(SqlHelper.strConnect)

            con.Open()
            If cmbPromoStatus.SelectedText = "Active" Then
                cmd = New OleDbCommand("SELECT (PromotionID) as [Promotion ID],(PromotionDescription) as [Promotion Name],(PromotionDiscount) as [Discount],(PromotionStartDate) as [Valid From],(PromotionEndDate) as [Valid To] FROM Promotions WHERE Active = True", con)
            ElseIf cmbPromoStatus.SelectedText = "InActive" Then
                cmd = New OleDbCommand("SELECT (PromotionID) as [Promotion ID],(PromotionDescription) as [Promotion Name],(PromotionDiscount) as [Discount],(PromotionStartDate) as [Valid From],(PromotionEndDate) as [Valid To] from Promotions WHERE Active = False", con)
            Else
                cmd = New OleDbCommand("SELECT (PromotionID) as [Promotion ID],(PromotionDescription) as [Promotion Name],(PromotionDiscount) as [Discount],(PromotionStartDate) as [Valid From],(PromotionEndDate) as [Valid To] FROM Promotions WHERE Active = True", con)
            End If
            Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)

            Dim myDataSet As DataSet = New DataSet()

            myDA.Fill(myDataSet, "Promotions")

            dgvPromoDetails.DataSource = myDataSet.Tables("Promotions").DefaultView


            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub PromoDetails_FormClosing(sender As System.Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Me.Hide()
        OrderDetails.Show()
    End Sub
End Class