﻿Public Class CreateNewEmployee
    Dim EmployeeTodo As EmployeeTodo

    Private Sub btnSignUp_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSignUp.Click
        Try
            Dim insertStatus As Integer
            If txtUserName.Text = "" Then
                MessageBox.Show("UserName cannot be blank", "UserName", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf txtPassword.Text = "" Then
                MessageBox.Show("Password cannot be blank", "Password", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf txtConfirmPassword.Text = "" Then
                MessageBox.Show("Confirm Password cannot be blank", "Confirm Password", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf txtFirstName.Text = "" Then
                MessageBox.Show("First Name cannot be blank", "First Name", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf txtLastName.Text = "" Then
                MessageBox.Show("Last Name cannot be blank", "Last Name", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf cmbLoginType.Text = "" Then
                MessageBox.Show("Select Login Type", "Login Type", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf txtAddress.Text = "" Then
                MessageBox.Show("Address cannot be blank", "Address", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf dtpDateOfBirth.Value >= Date.Today Then
                MessageBox.Show("Please select date less than current date", "Date Of Birth", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf txtState.Text = "" Then
                MessageBox.Show("State cannot be blank", "State", MessageBoxButtons.OK, MessageBoxIcon.Error)            
            ElseIf txtCountry.Text = "" Then
                MessageBox.Show("Country cannot be blank", "Country", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf txtCity.Text = "" Then
                MessageBox.Show("City cannot be blank", "City", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf txtZIPCode.Text = "" Then
                MessageBox.Show("ZipCode cannot be blank", "ZipCode", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf txtEmailID.Text = "" Then
                MessageBox.Show("EmailID cannot be blank", "EmailID", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf txtMobileNo.Text = "" Then
                MessageBox.Show("MobileNo cannot be blank", "MobileNo", MessageBoxButtons.OK, MessageBoxIcon.Error)
            ElseIf (txtPassword.Text <> txtConfirmPassword.Text) Then
                MessageBox.Show("Password and Confirm Password should match", "Password Entry", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Else
                Dim validUser As Boolean

                EmployeeTodo = New EmployeeTodo(txtUserName.Text, txtPassword.Text, txtFirstName.Text, txtLastName.Text, dtpDateOfBirth.Text, txtCity.Text, txtAddress.Text, txtState.Text, txtCountry.Text, txtZIPCode.Text, txtEmailID.Text, txtMobileNo.Text, cmbLoginType.Text)
                validUser = EmployeeTodo.ValidateUser(Trim(txtUserName.Text))
                If validUser Then
                    insertStatus = EmployeeTodo.insertUserLoginDetails()
                    If insertStatus > 0 Then
                        MessageBox.Show("New User account got created successfully", "New User : Success", MessageBoxButtons.OK, MessageBoxIcon.Information)
                    Else
                        MessageBox.Show("New User account creation got failed", "New User", MessageBoxButtons.OK, MessageBoxIcon.Error)
                    End If
                Else
                    MessageBox.Show("User with entered username already exists in database..Please try with new User Name", "New User", MessageBoxButtons.OK, MessageBoxIcon.Error)
                End If

            End If
        Catch ex As Exception
            MessageBox.Show("New user account cannot be created. Please try after sometime....", "Password Entry", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub btnSignIn_Click(sender As System.Object, e As System.EventArgs) Handles btnSignIn.Click
        Me.Hide()
        MainForm.Show()
    End Sub


    Private Sub CreateNewUserAccount_FormClosing(sender As System.Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Me.Hide()
        MainForm.Show()
    End Sub

    Private Sub btnClear_Click(sender As System.Object, e As System.EventArgs) Handles btnClear.Click
        For Each ctrl As Control In Me.Controls
            If ctrl.GetType Is GetType(TextBox) Then
                ctrl.Text = ""
            End If
        Next
        dtpDateOfBirth.Text = ""
        txtUserName.Focus()
    End Sub

    Private Sub txtZIPCode_KeyPress(sender As System.Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtZIPCode.KeyPress
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Then
            e.Handled = False
        Else
            e.Handled = True
            MessageBox.Show("Please enter numbers and ZIPCode cannot be more than 5 characters", "Zip Code", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

    Private Sub txtMobileNo_KeyPress(sender As System.Object, e As System.Windows.Forms.KeyPressEventArgs) Handles txtMobileNo.KeyPress
        If (Asc(e.KeyChar) >= 48 And Asc(e.KeyChar) <= 57) Or Asc(e.KeyChar) = 8 Then
            e.Handled = False
        Else
            e.Handled = True
            MessageBox.Show("Please enter numbers and Mobile Number cannot be more than 10 characters", "MobileNumber", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If
    End Sub

End Class