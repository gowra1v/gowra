﻿Imports System.Data.OleDb
Imports Excel = Microsoft.Office.Interop.Excel

Public Class MenuItemsRecord
    Dim drMenuItems As OleDbDataReader = Nothing
    Dim dtMenuItems As DataTable
    Dim con As OleDbConnection = Nothing
    Dim da As OleDbDataAdapter
    Dim ds As DataSet
    Dim cmd As OleDbCommand = Nothing
    Dim dt As New DataTable

    Dim MenuName As String
    Private Sub btnGetAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGetAll.Click
        con = New OleDbConnection(SqlHelper.strConnect)
        Try

            con.Open()
            cmd = New OleDbCommand("SELECT (MenuItems.MenuID) as [Menu ID],(MenuItems.ItemName) as [Inventory Name],(ItemCategories.CategoryName) as [Category Name],(MenuItems.ItemPrice) as [Item Price] from MenuItems INNER JOIN ItemCategories ON ItemCategories.CategoryID = MenuItems.CategoryID order by MenuItems.ItemName", con)


            Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()

            myDA.Fill(myDataSet, "MenuItems")
            dgvMenuItemsData.DataSource = myDataSet.Tables("MenuItems").DefaultView

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub btnExportAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnExportAll.Click
        If dgvMenuItemsData.RowCount = Nothing Then
            MessageBox.Show("Sorry nothing to export into excel sheet.." & vbCrLf & "Please retrieve data in datagridview", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        Dim rowsTotal, colsTotal As Short
        Dim I, j, iC As Short
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Dim xlApp As New Excel.Application

        Try
            Dim excelBook As Excel.Workbook = xlApp.Workbooks.Add
            Dim excelWorksheet As Excel.Worksheet = CType(excelBook.Worksheets(1), Excel.Worksheet)
            xlApp.Visible = True

            rowsTotal = dgvMenuItemsData.RowCount - 1
            colsTotal = dgvMenuItemsData.Columns.Count - 1
            With excelWorksheet
                .Cells.Select()
                .Cells.Delete()
                For iC = 0 To colsTotal
                    .Cells(1, iC + 1).Value = dgvMenuItemsData.Columns(iC).HeaderText
                Next
                For I = 0 To rowsTotal - 1
                    For j = 0 To colsTotal
                        .Cells(I + 2, j + 1).value = dgvMenuItemsData.Rows(I).Cells(j).Value
                    Next j
                Next I
                .Rows("1:1").Font.FontStyle = "Bold"
                .Rows("1:1").Font.Size = 12

                .Cells.Columns.AutoFit()
                .Cells.Select()
                .Cells.EntireColumn.AutoFit()
                .Cells(1, 1).Select()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            'RELEASE ALLOACTED RESOURCES
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            xlApp = Nothing
        End Try
    End Sub

    Private Sub btnInventoryExport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInventoryExport.Click
        If dgvMenuItemDetails.RowCount = Nothing Then
            MessageBox.Show("Sorry nothing to export into excel sheet.." & vbCrLf & "Please retrieve data in datagridview", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        Dim rowsTotal, colsTotal As Short
        Dim I, j, iC As Short
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Dim xlApp As New Excel.Application

        Try
            Dim excelBook As Excel.Workbook = xlApp.Workbooks.Add
            Dim excelWorksheet As Excel.Worksheet = CType(excelBook.Worksheets(1), Excel.Worksheet)
            xlApp.Visible = True

            rowsTotal = dgvMenuItemDetails.RowCount - 1
            colsTotal = dgvMenuItemDetails.Columns.Count - 1
            With excelWorksheet
                .Cells.Select()
                .Cells.Delete()
                For iC = 0 To colsTotal
                    .Cells(1, iC + 1).Value = dgvMenuItemDetails.Columns(iC).HeaderText
                Next
                For I = 0 To rowsTotal - 1
                    For j = 0 To colsTotal
                        .Cells(I + 2, j + 1).value = dgvMenuItemDetails.Rows(I).Cells(j).Value
                    Next j
                Next I
                .Rows("1:1").Font.FontStyle = "Bold"
                .Rows("1:1").Font.Size = 12

                .Cells.Columns.AutoFit()
                .Cells.Select()
                .Cells.EntireColumn.AutoFit()
                .Cells(1, 1).Select()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            'RELEASE ALLOACTED RESOURCES
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            xlApp = Nothing
        End Try
    End Sub


    Private Sub btnResetExport_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnResetExport.Click
        If dgvCategoryDetails.RowCount = Nothing Then
            MessageBox.Show("Sorry nothing to export into excel sheet.." & vbCrLf & "Please retrieve data in datagridview", "", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        Dim rowsTotal, colsTotal As Short
        Dim I, j, iC As Short
        System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.WaitCursor
        Dim xlApp As New Excel.Application

        Try
            Dim excelBook As Excel.Workbook = xlApp.Workbooks.Add
            Dim excelWorksheet As Excel.Worksheet = CType(excelBook.Worksheets(1), Excel.Worksheet)
            xlApp.Visible = True

            rowsTotal = dgvCategoryDetails.RowCount - 1
            colsTotal = dgvCategoryDetails.Columns.Count - 1
            With excelWorksheet
                .Cells.Select()
                .Cells.Delete()
                For iC = 0 To colsTotal
                    .Cells(1, iC + 1).Value = dgvCategoryDetails.Columns(iC).HeaderText
                Next
                For I = 0 To rowsTotal - 1
                    For j = 0 To colsTotal
                        .Cells(I + 2, j + 1).value = dgvCategoryDetails.Rows(I).Cells(j).Value
                    Next j
                Next I
                .Rows("1:1").Font.FontStyle = "Bold"
                .Rows("1:1").Font.Size = 12

                .Cells.Columns.AutoFit()
                .Cells.Select()
                .Cells.EntireColumn.AutoFit()
                .Cells(1, 1).Select()
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            'RELEASE ALLOACTED RESOURCES
            System.Windows.Forms.Cursor.Current = System.Windows.Forms.Cursors.Default
            xlApp = Nothing
        End Try
    End Sub

    Private Sub btnResetCategory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnResetCategory.Click
        dgvCategoryDetails.DataBindings.Clear()
        dgvCategoryDetails.DataSource = Nothing
        'cmbCategory.Text = ""
    End Sub


    Private Sub btnResetInventory_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnResetInventory.Click
        'cmbInventoryName.Text = ""
        txtMenuItemName.Text = ""
        dgvMenuItemDetails.DataBindings.Clear()
        dgvMenuItemDetails.DataSource = Nothing
    End Sub

    Private Sub btnResetAll_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnResetAll.Click
        dgvMenuItemsData.DataBindings.Clear()
        dgvMenuItemsData.DataSource = Nothing
    End Sub

    Private Sub InventoryTabControl_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles MenuItemTabControl.Click

        dgvCategoryDetails.DataBindings.Clear()
        dgvCategoryDetails.DataSource = Nothing
        'cmbCategory.Text = ""

        'cmbInventoryName.Text = ""
        txtMenuItemName.Text = ""
        dgvMenuItemDetails.DataBindings.Clear()
        dgvMenuItemsData.DataBindings.Clear()
        dgvMenuItemDetails.DataSource = Nothing
        dgvMenuItemsData.DataSource = Nothing
    End Sub
    Sub fillInventoryDetails()
        Dim conn As New OleDbConnection(SqlHelper.strConnect)
        Try
            conn.Open()
            da = New OleDbDataAdapter()
            da.SelectCommand = New OleDbCommand("SELECT MenuID, ItemName FROM MenuItems", conn)
            ds = New DataSet("ds")

            da.Fill(ds)
            dtMenuItems = ds.Tables(0)
            cmbInventoryName.DataBindings.Clear()
            ' cmbInventoryName.Items.Clear()
            cmbInventoryName.DataSource = Nothing
            With cmbInventoryName
                .DataSource = dtMenuItems
                .DisplayMember = "ItemName"
                .ValueMember = "MenuID"
                '.SelectedIndex = -1
            End With
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            conn.Close()
        End Try

    End Sub

    Sub selMenuItem(frmMenuItem As String)
        MenuName = frmMenuItem

        dgvCategoryDetails.DataBindings.Clear()
        dgvCategoryDetails.DataSource = Nothing
        txtMenuItemName.Text = ""
        dgvMenuItemDetails.DataBindings.Clear()
        dgvMenuItemDetails.DataSource = Nothing
        dgvMenuItemsData.DataBindings.Clear()
        dgvMenuItemsData.DataSource = Nothing


        fillCategoryDetails()
        fillInventoryDetails()
    End Sub

    Sub fillCategoryDetails()
        Dim conn As New OleDbConnection(SqlHelper.strConnect)
        Try
            dtMenuItems = New DataTable()
            conn.Open()
            da = New OleDbDataAdapter()
            da.SelectCommand = New OleDbCommand("SELECT CategoryID,CategoryName FROM ItemCategories", conn)
            ds = New DataSet("ds")

            da.Fill(ds)
            dtMenuItems = ds.Tables(0)
            cmbCategory.DataBindings.Clear()
            cmbCategory.DataSource = Nothing

            With cmbCategory
                .DataSource = dtMenuItems
                .DisplayMember = "CategoryName"
                .ValueMember = "CategoryID"
            End With

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            conn.Close()
        End Try
    End Sub

    Private Sub MenuItemsRecord_FormClosing(sender As Object, e As System.Windows.Forms.FormClosingEventArgs) Handles Me.FormClosing
        Me.Hide()
        MenuItems.Show()
    End Sub


    Private Sub cmbInventoryName_SelectionChangeCommitted(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbInventoryName.SelectionChangeCommitted
        con = New OleDbConnection(SqlHelper.strConnect)
        Try
            con.Open()
            cmd = New OleDbCommand("SELECT (MenuItems.MenuID) as [Menu ID],(MenuItems.ItemName) as [Menu Item Name],(ItemCategories.CategoryName) as [Category Name],(MenuItems.ItemPrice) as [Item Price] from MenuItems INNER JOIN ItemCategories ON ItemCategories.CategoryID = MenuItems.CategoryID WHERE MenuItems.ItemName= '" & cmbInventoryName.Text & "' order by MenuItems.ItemName", con)

            Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()
            myDA.Fill(myDataSet, "MenuItems")
            dgvMenuItemDetails.DataSource = myDataSet.Tables("MenuItems").DefaultView
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub txtInventoryName_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtMenuItemName.TextChanged
        con = New OleDbConnection(SqlHelper.strConnect)
        Try
            con.Open()
            cmd = New OleDbCommand("SELECT (MenuItems.MenuID) as [Menu ID],(MenuItems.ItemName) as [Menu Item Name],(ItemCategories.CategoryName) as [Category Name],(MenuItems.ItemPrice) as [Item Price] from MenuItems INNER JOIN ItemCategories ON ItemCategories.CategoryID = MenuItems.CategoryID WHERE MenuItems.ItemName like '%" & txtMenuItemName.Text & "%' order by MenuItems.ItemName", con)

            Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()

            myDA.Fill(myDataSet, "MenuItems")
            dgvMenuItemDetails.DataSource = myDataSet.Tables("MenuItems").DefaultView

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        Finally
            con.Close()
        End Try
    End Sub

    Private Sub cmbCategory_SelectionChangeCommitted(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles cmbCategory.SelectionChangeCommitted
        Try

            con = New OleDbConnection(SqlHelper.strConnect)
            con.Open()

            cmd = New OleDbCommand("SELECT (MenuItems.MenuID) as [Menu ID],(MenuItems.ItemName) as [Menu Item Name],(ItemCategories.CategoryName) as [Category Name],(MenuItems.ItemPrice) as [Item Price] from MenuItems INNER JOIN ItemCategories ON ItemCategories.CategoryID = MenuItems.CategoryID WHERE MenuItems.CategoryID = " & Convert.ToInt32(cmbCategory.SelectedValue) & " order by MenuItems.ItemName", con)

            Dim myDA As OleDbDataAdapter = New OleDbDataAdapter(cmd)
            Dim myDataSet As DataSet = New DataSet()

            myDA.Fill(myDataSet, "MenuItems")
            dgvCategoryDetails.DataSource = myDataSet.Tables("MenuItems").DefaultView

            con.Close()
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgvMenuItemsData_RowHeaderMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgvMenuItemsData.RowHeaderMouseClick
        Try
            Dim dr As DataGridViewRow = dgvMenuItemsData.SelectedRows(0)
            Me.Hide()
            MenuItems.Show()
            If MenuName = "selMenuItemID" Then

                MenuItems.txtMenuName.Text = dr.Cells(1).Value.ToString()
                MenuItems.setMenuID(Convert.ToInt32(dr.Cells(0).Value.ToString()))
            Else
                MenuItems.txtMenuItemID.Text = dr.Cells(0).Value.ToString()
                MenuItems.txtMenuItemName.Text = dr.Cells(1).Value.ToString()
                MenuItems.cmbCategoryName.Text = dr.Cells(2).Value.ToString()
                MenuItems.txtUnitPrice.Text = dr.Cells(3).Value.ToString()
                MenuItems.btnMenuUpdate.Enabled = True
                MenuItems.btnMenuDelete.Enabled = True
                MenuItems.btnSaveMenuItem.Enabled = False
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub dgvMenuItemDetails_RowHeaderMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgvMenuItemDetails.RowHeaderMouseClick
        Try
            Dim dr As DataGridViewRow = dgvMenuItemDetails.SelectedRows(0)
            Me.Hide()
            MenuItems.Show()
            If MenuName = "selMenuItemID" Then

                MenuItems.txtMenuName.Text = dr.Cells(1).Value.ToString()
                MenuItems.setMenuID(Convert.ToInt32(dr.Cells(0).Value.ToString()))
            Else

                MenuItems.txtMenuItemID.Text = dr.Cells(0).Value.ToString()
                MenuItems.txtMenuItemName.Text = dr.Cells(1).Value.ToString()
                MenuItems.cmbCategoryName.Text = dr.Cells(2).Value.ToString()
                MenuItems.txtUnitPrice.Text = dr.Cells(3).Value.ToString()
                MenuItems.btnMenuUpdate.Enabled = True
                MenuItems.btnMenuDelete.Enabled = True
                MenuItems.btnSaveMenuItem.Enabled = False
                'frmProduct.cmbWeight.Enabled = False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub



    Private Sub dgvCategoryDetails_RowHeaderMouseClick(ByVal sender As Object, ByVal e As System.Windows.Forms.DataGridViewCellMouseEventArgs) Handles dgvCategoryDetails.RowHeaderMouseClick
        Try
            Dim dr As DataGridViewRow = dgvCategoryDetails.SelectedRows(0)
            Me.Hide()
            MenuItems.Show()
            If MenuName = "selMenuItemID" Then
                MenuItems.txtMenuName.Text = dr.Cells(1).Value.ToString()
                MenuItems.setMenuID(Convert.ToInt32(dr.Cells(0).Value.ToString()))
            Else
                MenuItems.txtMenuItemID.Text = dr.Cells(0).Value.ToString()
                MenuItems.txtMenuItemName.Text = dr.Cells(1).Value.ToString()
                MenuItems.cmbCategoryName.Text = dr.Cells(2).Value.ToString()
                MenuItems.txtUnitPrice.Text = dr.Cells(3).Value.ToString()
                MenuItems.btnMenuUpdate.Enabled = True
                MenuItems.btnMenuDelete.Enabled = True
                MenuItems.btnSaveMenuItem.Enabled = False
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

End Class