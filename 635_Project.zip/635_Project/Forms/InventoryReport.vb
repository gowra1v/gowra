﻿Imports System.Text
Imports System.Globalization
Public Class InventoryReport
    Dim reportTodo As ReportTodoList
    Dim InventoryTo As InventoryTodo
    Dim Sql As SqlHelper

    Private Sub cmbInventoryItems_SelectionChangeCommitted(sender As Object, e As System.EventArgs) Handles cmbInventoryItems.SelectionChangeCommitted
        Try
            Dim docXML As String = ""
            Dim reportData As String = ""
            Dim PromotionStatus As String = ""
            Dim PromotionCode As String = ""
            PromotionCode = IIf(cmbInventoryItems.SelectedValue = 0, 0, cmbInventoryItems.SelectedValue)
            Dim dtPromotionReport As New DataTable
            reportTodo = New ReportTodoList()
            dtPromotionReport = reportTodo.SelectInventoryDetailsForReport(PromotionCode)
            If dtPromotionReport.Rows.Count > 0 Then
                reportData = buildXMLContent(dtPromotionReport)
            End If
            docXML = "<?xml version=""1.0"" encoding=""utf-8""?>"
            docXML += "<html>"
            docXML += "<head>"
            docXML += "<style type=""text/css"">"
            docXML += "body { margin: 80px; font-family: arial;font-size: 16pt;}"
            docXML += " th { font-style: italic; } th, td { border: 1px solid black; padding: 10 px; text-align: center;}"
            docXML += "tr.odd { background: rgb(244,244,244); } tr.even { background: rgb(232,232,232); }"
            docXML += "table {border-collapse:collapse;}"
            docXML += "</style>"
            docXML += "</head>"
            docXML += "<body> <h1>Inventory Items Report</h1> <h2></h2>"
            'docXML += "<table><tr class=""even""><th>Inventory ID</th><th>Inventory Name</th><th>Available Quantity</th><th>ReOrder Point</th><th>ReOrderNeeded</th><th>Unit Price</th></tr>"
            docXML += "<table><tr class=""even""><th>Inventory ID</th><th>Inventory Name</th><th>Available Quantity</th><th>ReOrder Point</th><th>ReOrderNeeded</th></tr>"
            docXML += "</table>"
            docXML += "</body>"
            docXML += "</html>"
            If reportData.Trim.Length = 0 Then
                WebBrowser1.DocumentText = docXML.ToString()
            Else
                WebBrowser1.DocumentText = reportData.ToString()
            End If
        Catch ex As Exception
            MessageBox.Show("Error in loading data for report... please try after sometime", "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub InventoryReport_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load
        Sql = New SqlHelper()
        InventoryTo = New InventoryTodo()
        Dim dtItemInfo As DataTable
        Dim docXML As String = ""
        Dim reportData As String = ""

        Dim dtPromotionReport As New DataTable

        Try
            ' Set up and fill the DataSet.
            dtItemInfo = InventoryTo.LoadInventoryItemsDetails()
            ' Set up the binding source.
            With cmbInventoryItems
                .DataSource = dtItemInfo
                .DisplayMember = "InventoryName"
                .ValueMember = "InventoryID"
            End With

            reportTodo = New ReportTodoList()
            dtPromotionReport = reportTodo.SelectInventoryDetailsReport()
            If dtPromotionReport.Rows.Count > 0 Then
                reportData = buildXMLContent(dtPromotionReport)
            End If
            docXML = "<?xml version=""1.0"" encoding=""utf-8""?>"
            docXML += "<html>"
            docXML += "<head>"
            docXML += "<style type=""text/css"">"
            docXML += "body { margin: 80px; font-family: arial;font-size: 16pt;}"
            docXML += " th { font-style: italic; } th, td { border: 1px solid black; padding: 10 px; text-align: center;}"
            docXML += "tr.odd { background: rgb(244,244,244); } tr.even { background: rgb(232,232,232); }"
            docXML += "table {border-collapse:collapse;}"
            docXML += "</style>"
            docXML += "</head>"
            docXML += "<body> <h1>Inventory Items Report</h1> <h2></h2>"
            'docXML += "<table><tr class=""even""><th>Inventory ID</th><th>Inventory Name</th><th>Available Quantity</th><th>ReOrder Point</th><th>ReOrderNeeded</th><th>Unit Price</th></tr>"
            docXML += "<table><tr class=""even""><th>Inventory ID</th><th>Inventory Name</th><th>Available Quantity</th><th>ReOrder Point</th><th>ReOrderNeeded</th></tr>"
            docXML += "</table>"
            docXML += "</body>"
            docXML += "</html>"
            If reportData.Trim.Length = 0 Then
                WebBrowser1.DocumentText = docXML.ToString()
            Else
                WebBrowser1.DocumentText = reportData.ToString()
            End If
        Catch ex As Exception
            MessageBox.Show("Data Error: " & ex.Message)
        End Try
    End Sub

    Private Function buildXMLContent(ByVal dtTable As DataTable) As String
        Dim docXML As String = ""
        Dim reportData As String = ""
        Dim tagClass As String = "odd"

        Dim rowCount As Integer = 0
        Dim TimesOut As Integer = 0
        Dim battingAverage As Decimal = 0D
        Dim bowlingAverage As Decimal = 0D
        docXML = "<?xml version=""1.0"" encoding=""utf-8""?>"
        docXML += "<html>"
        docXML += "<head>"
        docXML += "<style type=""text/css"">"
        docXML += "body { margin: 40px; font-family: arial;font-size: 16pt;}"
        docXML += " th { font-style: italic; } th, td { border: 1px solid black; padding: 10 px; text-align: center;}"
        docXML += "tr.odd { background: rgb(244,244,244); } tr.even { background: rgb(232,232,232); }"
        docXML += "table {border-collapse:collapse;}"
        docXML += "</style>"
        docXML += "</head>"
        docXML += "<body> <h1>Inventory Items Report</h1> <h2></h2>"
        docXML += "<table><tr class=""even""><th>Inventory ID</th><th>Inventory Name</th><th>Available Quantity</th><th>ReOrder Point</th><th>ReOrderNeeded</th></tr>"
        For Each dr As DataRow In dtTable.Rows
            If rowCount = 0 Then
                tagClass = "odd"
            ElseIf (rowCount Mod 2) = 0 Then
                tagClass = "even"
            End If
            Dim Needed As String = "No"
            If Convert.ToInt32(dr.Item("AvailableQty").ToString()) <= Convert.ToInt32(dr.Item("ReorderPoint").ToString()) Then
                Needed = "Yes"
            Else
                Needed = "No"
            End If

            reportData += "<tr class=" & tagClass & ">"
            reportData += "<td>" & dr.Item("InventoryID").ToString() & "</td>"
            reportData += "<td>" & dr.Item("InventoryName").ToString() & "</td>"
            reportData += "<td>" & dr.Item("AvailableQty").ToString() & "</td>"
            reportData += "<td>" & dr.Item("ReorderPoint").ToString() & "</td>"
            reportData += "<td>" & Needed & "</td>"
            reportData += "</tr>"
            rowCount += 1
        Next
        reportData += "</table>"
        reportData += "</body>"
        reportData += "</html>"
        Return (docXML.ToString() & " " & reportData.ToString())
    End Function


    Private Sub InventoryReport_FormClosing(ByVal sender As System.Object, ByVal e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If MessageBox.Show("Click on ok to navigate to main page?", "Are you sure to Exit?", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = Windows.Forms.DialogResult.OK Then

            MainForm.Show()
        Else
            e.Cancel = True
        End If
    End Sub

    Private Sub btnClose_Click(sender As System.Object, e As System.EventArgs) Handles btnClose.Click
        If MessageBox.Show("Click on ok to navigate to main page?", "Are you sure to Exit?", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = Windows.Forms.DialogResult.OK Then
            Me.Hide()
            MainForm.Show()
        End If
    End Sub

    Private Sub btnReset_Click(sender As System.Object, e As System.EventArgs) Handles btnReset.Click

        Sql = New SqlHelper()
        InventoryTo = New InventoryTodo()
        Dim dtItemInfo As DataTable
        Dim docXML As String = ""
        Dim reportData As String = ""

        Dim dtPromotionReport As New DataTable

        Try

            dtItemInfo = InventoryTo.LoadInventoryItemsDetails()

            With cmbInventoryItems
                .DataSource = dtItemInfo
                .DisplayMember = "InventoryName"
                .ValueMember = "InventoryID"
            End With

            reportTodo = New ReportTodoList()
            dtPromotionReport = reportTodo.SelectInventoryDetailsReport()
            If dtPromotionReport.Rows.Count > 0 Then
                reportData = buildXMLContent(dtPromotionReport)
            End If
            docXML = "<?xml version=""1.0"" encoding=""utf-8""?>"
            docXML += "<html>"
            docXML += "<head>"
            docXML += "<style type=""text/css"">"
            docXML += "body { margin: 80px; font-family: arial;font-size: 16pt;}"
            docXML += " th { font-style: italic; } th, td { border: 1px solid black; padding: 10 px; text-align: center;}"
            docXML += "tr.odd { background: rgb(244,244,244); } tr.even { background: rgb(232,232,232); }"
            docXML += "table {border-collapse:collapse;}"
            docXML += "</style>"
            docXML += "</head>"
            docXML += "<body> <h1>Inventory Items Report</h1> <h2></h2>"
            'docXML += "<table><tr class=""even""><th>Inventory ID</th><th>Inventory Name</th><th>Available Quantity</th><th>ReOrder Point</th><th>ReOrderNeeded</th><th>Unit Price</th></tr>"
            docXML += "<table><tr class=""even""><th>Inventory ID</th><th>Inventory Name</th><th>Available Quantity</th><th>ReOrder Point</th><th>ReOrderNeeded</th></tr>"
            docXML += "</table>"
            docXML += "</body>"
            docXML += "</html>"
            If reportData.Trim.Length = 0 Then
                WebBrowser1.DocumentText = docXML.ToString()
            Else
                WebBrowser1.DocumentText = reportData.ToString()
            End If
        Catch ex As Exception
            MessageBox.Show("Data Error: " & ex.Message)
        End Try

    End Sub
End Class


