<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class SendPromotions
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing AndAlso components IsNot Nothing Then
            components.Dispose()
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.txtToEmailID = New System.Windows.Forms.TextBox()
        Me.txtEmailSubject = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.txtEmailMessage = New System.Windows.Forms.TextBox()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.rbSMS = New System.Windows.Forms.RadioButton()
        Me.rbMail = New System.Windows.Forms.RadioButton()
        Me.btnClose = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Location = New System.Drawing.Point(464, 284)
        Me.Button1.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(149, 40)
        Me.Button1.TabIndex = 8
        Me.Button1.Text = "&Send"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'txtToEmailID
        '
        Me.txtToEmailID.Enabled = False
        Me.txtToEmailID.Location = New System.Drawing.Point(142, 64)
        Me.txtToEmailID.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtToEmailID.Name = "txtToEmailID"
        Me.txtToEmailID.Size = New System.Drawing.Size(233, 24)
        Me.txtToEmailID.TabIndex = 10
        '
        'txtEmailSubject
        '
        Me.txtEmailSubject.Location = New System.Drawing.Point(142, 110)
        Me.txtEmailSubject.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtEmailSubject.Name = "txtEmailSubject"
        Me.txtEmailSubject.Size = New System.Drawing.Size(233, 24)
        Me.txtEmailSubject.TabIndex = 11
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(68, 67)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(24, 17)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "To"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(68, 165)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(55, 17)
        Me.Label4.TabIndex = 14
        Me.Label4.Text = "Message"
        '
        'txtEmailMessage
        '
        Me.txtEmailMessage.Location = New System.Drawing.Point(142, 162)
        Me.txtEmailMessage.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.txtEmailMessage.Multiline = True
        Me.txtEmailMessage.Name = "txtEmailMessage"
        Me.txtEmailMessage.Size = New System.Drawing.Size(233, 162)
        Me.txtEmailMessage.TabIndex = 16
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(68, 110)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(47, 17)
        Me.Label6.TabIndex = 17
        Me.Label6.Text = "Subject"
        '
        'rbSMS
        '
        Me.rbSMS.AutoSize = True
        Me.rbSMS.Location = New System.Drawing.Point(479, 65)
        Me.rbSMS.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbSMS.Name = "rbSMS"
        Me.rbSMS.Size = New System.Drawing.Size(52, 21)
        Me.rbSMS.TabIndex = 18
        Me.rbSMS.TabStop = True
        Me.rbSMS.Text = "SMS"
        Me.rbSMS.UseVisualStyleBackColor = True
        '
        'rbMail
        '
        Me.rbMail.AutoSize = True
        Me.rbMail.Location = New System.Drawing.Point(554, 64)
        Me.rbMail.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.rbMail.Name = "rbMail"
        Me.rbMail.Size = New System.Drawing.Size(50, 21)
        Me.rbMail.TabIndex = 19
        Me.rbMail.TabStop = True
        Me.rbMail.Text = "Mail"
        Me.rbMail.UseVisualStyleBackColor = True
        '
        'btnClose
        '
        Me.btnClose.Location = New System.Drawing.Point(479, 13)
        Me.btnClose.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.Size = New System.Drawing.Size(149, 31)
        Me.btnClose.TabIndex = 20
        Me.btnClose.Text = "&Home"
        Me.btnClose.UseVisualStyleBackColor = True
        '
        'SendPromotions
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(7.0!, 17.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.ButtonHighlight
        Me.ClientSize = New System.Drawing.Size(679, 386)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.rbMail)
        Me.Controls.Add(Me.rbSMS)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.txtEmailMessage)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.txtEmailSubject)
        Me.Controls.Add(Me.txtToEmailID)
        Me.Controls.Add(Me.Button1)
        Me.Font = New System.Drawing.Font("Palatino Linotype", 9.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Margin = New System.Windows.Forms.Padding(3, 4, 3, 4)
        Me.Name = "SendPromotions"
        Me.Text = "Send Promotion Emails or SMS"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents txtToEmailID As System.Windows.Forms.TextBox
    Friend WithEvents txtEmailSubject As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents txtEmailMessage As System.Windows.Forms.TextBox
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents rbSMS As System.Windows.Forms.RadioButton
    Friend WithEvents rbMail As System.Windows.Forms.RadioButton
    Friend WithEvents btnClose As System.Windows.Forms.Button

End Class
