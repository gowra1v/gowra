﻿Imports System.Data.OleDb
Imports System.Security.Cryptography
Imports System.Text
Public Class OrderDetails
    Dim Sql As SqlHelper
    Dim OrderIDInteger As Integer
    Dim OrderTo As OrderTodo
    Dim rdr As OleDbDataReader = Nothing
    Dim dtable As DataTable
    Dim con As OleDbConnection = Nothing
    Dim adp As OleDbDataAdapter
    Dim ds As DataSet
    Dim cmd As OleDbCommand = Nothing
    Dim dtOrderItems As New DataTable
    Dim dtOld As New DataTable
    Dim sSql As String
    Dim indexArray(100) As Integer
    Dim Tax_Rate As Decimal = 0.06D

    Dim AMenuItemsDataTable As DataTable
    Dim MenuItemsTo As MenuItemsTodo
    Dim OrdersTo As OrderTodo
    Dim EmployeeID As Integer
    Dim OrderID As Integer

    Dim MenuItemsDataRow As DataRow

    Public Sub FillOrderDetailsList()
        With OrderDetailsListView
            .Clear()
            .Columns.Add("Column11", 0)
            .Columns.Add("Item ID", 125)
            .Columns.Add("Item Name", 125, HorizontalAlignment.Center)
            .Columns.Add("Quantity", 125, HorizontalAlignment.Center)
            .Columns.Add("Unit Price", 125, HorizontalAlignment.Center)
            .Columns.Add("Total Amount", 125, HorizontalAlignment.Center)
        End With

    End Sub

    Public Function GetData(ByVal sSQL As String)

        Dim sqlCmd As OleDbCommand = New OleDbCommand(sSQL)
        Dim myData As OleDbDataReader

        con = New OleDbConnection(SqlHelper.strConnect)

        Try
            con.Open()
            sqlCmd.Connection = con
            myData = sqlCmd.ExecuteReader
            Return myData
        Catch ex As Exception
            Return ex
        End Try
    End Function

    Private Sub fillOrdersListView(ByRef ordersListView As ListView, ByRef drOrdersList As OleDbDataReader)
        Dim ordListItem As ListViewItem

        Dim firstValue As String
        Dim strValue As String

        Do While drOrdersList.Read
            ordListItem = New ListViewItem()
            firstValue = IIf(drOrdersList.IsDBNull(0), "", drOrdersList.GetValue(0))
            ordListItem.Text = firstValue
            ordListItem.SubItems.Add(drOrdersList.GetValue(0))
            For fieldCounter = 1 To drOrdersList.FieldCount() - 1
                If drOrdersList.IsDBNull(fieldCounter) Then
                    ordListItem.SubItems.Add("")
                Else
                    If fieldCounter = drOrdersList.FieldCount() Then
                        strValue = (Convert.ToInt32(drOrdersList.GetValue(fieldCounter - 1)) * Convert.ToDecimal(drOrdersList.GetValue(fieldCounter))).ToString()
                        ordListItem.SubItems.Add(drOrdersList.GetValue(fieldCounter))
                        ordListItem.SubItems.Add(strValue)

                    Else
                        ordListItem.SubItems.Add(drOrdersList.GetValue(fieldCounter))

                    End If
                End If
            Next fieldCounter

            ordersListView.Items.Add(ordListItem)
        Loop
    End Sub

   

    Private Sub PlaceOrderButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PlaceOrderButton.Click
        If OrderDetailsListView.Items.Count = 0 Then
            MessageBox.Show("Please select atleast one menu item and then place new order.... ", "Error in Order", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        Dim index As Integer
        Dim dtItemAssign As DataTable
        index = 0
        Dim ItemIDInteger, InventoryIDInteger, Quantity, InvQuantity, DiscountPer As Integer
        Dim UnitPrice, subTotalPrice, DiscountAmount, TotalPrice As Decimal
        ItemIDInteger = 0
        InventoryIDInteger = 0
        InvQuantity = 0
        Quantity = 0
        UnitPrice = 0D
        subTotalPrice = 0D
        DiscountAmount = 0D
        TotalPrice = 0D
        DiscountPer = 0
        Try
            Dim InsertMenuItem, InsertOrderStatus, UpdateInventoryStatus As Integer
            For Each lstRecord As ListViewItem In OrderDetailsListView.Items

                Quantity = (Convert.ToInt32(OrderDetailsListView.Items(index).SubItems(3).Text))
                UnitPrice = (Convert.ToDecimal(OrderDetailsListView.Items(index).SubItems(4).Text))
                subTotalPrice = subTotalPrice + Convert.ToDecimal(Quantity * UnitPrice)
            Next


            If txtPromoDiscount.Text <> "" Then
                DiscountAmount = (subTotalPrice * Convert.ToInt32(txtPromoDiscount.Text) / 100)
                DiscountPer = Convert.ToInt32(txtPromoDiscount.Text)

            End If
            If DiscountPer > 0 Then
                subTotalPrice = subTotalPrice - DiscountAmount
                TotalPrice = subTotalPrice + (subTotalPrice * Tax_Rate)
            Else
                TotalPrice = subTotalPrice + (subTotalPrice * Tax_Rate)
            End If
            InsertOrderStatus = InsertOrders(If(SqlHelper.EmployeeID = 0, 1, SqlHelper.EmployeeID), Date.Today.Date, subTotalPrice, DiscountPer, DiscountAmount, TotalPrice)

            OrderID = InsertOrderStatus
            For Each lstRecord As ListViewItem In OrderDetailsListView.Items
                ItemIDInteger = (Convert.ToInt32(OrderDetailsListView.Items(index).SubItems(1).Text))
                Quantity = (Convert.ToInt32(OrderDetailsListView.Items(index).SubItems(3).Text))
                UnitPrice = (Convert.ToDecimal(OrderDetailsListView.Items(index).SubItems(4).Text))

                dtItemAssign = GetQuantityRequired(ItemIDInteger)

                If dtItemAssign.Rows.Count > 0 Then
                    For Each MenuDataRow In dtItemAssign.Rows
                        InventoryIDInteger = Integer.Parse(MenuDataRow.Item("InventoryItemID").ToString())
                        InvQuantity = Integer.Parse(MenuDataRow.Item("Required_Qty").ToString())
                        UpdateInventoryStatus = UpdateInventoryItems(InventoryIDInteger, InvQuantity * Quantity)
                    Next
                End If

                index = index + 1
                InsertMenuItem = InsertOrderDetails(InsertOrderStatus, ItemIDInteger, Quantity, UnitPrice)
            Next

            If InsertOrderStatus > 0 Then
                MessageBox.Show("Your Order is successfull and Order ID is : " & InsertOrderStatus & "", "Order got Created", MessageBoxButtons.OK, MessageBoxIcon.Information)
                PlaceOrderButton.Enabled = False
                btnPayment.Enabled = True
                btnClear.Text = "&Create New Order"
                'btnPrint.Enabled = True
            End If
            AMenuItemsDataTable.Clear()

            txtQuantity.Clear()
            txtQuantity.Enabled = False
            btnAddMenuItems.Enabled = False
            btnAddMenuItems.Enabled = False
            txtUnitPrice.Clear()
            txtOrderID.Text = InsertOrderStatus
            txtTotalPayment.Text = txtTotal.Text
            cmbPaymentType.Enabled = True

        Catch ex As Exception

            MessageBox.Show("Error while placing order, please try after sometime .... ", "Error in Order", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub AddMenuItemsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnAddMenuItems.Click
        Dim index, Change As Integer

        index = 0
        Change = 0
        txtTaxPer.Text = 6
        Try
            If MenuItemsComboBox.SelectedIndex = -1 Then
                MessageBox.Show("Please select any Item", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
            If Len(Trim(txtQuantity.Text)) = 0 Then
                MessageBox.Show("Please enter Quantity Needed", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
            If Len(Trim(txtUnitPrice.Text)) = 0 Then
                MessageBox.Show("Please Select any Menu item from list", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            Dim listCount As Integer
            listCount = OrderDetailsListView.Items.Count()
            If listCount = 0 Then
                Dim indexListItem As Integer
                Dim orderitemList As New ListViewItem(indexListItem)
                orderitemList.SubItems.Add(MenuItemsComboBox.SelectedValue)
                orderitemList.SubItems.Add(MenuItemsComboBox.Text)
                orderitemList.SubItems.Add(txtQuantity.Text)
                orderitemList.SubItems.Add(txtUnitPrice.Text)
                orderitemList.SubItems.Add(Convert.ToDecimal(Convert.ToInt32(txtQuantity.Text) * Convert.ToDecimal(txtUnitPrice.Text)))

                OrderDetailsListView.Items.Add(orderitemList)
                OrderDetailsListView.Refresh()
                indexListItem = indexListItem + 1
                txtSubTotal.Text = subOrderTotal().ToString("N2")
                txtTaxAmt.Text = (Convert.ToDecimal(txtSubTotal.Text) * Tax_Rate).ToString("N2")
                txtTotal.Text = ordersTotal().ToString("N2")
                txtTotalPayment.Text = txtTotal.Text

                Exit Sub
            End If

            If listCount > 0 Then
                For Each lstRecord As ListViewItem In OrderDetailsListView.Items
                    If (lstRecord.SubItems.Item(1).Text = MenuItemsComboBox.SelectedValue.ToString()) And (lstRecord.SubItems.Item(4).Text = txtUnitPrice.Text.ToString()) Then
                        Dim Quantity As Integer
                        Quantity = (Convert.ToInt32(OrderDetailsListView.Items(index).SubItems(3).Text) + Convert.ToInt32(txtQuantity.Text))
                        OrderDetailsListView.Items(index).SubItems(3).Text = Quantity.ToString()
                        OrderDetailsListView.Items(index).SubItems(5).Text = (Quantity * Convert.ToDecimal(txtUnitPrice.Text)).ToString()
                        Change += 1
                        indexArray(Change) = index
                    End If
                    index += 1
                Next
                If Change = 0 Then

                    Dim i As Integer
                    Dim lst As New ListViewItem(i)
                    lst.SubItems.Add(MenuItemsComboBox.SelectedValue)
                    lst.SubItems.Add(MenuItemsComboBox.Text)
                    lst.SubItems.Add(txtQuantity.Text)
                    lst.SubItems.Add(txtUnitPrice.Text)
                    lst.SubItems.Add(Convert.ToDecimal(Convert.ToInt32(txtQuantity.Text) * Convert.ToDecimal(txtUnitPrice.Text)))

                    OrderDetailsListView.Items.Add(lst)
                    OrderDetailsListView.Refresh()

                End If

                txtSubTotal.Text = subOrderTotal().ToString("N2")
                txtTaxAmt.Text = (Convert.ToDecimal(txtSubTotal.Text) * Tax_Rate).ToString("N2")
                txtTotal.Text = ordersTotal().ToString("N2")
                txtTotalPayment.Text = txtTotal.Text

                Exit Sub
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Public Function subOrderTotal() As Decimal
        Dim index As Integer = 0
        Dim selPrice As Decimal = 0D

        Try
            If OrderDetailsListView.Items.Count > 0 Then
                For Each lstRecord As ListViewItem In OrderDetailsListView.Items
                    selPrice = selPrice + (Convert.ToDecimal(OrderDetailsListView.Items(index).SubItems(5).Text))
                Next
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Return selPrice

    End Function

    Public Function ordersTotal() As Decimal
        Dim index As Integer = 0
        Dim selPrice As Decimal = 0D
        Dim totalPrice As Decimal = 0D

        Try
            If OrderDetailsListView.Items.Count > 0 Then
                For Each lstRecord As ListViewItem In OrderDetailsListView.Items
                    selPrice = selPrice + (Convert.ToDecimal(OrderDetailsListView.Items(index).SubItems(5).Text))
                Next
            End If
            If selPrice > 0D Then
                If txtPromoDiscount.Text = "" Then
                    totalPrice = selPrice + (selPrice * Tax_Rate).ToString
                Else
                    selPrice = selPrice - (selPrice * Convert.ToInt32(txtPromoDiscount.Text) / 100)
                    totalPrice = selPrice + selPrice * Tax_Rate
                End If
            Else
                totalPrice = 0D
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Return totalPrice
    End Function

    Private Sub RemoveButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRemove.Click
        Try
            If OrderDetailsListView.Items.Count = 0 Then
                MsgBox("No items to remove", MsgBoxStyle.Critical, "Error")
                Exit Sub
            Else
                'Dim listViewCount, index, inCount As Integer
                Dim listViewCount As Integer
                If OrderDetailsListView.FocusedItem Is Nothing Then
                    MsgBox("Please select any item in list view to remove item from list", MsgBoxStyle.Critical, "Error")
                    Exit Sub
                End If
                OrderDetailsListView.FocusedItem.Remove()
                listViewCount = OrderDetailsListView.Items.Count

                If listViewCount = 0 Then
                    txtSubTotal.Text = ""
                    txtTaxAmt.Text = ""
                    txtTotal.Text = ""
                    txtPrmotionCode.Text = ""
                    txtPromoDiscount.Text = ""
                    txtTotalPayment.Text = ""
                Else

                    txtSubTotal.Text = subOrderTotal().ToString("N2")
                    txtTaxAmt.Text = (Convert.ToDecimal(txtSubTotal.Text) * Tax_Rate).ToString("N2")
                    txtTotal.Text = ordersTotal().ToString("N2")
                    txtTotalPayment.Text = txtTotal.Text
                End If
            End If
            If OrderDetailsListView.Items.Count = 0 Then
                txtSubTotal.Text = ""
                txtTaxAmt.Text = ""
                txtTotal.Text = ""
                txtPrmotionCode.Text = ""
                txtPromoDiscount.Text = ""
                txtTotalPayment.Text = ""
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub AddNewItemsCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        MenuItemsComboBox.Enabled = True
        txtQuantity.Enabled = True
        btnAddMenuItems.Enabled = True
    End Sub

    Private Sub MenuItemsComboBox_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles MenuItemsComboBox.SelectionChangeCommitted
        Dim Value As Integer
        MenuItemsTo = New MenuItemsTodo()
        Value = MenuItemsComboBox.SelectedValue
        txtUnitPrice.Text = MenuItemsTo.LoadPriceDetails(Value).ToString()
        If txtUnitPrice.Text = "" Then
            txtUnitPrice.Text = 1.99D
        End If
    End Sub

    Private Sub OrderDetails_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Clear()
        SqlHelper.strConnect = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" & Application.StartupPath & "\Popoye.accdb"
        Sql = New SqlHelper()
        MenuItemsTo = New MenuItemsTodo()
        Dim dtItemInfo As DataTable
        Dim dtPaymentInfo As DataTable
        Dim InOrderID As Integer = 0
        Try
            ' Set up and fill the DataSet.
            dtItemInfo = MenuItemsTo.LoadItemDetails()
            ' Set up the binding source.
            With MenuItemsComboBox
                .DataSource = dtItemInfo
                .DisplayMember = "ItemName"
                .ValueMember = "MenuID"
            End With
            CreateDataTable()
            FillOrderDetailsList()

            dtPaymentInfo = GetPaymentTypes()
            With cmbPaymentType
                .DataSource = dtPaymentInfo
                .DisplayMember = "PaymentType"
                .ValueMember = "PaymentTypeID"
            End With

            InOrderID = GetOrdersID()
            txtOrderID.Text = InOrderID
        Catch ex As Exception
            MessageBox.Show("Data Error: " & ex.Message)
        End Try
    End Sub
    Private Sub CreateDataTable()
        AMenuItemsDataTable = New DataTable
        AMenuItemsDataTable.Columns.Add(New DataColumn("ItemID", System.Type.GetType("System.Int32")))
        AMenuItemsDataTable.Columns(0).Unique = True
        AMenuItemsDataTable.Columns.Add(New DataColumn("ItemName", System.Type.GetType("System.String")))
        AMenuItemsDataTable.Columns.Add(New DataColumn("Quantity", System.Type.GetType("System.Int32")))
        AMenuItemsDataTable.Columns.Add(New DataColumn("UnitPrice", System.Type.GetType("System.Decimal")))
        AMenuItemsDataTable.Columns.Add(New DataColumn("TotalPrice", System.Type.GetType("System.Decimal")))
    End Sub
    Private Sub btnPayment_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnPayment.Click
        Dim insertPayment As Integer

        insertPayment = InsertPaymentDetails(Convert.ToInt32(txtOrderID.Text), If(cmbPaymentType.SelectedValue = 0, 1, cmbPaymentType.SelectedValue), Date.Today.Date, Convert.ToDecimal(txtTotalPayment.Text))

        If insertPayment > 0 Then
            MessageBox.Show("Your Payment details got updated successfully", "Payment Successfull", MessageBoxButtons.OK)
            PlaceOrderButton.Enabled = False
            'btnPrint.Enabled = True
        End If
        btnPayment.Enabled = False
    End Sub


    Private Sub btnSearchPromoCode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearchPromoCode.Click
        PromoDetails.Show()
    End Sub

    Private Sub btnApply_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnApply.Click
        If OrderDetailsListView.Items.Count = 0 Then
            MessageBox.Show("Please select atleast one menu item and then apply discount .... ", "Error in Order", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        Dim SubTotalPromo As Decimal
        If txtSubTotal.Text <> "" Then
            SubTotalPromo = (Convert.ToInt32(txtPromoDiscount.Text) * Convert.ToDecimal(txtSubTotal.Text) / 100)
        End If
        txtTotal.Text = ordersTotal().ToString("N2")
        txtTotalPayment.Text = txtTotal.Text
    End Sub

    Public Function InsertOrders(InCustomerID As Integer, InOrderDate As DateTime, InOrderAmount As Decimal, InDiscountPercent As Integer, InDiscountAmount As Decimal, InNetOrderAmount As Decimal) As Integer
        Dim InsertSuccess As Integer = 0
        Dim insertStr As String = ""
        insertStr = "INSERT INTO Orders (EmployeeID, OrderDate, OrderAmount, DiscountPercent, DiscountAmount, NetOrderAmount) VALUES (" & InCustomerID & ",'" & InOrderDate & "','" & InOrderAmount & "'," & InDiscountPercent & ",'" & InDiscountAmount & "','" & InNetOrderAmount & "')"
        InsertSuccess = Sql.ExecuteInsUpdDel(insertStr, True) REM True, it is Insert
        Return InsertSuccess
    End Function


    Public Function UpdateInventoryItems(InInventoryID As Integer, InQuantity As Integer) As Integer
        Dim UpdateSuccess As Integer = 0
        Dim updateStr As String = ""
        updateStr = "UPDATE InventoryItems SET AvailableQty =  (AvailableQty - " & InQuantity & " ) WHERE InventoryID = " & InInventoryID
        UpdateSuccess = Sql.ExecuteInsUpdDel(updateStr) REM True, it is Insert
        Return UpdateSuccess

    End Function


    Public Function InsertOrderDetails(InOrderID As Integer, InItemID As Integer, InQuantity As Integer, InUnitPrice As Decimal) As Integer
        Dim InsertSuccess As Integer = 0
        Dim insertStr As String = ""
        insertStr = "INSERT INTO OrderItems (OrderID, ItemID, Quantity, UnitPrice) values (" & InOrderID & "," & InItemID & "," & InQuantity & ",'" & InUnitPrice & "')"
        InsertSuccess = Sql.ExecuteInsUpdDel(insertStr, True) REM True, it is Insert
        Return InsertSuccess

    End Function
    Public Function GetQuantityRequired(InMenuItemID As Integer) As DataTable
        Dim selTable As DataTable = Nothing
        Dim selectStr As String = ""
        selectStr = "SELECT InventoryItemID, Required_Qty FROM ItemAssignments WHERE MenuItemID = " & InMenuItemID & ""
        selTable = Sql.ExecuteSelectTable(selectStr) REM True, it is Insert
        Return selTable
    End Function


    Public Function GetPaymentTypes() As DataTable
        Dim selTable As DataTable = Nothing
        Dim selectStr As String = ""
        selectStr = "SELECT PaymentTypeID, PaymentType FROM PaymentTypes"
        selTable = Sql.ExecuteSelectTable(selectStr) REM True, it is Insert
        Return selTable
    End Function


    Public Function GetOrdersID() As Integer
        Dim GetMaxID As Integer
        Dim selectStr As String
        Sql = New SqlHelper()
        selectStr = "select Max(OrderID) as MaxID from Orders"
        GetMaxID = Sql.GetMaxID(selectStr)
        Return GetMaxID
    End Function


    Public Function InsertPaymentDetails(InOrderID As Integer, InPaymentTypeID As Integer, InPaymentDate As Date, InPaymentAmount As Decimal) As Integer
        Dim InsertSuccess As Integer = 0
        Dim insertStr As String = ""
        insertStr = "INSERT INTO Payments ( OrderID, PaymentTypeID, PaymentDate, PaymentAmount) values (" & InOrderID & "," & InPaymentTypeID & "," & InPaymentDate & ",'" & InPaymentAmount & "')"
        InsertSuccess = Sql.ExecuteInsUpdDel(insertStr, True) REM True, it is Insert
        Return InsertSuccess

    End Function


    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim PrintPreview As New PrintPreviewDialog
        PrintPreview.Document = PrintOrderDocument
        PrintPreview.ShowDialog()
    End Sub
    Private Sub PrintDocument1_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintOrderDocument.PrintPage

        If OrderDetailsListView.View = View.Details Then
            PrintDetails(e)
        End If
    End Sub
    Private Sub PrintDetails(ByRef e As System.Drawing.Printing.PrintPageEventArgs)
        Static LastIndex As Integer = 0
        Static CurrentPage As Integer = 0
        Dim PrintTotal As Integer = 0
        Dim DpiGraphics As Graphics = Me.CreateGraphics
        Dim DpiX As Integer = DpiGraphics.DpiX
        Dim DpiY As Integer = DpiGraphics.DpiY
        DpiGraphics.Dispose()
        Dim X, Y As Integer
        Dim ImageWidth As Integer
        Dim TextRect As Rectangle = Rectangle.Empty
        Dim TextLeftPad As Single = CSng(4 * (DpiX / 96)) '4 pixel pad on the left.
        Dim ColumnHeaderHeight As Single = CSng(OrderDetailsListView.Font.Height + (10 * (DpiX / 96))) '5 pixel pad on the top an bottom
        Dim StringFormat As New StringFormat
        Dim PageNumberWidth As Single = e.Graphics.MeasureString(CStr(CurrentPage), OrderDetailsListView.Font).Width


        Dim PrintLineString As String
        Dim PrintFont As New Font("Arial", 14)
        Dim HorizontalPrintLocationSingle As Single = e.MarginBounds.Left
        Dim VerticalPrintLocationSingle As Single = e.MarginBounds.Top
        Dim HeadingFont As New Font("Arial", 16, FontStyle.Bold)
        Dim LineHeightSingle As Single = PrintFont.GetHeight + 5
        Dim FontSizeF As New SizeF()
        Dim ColumnEndSingle As Single = 700D

        PrintLineString = "Popoye's Chicken Outlet"

        VerticalPrintLocationSingle += LineHeightSingle
        VerticalPrintLocationSingle += LineHeightSingle
        VerticalPrintLocationSingle += LineHeightSingle

        e.Graphics.DrawString(PrintLineString, HeadingFont, Brushes.Black, 250, VerticalPrintLocationSingle)

        StringFormat.FormatFlags = StringFormatFlags.NoWrap
        StringFormat.Trimming = StringTrimming.EllipsisCharacter
        StringFormat.LineAlignment = StringAlignment.Center
        CurrentPage += 1
        VerticalPrintLocationSingle += LineHeightSingle
        VerticalPrintLocationSingle += LineHeightSingle

        X = CInt(HorizontalPrintLocationSingle)
        Y = CInt(VerticalPrintLocationSingle)
        'Draw the column headers
        For ColumnIndex As Integer = 0 To OrderDetailsListView.Columns.Count - 1
            TextRect.X = X
            TextRect.Y = Y
            TextRect.Width = OrderDetailsListView.Columns(ColumnIndex).Width
            TextRect.Height = ColumnHeaderHeight
            e.Graphics.FillRectangle(Brushes.LightGray, TextRect)
            e.Graphics.DrawRectangle(Pens.DarkGray, TextRect)
            TextRect.X += TextLeftPad
            TextRect.Width -= TextLeftPad
            e.Graphics.DrawString(OrderDetailsListView.Columns(ColumnIndex).Text, OrderDetailsListView.Font, Brushes.Black, TextRect, StringFormat)

            X += TextRect.Width + TextLeftPad
        Next

        Y += ColumnHeaderHeight

        For i = LastIndex To OrderDetailsListView.Items.Count - 1
            With OrderDetailsListView.Items(i)

                X = CInt(e.MarginBounds.X)

                If Y + .Bounds.Height > e.MarginBounds.Bottom Then

                    LastIndex = i - 1
                    e.HasMorePages = True
                    StringFormat.Dispose()

                    e.Graphics.DrawString(CStr(CurrentPage), OrderDetailsListView.Font, Brushes.Black, (e.PageBounds.Width - PageNumberWidth) / 2, e.PageBounds.Bottom - OrderDetailsListView.Font.Height * 2)
                    Exit Sub
                End If

                For ColumnIndex As Integer = 0 To OrderDetailsListView.Columns.Count - 1
                    TextRect.X = X
                    TextRect.Y = Y
                    TextRect.Width = OrderDetailsListView.Columns(ColumnIndex).Width
                    TextRect.Height = .Bounds.Height
                    If OrderDetailsListView.GridLines Then

                    End If

                    If ColumnIndex = 0 Then TextRect.X += ImageWidth

                    TextRect.X += TextLeftPad
                    TextRect.Width -= TextLeftPad
                    If ColumnIndex < .SubItems.Count Then

                        e.Graphics.DrawString(.SubItems(ColumnIndex).Text, OrderDetailsListView.Font, Brushes.Black, TextRect, StringFormat)
                    End If

                    X += TextRect.Width + TextLeftPad
                Next

                Y += .Bounds.Height
            End With
        Next

        Y += ColumnHeaderHeight
        HorizontalPrintLocationSingle = X
        VerticalPrintLocationSingle = Y
        VerticalPrintLocationSingle += LineHeightSingle
        VerticalPrintLocationSingle += LineHeightSingle
        VerticalPrintLocationSingle += LineHeightSingle

        LastIndex = 0
        PrintTotal = 3
        For i = 0 To PrintTotal

            For ColumnIndex As Integer = 0 To OrderDetailsListView.Columns.Count - 1
                TextRect.X = X
                TextRect.Y = Y
                TextRect.Width = OrderDetailsListView.Columns(ColumnIndex).Width
                TextRect.Height = OrderDetailsListView.Bounds.Height
                If OrderDetailsListView.GridLines Then

                End If

                If ColumnIndex = 0 Then TextRect.X += ImageWidth

                TextRect.X += TextLeftPad
                TextRect.Width -= TextLeftPad
                If ColumnIndex < 5 Then

                    If i = 0 Then
                        If ColumnIndex = 3 Then
                            e.Graphics.DrawString(" Sub Total", OrderDetailsListView.Font, Brushes.Black, TextRect, StringFormat)
                        ElseIf ColumnIndex = 4 Then
                            e.Graphics.DrawString(txtSubTotal.Text, OrderDetailsListView.Font, Brushes.Black, TextRect, StringFormat)
                        End If
                    ElseIf i = 1 Then
                        If ColumnIndex = 3 Then
                            e.Graphics.DrawString(" Tax Amount", OrderDetailsListView.Font, Brushes.Black, TextRect, StringFormat)
                        ElseIf ColumnIndex = 4 Then
                            e.Graphics.DrawString(txtTaxAmt.Text, OrderDetailsListView.Font, Brushes.Black, TextRect, StringFormat)
                        End If
                    ElseIf i = 2 Then
                        If ColumnIndex = 3 Then
                            e.Graphics.DrawString(" Total payment", OrderDetailsListView.Font, Brushes.Black, TextRect, StringFormat)
                        ElseIf ColumnIndex = 4 Then
                            e.Graphics.DrawString(txtTotalPayment.Text, OrderDetailsListView.Font, Brushes.Black, TextRect, StringFormat)
                        End If
                    End If
                End If

                X += TextRect.Width + TextLeftPad
            Next

        Next

        '
        e.Graphics.DrawString(CStr(CurrentPage), OrderDetailsListView.Font, Brushes.Black, (e.PageBounds.Width - PageNumberWidth) / 2, e.PageBounds.Bottom - OrderDetailsListView.Font.Height * 2)
        StringFormat.Dispose()
        LastIndex = 0
        CurrentPage = 0
    End Sub



    Private Sub OrderDetails_FormClosing(sender As System.Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        Me.Hide()
        Clear()
        MainForm.Show()
    End Sub


    Sub Clear()

        For Each txtControls In Me.Controls
            If TypeOf txtControls Is TextBox Then
                txtControls.Text = ""     'Clear all text
            End If
        Next txtControls

        OrderDetailsListView.Items.Clear()
        OrderDetailsListView.DataBindings.Clear()
    End Sub

    Private Sub btnHome_Click(sender As System.Object, e As System.EventArgs) Handles btnHome.Click
        Me.Hide()
        Clear()
        MainForm.Show()

    End Sub

    Private Sub btnClear_Click(sender As System.Object, e As System.EventArgs) Handles btnClear.Click
        If btnClear.Text = "&Create New Order" Then
            Clear()
            txtOrderID.Text = GetOrdersID()
            MenuItemsComboBox.Focus()
            btnClear.Text = "&Clear"
            PlaceOrderButton.Enabled = True
            btnPayment.Enabled = False
            txtQuantity.Enabled = True
            btnAddMenuItems.Enabled = True
            btnAddMenuItems.Enabled = True
        End If

        clear()

    End Sub

    Private Sub dtpOrderDate_ValueChanged(sender As System.Object, e As System.EventArgs) Handles dtpOrderDate.ValueChanged
        If dtpOrderDate.Value < Date.Now.Date Then
            MessageBox.Show("Order date should not be less than current date : " & Date.Now.Date & " to create or place order.... ", "Error in Order", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End If

    End Sub
End Class

