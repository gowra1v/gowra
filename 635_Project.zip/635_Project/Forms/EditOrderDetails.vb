﻿Imports System.Data.OleDb
Imports System.Security.Cryptography
Imports System.Text
Public Class EditOrderDetails

    Dim Sql As SqlHelper
    Dim OrderIDInteger As Integer
    Dim OrderTo As OrderTodo
    Dim rdr As OleDbDataReader = Nothing
    Dim dtable As DataTable
    Dim con As OleDbConnection = Nothing
    Dim adp As OleDbDataAdapter
    Dim ds As DataSet
    Dim cmd As OleDbCommand = Nothing
    Dim dtOrderItems As New DataTable
    Dim dtOld As New DataTable
    Dim sSql As String
    Dim indexArray(100) As Integer
    Dim Tax_Rate As Decimal = 0.06D
    Dim ExistOrderID As Integer
    Dim AMenuItemsDataTable As DataTable
    Dim MenuItemsTo As MenuItemsTodo
    Dim OrdersTo As OrderTodo
    Dim EmployeeID As Integer
    Dim OrderID As Integer
    Dim selectStr As String
    Dim MenuItemsDataRow As DataRow
    Dim frmEditOrder As String


   

    Private Sub btnSearch_Click(sender As System.Object, e As System.EventArgs) Handles btnSearch.Click
        Sql = New SqlHelper()

        Dim dtOrders As DataTable
        Dim dtOrderDetails As DataTable
        Try
            selectStr = "SELECT Orders.OrderID, Orders.OrderDate, Orders.OrderAmount, Orders.DiscountPercent, Orders.DiscountAmount, Orders.NetOrderAmount FROM Orders where Orders.OrderID = " & Convert.ToInt32(txtOrderID.Text) & " and IsDeleted = 0"
            dtOrders = Sql.ExecuteSelectTable(selectStr)
            If dtOrders.Rows.Count = 1 Then
                For Each Row As DataRow In dtOrders.Rows

                    dtpOrderDate.Text = Row.Item("OrderDate").ToString()
                    'CustTextbox.Text = Row.Item("Fullname")
                    txtSubTotal.Text = Convert.ToDecimal(Row.Item("OrderAmount")).ToString("N2")
                    txtPromoDiscount.Text = Row.Item("DiscountPercent").ToString()
                    txtTotal.Text = Convert.ToDecimal(Row.Item("NetOrderAmount")).ToString("N2")
                    txtTaxPer.Text = 6
                    txtTaxAmt.Text = (Convert.ToDecimal(Row.Item("OrderAmount")) * Tax_Rate).ToString("N2")
                    txtTotalPayment.Text = Convert.ToDecimal(Row.Item("NetOrderAmount")).ToString("N2")
                    ExistOrderID = Row.Item("OrderID")
                Next

                selectStr = "SELECT MenuItems.MenuID, MenuItems.ItemName, OrderItems.Quantity, OrderItems.UnitPrice, (OrderItems.Quantity * OrderItems.UnitPrice) AS TotalAmount FROM Orders INNER JOIN (MenuItems INNER JOIN OrderItems ON MenuItems.MenuID = OrderItems.ItemID) ON Orders.OrderID = OrderItems.OrderID WHERE Orders.OrderID = " & Convert.ToInt32(txtOrderID.Text)
                FillOrderDetailsList()
                btnCancelOrder.Enabled = True
            Else
                MessageBox.Show("Invalid OrderID , Please provide correct Input", "Invalid Input", MessageBoxButtons.OK, MessageBoxIcon.Error)
            End If

            dtpOrderDate.Enabled = True
            txtQuantity.Enabled = True
        Catch Ex As Exception
            MessageBox.Show("Error in loading data... please try after sometime", "Load Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Public Sub FillOrderDetailsList()
        With OrderDetailsListView
            .Clear()
            .Columns.Add("Column11", 0)
            .Columns.Add("Item ID", 125)
            .Columns.Add("Item Name", 125, HorizontalAlignment.Center)
            .Columns.Add("Quantity", 125, HorizontalAlignment.Center)
            .Columns.Add("Unit Price", 125, HorizontalAlignment.Center)
            .Columns.Add("Total Amount", 125, HorizontalAlignment.Center)
        End With
        fillOrdersListView(OrderDetailsListView, GetData(selectStr))
    End Sub

    Public Function GetData(ByVal sSQL As String)

        Dim sqlCmd As OleDbCommand = New OleDbCommand(sSQL)
        Dim myData As OleDbDataReader

        con = New OleDbConnection(SqlHelper.strConnect)

        Try
            con.Open()
            sqlCmd.Connection = con
            myData = sqlCmd.ExecuteReader
            Return myData
        Catch ex As Exception
            Return ex
        End Try
    End Function

    Private Sub fillOrdersListView(ByRef ordersListView As ListView, ByRef drOrdersList As OleDbDataReader)
        Dim ordListItem As ListViewItem

        Dim firstValue As String
        Dim strValue As String

        Do While drOrdersList.Read
            ordListItem = New ListViewItem()
            firstValue = IIf(drOrdersList.IsDBNull(0), "", drOrdersList.GetValue(0))
            ordListItem.Text = firstValue
            ordListItem.SubItems.Add(drOrdersList.GetValue(0))
            For fieldCounter = 1 To drOrdersList.FieldCount() - 1
                If drOrdersList.IsDBNull(fieldCounter) Then
                    ordListItem.SubItems.Add("")
                Else
                    If fieldCounter = drOrdersList.FieldCount() Then
                        strValue = (Convert.ToInt32(drOrdersList.GetValue(fieldCounter - 1)) * Convert.ToDecimal(drOrdersList.GetValue(fieldCounter))).ToString()
                        ordListItem.SubItems.Add(drOrdersList.GetValue(fieldCounter))
                        ordListItem.SubItems.Add(strValue)

                    Else
                        ordListItem.SubItems.Add(drOrdersList.GetValue(fieldCounter))

                    End If
                End If
            Next fieldCounter

            ordersListView.Items.Add(ordListItem)
        Loop
    End Sub



    Private Sub btnUpdateOrder_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpdateOrder.Click
        If OrderDetailsListView.Items.Count = 0 Then
            MessageBox.Show("Please select atleast one menu item and then place new order.... ", "Error in Order", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        Dim index As Integer
        Dim dtItemAssign As DataTable
        index = 0
        Dim ItemIDInteger, InventoryIDInteger, Quantity, InvQuantity, DiscountPer, UpdateInventoryStatus As Integer
        Dim UnitPrice, subTotalPrice, DiscountAmount, TotalPrice As Decimal
        ItemIDInteger = 0
        InventoryIDInteger = 0
        InvQuantity = 0
        Quantity = 0
        UnitPrice = 0D
        subTotalPrice = 0D
        DiscountAmount = 0D
        TotalPrice = 0D
        DiscountPer = 0
        UpdateInventoryStatus = 0
        Dim exist, updStatus, delStatus, insertInteger, change, delete As Integer
        exist = 0
        change = 0
        delete = 0
        Dim dtOrdersData As DataTable
        Try
            dtOrdersData = SelectOrderDetails(Convert.ToInt32(txtOrderID.Text))
            For Each lstRecord As ListViewItem In OrderDetailsListView.Items
                For Each dbExistRow As DataRow In dtOrdersData.Rows
                    If (lstRecord.SubItems(1).Text = dbExistRow.Item("ItemID").ToString() And ExistOrderID = Convert.ToInt32(dbExistRow.Item("OrderID").ToString())) Then
                        If lstRecord.SubItems(3).Text <> dbExistRow.Item("Quantity").ToString() Then

                            ItemIDInteger = (Convert.ToInt32(dbExistRow.Item("ItemID").ToString()))
                            Quantity = (Convert.ToInt32(dbExistRow.Item("Quantity").ToString()))
                            dtItemAssign = GetQuantityRequired(ItemIDInteger)

                            If dtItemAssign.Rows.Count > 0 Then
                                For Each MenuDataRow In dtItemAssign.Rows
                                    InventoryIDInteger = Integer.Parse(MenuDataRow.Item("InventoryItemID").ToString())
                                    InvQuantity = Integer.Parse(MenuDataRow.Item("Required_Qty").ToString())
                                    UpdateInventoryStatus = UpdateInventoryQuantity(InventoryIDInteger, InvQuantity * Quantity)
                                    UpdateInventoryStatus = UpdateInventoryItems(InventoryIDInteger, InvQuantity * (Convert.ToInt32(lstRecord.SubItems(3).Text)))
                                Next
                            End If

                            updStatus = UpdateOrderDetails(ExistOrderID, Convert.ToInt32(lstRecord.SubItems(1).Text), Convert.ToInt32(lstRecord.SubItems(3).Text), Convert.ToDecimal(lstRecord.SubItems(4).Text))
                        End If
                    End If
                Next
            Next

            For Each dbExistRow As DataRow In dtOrdersData.Rows
                For Each lstRecord As ListViewItem In OrderDetailsListView.Items

                    If (lstRecord.SubItems(1).Text <> dbExistRow.Item("ItemID").ToString()) Then
                        delete = delete + 1
                    Else
                        exist = exist + 1
                    End If
                Next
                If delete > 0 And exist = 0 Then

                    ItemIDInteger = (Convert.ToInt32(dbExistRow.Item("ItemID").ToString()))
                    Quantity = (Convert.ToInt32(dbExistRow.Item("Quantity").ToString()))
                    dtItemAssign = GetQuantityRequired(ItemIDInteger)

                    If dtItemAssign.Rows.Count > 0 Then
                        For Each MenuDataRow In dtItemAssign.Rows
                            InventoryIDInteger = Integer.Parse(MenuDataRow.Item("InventoryItemID").ToString())
                            InvQuantity = Integer.Parse(MenuDataRow.Item("Required_Qty").ToString())
                            UpdateInventoryStatus = UpdateInventoryQuantity(InventoryIDInteger, InvQuantity * Quantity)
                        Next
                    End If
                    delStatus = DeleteOrderDetails(ExistOrderID, Convert.ToInt32(dbExistRow.Item("ItemID").ToString()))
                End If
                delete = 0
                exist = 0
            Next

            exist = 0
            For Each lstRecord As ListViewItem In OrderDetailsListView.Items
                For Each dbExistRow As DataRow In dtOrdersData.Rows
                    If (lstRecord.SubItems(1).Text = dbExistRow.Item("ItemID").ToString()) Then
                        change = change + 1
                    Else
                        exist = exist + 1
                    End If
                Next
                If change = 0 And exist > 0 Then
                    ItemIDInteger = (Convert.ToInt32(OrderDetailsListView.Items(index).SubItems(1).Text))
                    insertInteger = InsertOrderDetails(Convert.ToInt32(txtOrderID.Text), Convert.ToInt32(lstRecord.SubItems(1).Text), Convert.ToInt32(lstRecord.SubItems(3).Text), Convert.ToDecimal(lstRecord.SubItems(4).Text))

                    dtItemAssign = GetQuantityRequired(ItemIDInteger)

                    If dtItemAssign.Rows.Count > 0 Then
                        For Each MenuDataRow In dtItemAssign.Rows
                            InventoryIDInteger = Integer.Parse(MenuDataRow.Item("InventoryItemID").ToString())
                            InvQuantity = Integer.Parse(MenuDataRow.Item("Required_Qty").ToString())
                            UpdateInventoryStatus = UpdateInventoryItems(InventoryIDInteger, InvQuantity * Quantity)
                        Next
                    End If

                End If
                change = 0
                exist = 0
            Next
            For Each lstRecord As ListViewItem In OrderDetailsListView.Items

                Quantity = (Convert.ToInt32(OrderDetailsListView.Items(index).SubItems(3).Text))
                UnitPrice = (Convert.ToDecimal(OrderDetailsListView.Items(index).SubItems(4).Text))
                subTotalPrice = subTotalPrice + Convert.ToDecimal(Quantity * UnitPrice)
            Next


            If txtPromoDiscount.Text <> "" Then
                DiscountAmount = (subTotalPrice * Convert.ToInt32(txtPromoDiscount.Text) / 100)
                DiscountPer = Convert.ToInt32(txtPromoDiscount.Text)

            End If
            If DiscountPer > 0 Then
                subTotalPrice = subTotalPrice - DiscountAmount
                TotalPrice = subTotalPrice + (subTotalPrice * Tax_Rate)
            Else
                TotalPrice = subTotalPrice + (subTotalPrice * Tax_Rate)
            End If


            updStatus = UpdateOrders(Convert.ToInt32(txtOrderID.Text), SqlHelper.EmployeeID, subTotalPrice, If(DiscountPer = 0, 0, DiscountPer), If(DiscountAmount = 0D, 0D, DiscountAmount), TotalPrice)
            MessageBox.Show("Order details got updated successfully")
            PaymentButton.Enabled = True


        Catch ex As Exception

            MessageBox.Show("Error while placing order, please try after sometime .... ", "Error in Order", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try

    End Sub

    Private Sub AddMenuItemsButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddMenuItemsButton.Click
        Dim index, Change As Integer

        index = 0
        Change = 0
        txtTaxPer.Text = 6
        Try
            If MenuItemsComboBox.SelectedIndex = -1 Then
                MessageBox.Show("Please select any Item", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
            If Len(Trim(txtQuantity.Text)) = 0 Then
                MessageBox.Show("Please enter Quantity Needed", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If
            If Len(Trim(txtUnitPrice.Text)) = 0 Then
                MessageBox.Show("Please Select any Menu item from list", "Input Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
                Exit Sub
            End If

            Dim listCount As Integer
            listCount = OrderDetailsListView.Items.Count()
            If listCount = 0 Then
                Dim indexListItem As Integer
                Dim orderitemList As New ListViewItem(indexListItem)
                orderitemList.SubItems.Add(MenuItemsComboBox.SelectedValue)
                orderitemList.SubItems.Add(MenuItemsComboBox.Text)
                orderitemList.SubItems.Add(txtQuantity.Text)
                orderitemList.SubItems.Add(txtUnitPrice.Text)
                orderitemList.SubItems.Add(Convert.ToDecimal(Convert.ToInt32(txtQuantity.Text) * Convert.ToDecimal(txtUnitPrice.Text)))

                OrderDetailsListView.Items.Add(orderitemList)
                OrderDetailsListView.Refresh()
                indexListItem = indexListItem + 1
                txtSubTotal.Text = subOrderTotal().ToString("N2")
                txtTaxAmt.Text = (Convert.ToDecimal(txtSubTotal.Text) * Tax_Rate).ToString("N2")
                txtTotal.Text = ordersTotal().ToString("N2")
                txtTotalPayment.Text = txtTotal.Text

                Exit Sub
            End If

            If listCount > 0 Then
                For Each lstRecord As ListViewItem In OrderDetailsListView.Items
                    If (lstRecord.SubItems.Item(1).Text = MenuItemsComboBox.SelectedValue.ToString()) And (lstRecord.SubItems.Item(4).Text = txtUnitPrice.Text.ToString()) Then
                        Dim Quantity As Integer
                        Quantity = (Convert.ToInt32(OrderDetailsListView.Items(index).SubItems(3).Text) + Convert.ToInt32(txtQuantity.Text))
                        OrderDetailsListView.Items(index).SubItems(3).Text = Quantity.ToString()
                        OrderDetailsListView.Items(index).SubItems(5).Text = (Quantity * Convert.ToDecimal(txtUnitPrice.Text)).ToString()
                        Change += 1
                        indexArray(Change) = index
                    End If
                    index += 1
                Next
                If Change = 0 Then

                    Dim i As Integer
                    Dim lst As New ListViewItem(i)
                    lst.SubItems.Add(MenuItemsComboBox.SelectedValue)
                    lst.SubItems.Add(MenuItemsComboBox.Text)
                    lst.SubItems.Add(txtQuantity.Text)
                    lst.SubItems.Add(txtUnitPrice.Text)
                    lst.SubItems.Add(Convert.ToDecimal(Convert.ToInt32(txtQuantity.Text) * Convert.ToDecimal(txtUnitPrice.Text)))

                    OrderDetailsListView.Items.Add(lst)
                    OrderDetailsListView.Refresh()

                End If

                txtSubTotal.Text = subOrderTotal().ToString("N2")
                txtTaxAmt.Text = (Convert.ToDecimal(txtSubTotal.Text) * Tax_Rate).ToString("N2")
                txtTotal.Text = ordersTotal().ToString("N2")
                txtTotalPayment.Text = txtTotal.Text

                Exit Sub
            End If

        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub
    Public Function subOrderTotal() As Decimal
        Dim index As Integer = 0
        Dim selPrice As Decimal = 0D

        Try
            If OrderDetailsListView.Items.Count > 0 Then
                For Each lstRecord As ListViewItem In OrderDetailsListView.Items
                    selPrice = selPrice + (Convert.ToDecimal(OrderDetailsListView.Items(index).SubItems(5).Text))
                Next
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Return selPrice

    End Function
    Private Sub btnCancelOrder_Click(sender As System.Object, e As System.EventArgs) Handles btnCancelOrder.Click
        Dim CancelStatus As Integer
        If txtOrderID.Text <> "" Then
            selectStr = "Update Orders set IsDeleted = 1 where OrderID = " & ExistOrderID
            CancelStatus = Sql.ExecuteInsUpdDel(selectStr)
            selectStr = "Update OrderItems set IsDeleted = 1 where OrderID = " & ExistOrderID
            CancelStatus = Sql.ExecuteInsUpdDel(selectStr)
            updateQuantity()
            If (CancelStatus > 0) Then
                MessageBox.Show("Order ID: " & txtOrderID.Text & " Cancelled successfully!")
            Else
                MessageBox.Show("OrderID : " & txtOrderID.Text & " is invalid or Cancelled already!")
            End If
        End If
        Clear()
        btnCancelOrder.Enabled = False
        PaymentButton.Enabled = False
        txtOrderID.Enabled = True
        btnSearch.Enabled = True
        txtOrderID.Focus()
    End Sub

    Private Sub updateQuantity()
        Dim dtUpdQuantity As DataTable
        Dim updItemID, updQuantity, InventoryIDInteger, InvQuantity, UpdateInventoryStatus As Integer

        For Each lstRecord As ListViewItem In OrderDetailsListView.Items

            updItemID = Convert.ToInt32(lstRecord.SubItems(1).Text)
            updQuantity = Convert.ToInt32(lstRecord.SubItems(3).Text)
            dtUpdQuantity = GetQuantityRequired(updItemID)

            If dtUpdQuantity.Rows.Count > 0 Then
                For Each updQuantityRow As DataRow In dtUpdQuantity.Rows
                    InventoryIDInteger = Integer.Parse(updQuantityRow.Item("InventoryItemID").ToString())
                    InvQuantity = Integer.Parse(updQuantityRow.Item("Required_Qty").ToString())
                    UpdateInventoryStatus = UpdateInventoryQuantity(InventoryIDInteger, InvQuantity * updQuantity)

                Next
            End If
        Next
    End Sub
    Public Function ordersTotal() As Decimal
        Dim index As Integer = 0
        Dim selPrice As Decimal = 0D
        Dim totalPrice As Decimal = 0D

        Try
            If OrderDetailsListView.Items.Count > 0 Then
                For Each lstRecord As ListViewItem In OrderDetailsListView.Items
                    selPrice = selPrice + (Convert.ToDecimal(OrderDetailsListView.Items(index).SubItems(5).Text))
                Next
            End If
            If selPrice > 0D Then
                If txtPromoDiscount.Text = "" Then
                    totalPrice = selPrice + (selPrice * Tax_Rate).ToString
                Else
                    selPrice = selPrice - (selPrice * Convert.ToInt32(txtPromoDiscount.Text) / 100)
                    totalPrice = selPrice + selPrice * Tax_Rate
                End If
            Else
                totalPrice = 0D
            End If
        Catch ex As Exception
            MsgBox(ex.Message)
        End Try
        Return totalPrice
    End Function

    Private Sub RemoveButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RemoveButton.Click
        Try
            If OrderDetailsListView.Items.Count = 0 Then
                MsgBox("No items to remove", MsgBoxStyle.Critical, "Error")
                Exit Sub
            Else
                Dim itmCnt, i, t As Integer
                OrderDetailsListView.FocusedItem.Remove()
                itmCnt = OrderDetailsListView.Items.Count
                t = 1
                For i = 1 To itmCnt + 1
                    t = t + 1
                Next
                txtSubTotal.Text = subOrderTotal().ToString("N2")
                txtTaxAmt.Text = (Convert.ToDecimal(txtSubTotal.Text) * Tax_Rate).ToString("N2")
                txtTotal.Text = ordersTotal().ToString("N2")
                txtTotalPayment.Text = txtTotal.Text
            End If
            If OrderDetailsListView.Items.Count = 0 Then
                txtSubTotal.Text = ""
                txtTaxAmt.Text = ""
                txtTotal.Text = ""
                txtPrmotionCode.Text = ""
                txtPromoDiscount.Text = ""
                txtTotalPayment.Text = ""
            End If
        Catch ex As Exception
            MessageBox.Show(ex.Message, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error)
        End Try
    End Sub

    Private Sub AddNewItemsCheckBox_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs)
        MenuItemsComboBox.Enabled = True
        txtQuantity.Enabled = True
        AddMenuItemsButton.Enabled = True
    End Sub

    Private Sub MenuItemsComboBox_SelectionChangeCommitted(ByVal sender As Object, ByVal e As System.EventArgs) Handles MenuItemsComboBox.SelectionChangeCommitted
        Dim Value As Integer
        MenuItemsTo = New MenuItemsTodo()
        Value = MenuItemsComboBox.SelectedValue
        txtUnitPrice.Text = MenuItemsTo.LoadPriceDetails(Value).ToString()
        If txtUnitPrice.Text = "" Then
            txtUnitPrice.Text = 1.99D
        End If
    End Sub

    Private Sub EditOrderDetails_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Clear()
        Sql = New SqlHelper()
        MenuItemsTo = New MenuItemsTodo()
        Dim dtItemInfo As DataTable
        Dim dtPaymentInfo As DataTable
        Dim InOrderID As Integer = 0
        Try
            ' Set up and fill the DataSet.
            dtItemInfo = MenuItemsTo.LoadItemDetails()
            ' Set up the binding source.
            With MenuItemsComboBox
                .DataSource = dtItemInfo
                .DisplayMember = "ItemName"
                .ValueMember = "MenuID"
            End With
            CreateMenuItemsDataTable()


            dtPaymentInfo = GetPaymentTypes()
            With cmbPaymentType
                .DataSource = dtPaymentInfo
                .DisplayMember = "PaymentType"
                .ValueMember = "PaymentTypeID"
            End With

            InOrderID = GetMenuItemID()
            'txtOrderID.Text = InOrderID
        Catch ex As Exception
            MessageBox.Show("Data Error: " & ex.Message)
        End Try
    End Sub
    Private Sub CreateMenuItemsDataTable()
        AMenuItemsDataTable = New DataTable
        AMenuItemsDataTable.Columns.Add(New DataColumn("ItemID", System.Type.GetType("System.Int32")))
        AMenuItemsDataTable.Columns(0).Unique = True
        AMenuItemsDataTable.Columns.Add(New DataColumn("ItemName", System.Type.GetType("System.String")))
        AMenuItemsDataTable.Columns.Add(New DataColumn("Quantity", System.Type.GetType("System.Int32")))
        AMenuItemsDataTable.Columns.Add(New DataColumn("UnitPrice", System.Type.GetType("System.Decimal")))
        AMenuItemsDataTable.Columns.Add(New DataColumn("TotalPrice", System.Type.GetType("System.Decimal")))
    End Sub
    Private Sub PaymentTypeButton_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PaymentButton.Click
        Dim insertPayment As Integer

        insertPayment = InsertPaymentDetails(Convert.ToInt32(txtOrderID.Text), If(cmbPaymentType.SelectedValue = 0, 1, cmbPaymentType.SelectedValue), Date.Today.Date, Convert.ToDecimal(txtTotalPayment.Text))

        If insertPayment > 0 Then
            MessageBox.Show("Your Payment is successfull and your Payment ID is : " & insertPayment & "", "Payment Successfull", MessageBoxButtons.OK)
            btnUpdateOrder.Enabled = False
            'btnPrint.Enabled = True
            Clear()
            Me.Hide()
            MainForm.Show()
        End If
    End Sub


    Private Sub btnSearchPromoCode_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnSearchPromoCode.Click
        PromoDetails.frmEditOrders = "EditOrders"
        PromoDetails.Show()
    End Sub

    Private Sub btnApply_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnApply.Click
        If OrderDetailsListView.Items.Count = 0 Then
            MessageBox.Show("Please select atleast one menu item and then apply discount .... ", "Error in Order", MessageBoxButtons.OK, MessageBoxIcon.Error)
            Exit Sub
        End If
        Dim SubTotalPromo As Decimal
        If txtSubTotal.Text <> "" Then
            SubTotalPromo = (Convert.ToInt32(txtPromoDiscount.Text) * Convert.ToDecimal(txtSubTotal.Text) / 100)
        End If
        txtTotal.Text = ordersTotal().ToString("N2")
        txtTotalPayment.Text = txtTotal.Text
    End Sub

    Public Function InsertOrders(InEmployeeID As Integer, InOrderDate As DateTime, InOrderAmount As Decimal, InDiscountPercent As Integer, InDiscountAmount As Decimal, InNetOrderAmount As Decimal) As Integer
        Dim InsertSuccess As Integer = 0
        Dim insertStr As String = ""
        insertStr = "INSERT INTO Orders (EmployeeID, OrderDate, OrderAmount, DiscountPercent, DiscountAmount, NetOrderAmount) VALUES (" & InEmployeeID & ",'" & InOrderDate & "','" & InOrderAmount & "'," & InDiscountPercent & ",'" & InDiscountAmount & "','" & InNetOrderAmount & "')"
        InsertSuccess = Sql.ExecuteInsUpdDel(insertStr, True) REM True, it is Insert
        Return InsertSuccess

    End Function
    Public Function UpdateOrders(InOrderID As Integer, InEmployeeID As Integer, InOrderAmount As Decimal, InDiscountPercent As Integer, InDiscountAmount As Decimal, InNetOrderAmount As Decimal) As Integer
        Dim updateSuccess As Integer = 0
        Dim updateStr As String = ""
        updateStr = "UPDATE Orders SET EmployeeID = " & InEmployeeID & ", OrderAmount = '" & InOrderAmount & "', DiscountPercent = " & InDiscountPercent & ", DiscountAmount = '" & InDiscountAmount & "', NetOrderAmount = '" & InNetOrderAmount & "' where OrderID = " & InOrderID
        updateSuccess = Sql.ExecuteInsUpdDel(updateStr, True) REM True, it is Insert
        Return updateSuccess
    End Function



    Public Function UpdateInventoryItems(InInventoryID As Integer, InQuantity As Integer) As Integer
        Dim UpdateSuccess As Integer = 0
        Dim updateStr As String = ""
        updateStr = "UPDATE InventoryItems SET AvailableQty =  (AvailableQty - " & InQuantity & " ) WHERE InventoryID = " & InInventoryID
        UpdateSuccess = Sql.ExecuteInsUpdDel(updateStr) REM True, it is Insert
        Return UpdateSuccess

    End Function

    Public Function UpdateInventoryQuantity(InInventoryID As Integer, InQuantity As Integer) As Integer
        Dim UpdateSuccess As Integer = 0
        Dim updateStr As String = ""
        updateStr = "UPDATE InventoryItems SET AvailableQty =  (AvailableQty + " & InQuantity & " ) WHERE InventoryID = " & InInventoryID
        UpdateSuccess = Sql.ExecuteInsUpdDel(updateStr) REM True, it is Insert
        Return UpdateSuccess

    End Function


    Public Function InsertOrderDetails(InOrderID As Integer, InItemID As Integer, InQuantity As Integer, InUnitPrice As Decimal) As Integer
        Dim InsertSuccess As Integer = 0
        Dim insertStr As String = ""
        insertStr = "INSERT INTO OrderItems (OrderID, ItemID, Quantity, UnitPrice) values (" & InOrderID & "," & InItemID & "," & InQuantity & ",'" & InUnitPrice & "')"
        InsertSuccess = Sql.ExecuteInsUpdDel(insertStr, True) REM True, it is Insert
        Return InsertSuccess

    End Function
    Public Function GetQuantityRequired(InMenuItemID As Integer) As DataTable
        Dim selTable As DataTable = Nothing
        Dim selectStr As String = ""
        selectStr = "SELECT InventoryItemID, Required_Qty FROM ItemAssignments WHERE MenuItemID = " & InMenuItemID & ""
        selTable = Sql.ExecuteSelectTable(selectStr) REM True, it is Insert
        Return selTable
    End Function


    Public Function GetPaymentTypes() As DataTable
        Dim selTable As DataTable = Nothing
        Dim selectStr As String = ""
        selectStr = "SELECT PaymentTypeID, PaymentType FROM PaymentTypes"
        selTable = Sql.ExecuteSelectTable(selectStr) REM True, it is Insert
        Return selTable
    End Function


    Public Function GetMenuItemID() As Integer
        Dim GetMaxID As Integer
        Dim selectStr As String
        Sql = New SqlHelper()
        selectStr = "select Max(OrderID) as MaxID from Orders"
        GetMaxID = Sql.GetMaxID(selectStr)
        Return GetMaxID
    End Function


    Public Function InsertPaymentDetails(InOrderID As Integer, InPaymentTypeID As Integer, InPaymentDate As Date, InPaymentAmount As Decimal) As Integer
        Dim InsertSuccess As Integer = 0
        Dim insertStr As String = ""
        'insertStr = "INSERT INTO Payments ( OrderID, PaymentTypeID, PaymentDate, PaymentAmount) values (" & InOrderID & "," & InPaymentTypeID & "," & InPaymentDate & ",'" & InPaymentAmount & "')"
        insertStr = "UPDATE Payments  SET PaymentDate = " & InPaymentDate & ", PaymentAmount ='" & InPaymentAmount & "' WHERE OrderID = " & InOrderID
        InsertSuccess = Sql.ExecuteInsUpdDel(insertStr, True) REM True, it is Insert
        Return InsertSuccess

    End Function


    Private Sub btnPrint_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        Dim PrintPreview As New PrintPreviewDialog
        PrintPreview.Document = PrintOrderDocument
        PrintPreview.ShowDialog()
    End Sub
    'Private Sub PrintDocument1_PrintPage(ByVal sender As Object, ByVal e As System.Drawing.Printing.PrintPageEventArgs) Handles PrintOrderDocument.PrintPage

    '    If OrderDetailsListView.View = View.Details Then
    '        PrintDetails(e)
    '    End If
    'End Sub

    Private Sub OrderDetails_FormClosing(sender As System.Object, e As System.Windows.Forms.FormClosingEventArgs) Handles MyBase.FormClosing
        If MessageBox.Show("Please save any unsaved changes and then navigate to main menu view?", "Are you sure to Exit?", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = Windows.Forms.DialogResult.OK Then
            'Me.Close()
            Clear()
            MainForm.Show()
        Else
            e.Cancel = True
        End If
    End Sub


    Sub Clear()

        For Each txtControls In Me.Controls
            If TypeOf txtControls Is TextBox Then
                txtControls.Text = ""     'Clear all text
            End If
        Next txtControls

        OrderDetailsListView.Items.Clear()
        OrderDetailsListView.DataBindings.Clear()
    End Sub

    Private Sub btnHome_Click(sender As System.Object, e As System.EventArgs) Handles btnHome.Click
        If MessageBox.Show("Please save any unsaved changes and then navigate to main menu view?", "Are you sure to Exit?", MessageBoxButtons.OKCancel, MessageBoxIcon.Question) = Windows.Forms.DialogResult.OK Then
            Me.Hide()
            Clear()
            MainForm.Show()
        End If
    End Sub

    Private Sub btnClear_Click(sender As System.Object, e As System.EventArgs) Handles btnClear.Click
        If btnClear.Text = "&Create New Order" Then
            Clear()
            txtOrderID.Text = GetMenuItemID()
            MenuItemsComboBox.Focus()
            btnClear.Text = "&Clear"
            btnUpdateOrder.Enabled = True
            PaymentButton.Enabled = False
        End If

        Clear()

    End Sub


    Public Function SelectOrderDetails(InOrderID As Integer) As DataTable
        Sql = New SqlHelper()
        Dim selectStr As String
        Dim dt As DataTable
        selectStr = "SELECT * FROM OrderItems WHERE OrderID = " & InOrderID & ""
        dt = Sql.ExecuteSelectTable(selectStr)
        Return dt
    End Function
    Public Function UpdateOrderDetails(InOrderID As Integer, InItemID As Integer, InQuantity As Integer, InUnitPrice As Decimal) As Integer
        Dim InsertSuccess As Integer = 0
        Dim insertStr As String = ""
        insertStr = "UPDATE OrderItems SET Quantity = " & InQuantity & " WHERE OrderID = " & InOrderID & " AND ItemID =  " & InItemID & ""
        InsertSuccess = Sql.ExecuteInsUpdDel(insertStr, True) REM True, it is Insert
        Return InsertSuccess

    End Function
    Public Function DeleteOrderDetails(InOrderID As Integer, InItemID As Integer) As Integer
        Dim deleteSuccess As Integer = 0
        Dim deleteStr As String = ""
        deleteStr = "DELETE FROM OrderItems WHERE OrderID = " & InOrderID & " AND ItemID =  " & InItemID & ""
        deleteSuccess = Sql.ExecuteInsUpdDel(deleteStr) REM True, it is Insert
        Return deleteSuccess

    End Function

    Public Function DeleteOrders(InOrderID As Integer) As Integer
        Dim deleteSuccess As Integer = 0
        Dim deleteStr As String = ""
        DeleteOrderItems(InOrderID)
        deleteStr = "Update Orders SET IsDeleted = 1, OrderAmount = '0', DiscountPercent = '0', DiscountAmount = '0', NetOrderAmount = '0'  WHERE OrderID = " & InOrderID

        deleteSuccess = Sql.ExecuteInsUpdDel(deleteStr) REM True, it is Insert
        Return deleteSuccess

    End Function
    Public Sub DeleteOrderItems(InOrderID As Integer)
        Dim deleteSuccess As Integer = 0
        Dim deleteStr As String = ""
        deleteStr = "Update OrderItems SET IsDeleted = 1 WHERE OrderID = " & InOrderID
        deleteSuccess = Sql.ExecuteInsUpdDel(deleteStr) REM True, it is Insert
    End Sub


End Class

