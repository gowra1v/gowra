﻿Public Class OrderTodo
    Dim Sql As SqlHelper
    'Property InOrderID As Integer
    Property InCustomerID As Integer
    Property InOrderDate As Date
    Property InOrderAmount As Decimal
    Property InDiscountPercent As Integer
    Property InDiscountAmount As Decimal
    Property InNetOrderAmount As Decimal
    Property InQuantity As Integer
    Property InItemID As Integer
    Property InUnitPrice As Integer

    Public InOrderID As Integer

    Public Sub New()

    End Sub

    Public Sub New(ByVal CustomerID As Integer, ByVal OrderDate As Date, ByVal OrderAmount As Decimal, ByVal DiscountPercent As Integer, ByVal DiscountAmount As Decimal, ByVal NetOrderAmount As Decimal)

        InCustomerID = InCustomerID
        InOrderDate = InOrderDate
        InOrderAmount = InOrderAmount
        InDiscountPercent = InDiscountPercent
        InDiscountAmount = InDiscountAmount
        InNetOrderAmount = InNetOrderAmount
        InOrderID = -1  REM Not in database
    End Sub

    Public Function InsertOrdersIntoDatabase() As Integer
        Sql = New SqlHelper()
        Dim insertStr As String =
            "INSERT INTO Orders (CustomerID, OrderDate, OrderAmount, DiscountPercent, DiscountAmount, NetOrderAmount) VALUES ( " & InCustomerID & ", '" & InOrderDate & "','" & InOrderAmount & "'," & InDiscountPercent & ",'" & InDiscountAmount & "','" & InNetOrderAmount & "')"
        Dim OrderID As Integer = Sql.ExecuteInsUpdDel(insertStr, True)
        Me.InOrderID = OrderID
        Return OrderID
    End Function

    Public Function InsertOrders(InCustomerID As Integer, InOrderDate As DateTime, InOrderAmount As Decimal, InDiscountPercent As Integer, InDiscountAmount As Decimal, InNetOrderAmount As Decimal) As Integer
        Dim InsertSuccess As Integer = 0
        Dim insertStr As String = ""
        insertStr = "INSERT INTO Orders (CustomerID, OrderDate, OrderAmount, DiscountPercent, DiscountAmount, NetOrderAmount) VALUES (" & InCustomerID & ",'" & InOrderDate & "','" & InOrderAmount & "'," & InDiscountPercent & ",'" & InDiscountAmount & "','" & InNetOrderAmount & "')"

        InsertSuccess = Sql.ExecuteInsUpdDel(insertStr, True) REM True, it is Insert
        Return InsertSuccess
    End Function

    Public Function InsertOrderItemsIntoDatabase() As Integer
        Sql = New SqlHelper()
        Dim insertStr As String = "INSERT INTO OrderItems (OrderID,ItemID, Quantity, UnitPrice) VALUES (" & InOrderID & "," & InItemID & "," & InQuantity & ",'" & InUnitPrice & "')"


        Dim OrderID As Integer = Sql.ExecuteInsUpdDel(insertStr)
        'Me.PlayerID = OrderID
        Return OrderID
    End Function
    Public Function UpdateOrderItemsIntoDatabase()
        Sql = New SqlHelper()
        Dim updateStatus As Integer = 0
        Dim updateStr As String =
            "UPDATE OrderItems SET Quantity = " & InQuantity & " , UnitPrice = '" & InUnitPrice & "' WHERE  ItemID = " & InItemID & " AND OrderID = " & InOrderID
        updateStatus = Sql.ExecuteInsUpdDel(updateStr)
        Return updateStatus
    End Function

    Public Function DeleteOrderItemsFromDatabase() As Integer
        Sql = New SqlHelper()
        Dim deleteStr As String
        deleteStr = "DELETE * FROM OrderItems WHERE OrderID = " & InOrderID & " AND ItemID = " & InItemID
        Dim deleteStatus As Integer = Sql.ExecuteInsUpdDel(deleteStr)
        Return deleteStatus
    End Function

    Public Function DeleteOrdersFromDatabase() As Integer
        Sql = New SqlHelper()
        Dim deleteStr As String
        deleteStr = "DELETE * FROM Orders WHERE OrderID = " & InOrderID
        Dim deleteStatus As Integer = Sql.ExecuteInsUpdDel(deleteStr)
        Return deleteStatus
    End Function

    'sSql = "SELECT ItemID,Quantity,Unitprice, (Quantity * Unitprice) AS ItemAmount from OrderItems where OrderID = " & OrderIDInteger
    Public Function SelectOrderDetailsFromDatabase(ByVal OrderIDInteger As Integer) As DataTable
        Sql = New SqlHelper()
        Dim selectStr As String
        Dim dr As DataTable
        selectStr = "SELECT ItemID,Quantity,Unitprice, (Quantity * Unitprice) AS ItemAmount from OrderItems where OrderID = " & OrderIDInteger
        dr = Sql.ExecuteSelectTable(selectStr)
        Return dr
    End Function

End Class
