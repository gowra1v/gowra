﻿Public Class InventoryTodo
    Dim Sql As SqlHelper
    Public Property InInventoryID As Integer
    Public Property InInventoryName As String
    Public Property InCategoryID As Integer
    Public Property InAvailableQuantity As Integer
    Public Property InReorderPoint As Integer


    Public Sub New()

    End Sub

    Public Sub New(ByVal InventoryID As Integer, ByVal InventoryName As String, ByVal CategoryID As Integer,
                   ByVal AvailableQuantity As Integer, ByVal ReorderPoint As Integer)
        InInventoryID = InventoryID
        InInventoryName = InventoryName
        InCategoryID = CategoryID
        InAvailableQuantity = AvailableQuantity
        InReorderPoint = ReorderPoint
    End Sub

    Public Function InsertInventoryItemsIntoDatabase() As Integer
        Sql = New SqlHelper()
        Dim insertStr As String
        Dim InsertSuccess As Integer
        insertStr = " INSERT INTO InventoryItems (InventoryItem, CategoryID, AvailableQty, ReorderPoint) VALUES ('" & InInventoryName & "'," & InCategoryID & "," & InAvailableQuantity & "," & InReorderPoint & ")"
        InsertSuccess = Sql.ExecuteInsUpdDel(insertStr, True) REM True, it is Insert
        Return InsertSuccess
    End Function

    Public Function UpdateInventoryItemsIntoDatabase() As Integer
        Sql = New SqlHelper()
        Dim updateStr As String
        Dim UpdateSuccess As Integer
        updateStr = "UPDATE InventoryItems SET InventoryItem = '" & InInventoryName & "', CategoryID = " & InCategoryID & ", AvailableQty = " & InAvailableQuantity & ",ReorderPoint = " & InReorderPoint & " WHERE InventoryID = " & InInventoryID & ""
        
        UpdateSuccess = Sql.ExecuteInsUpdDel(updateStr) REM True, it is Insert

        Return UpdateSuccess
    End Function

    Public Function DeleteInventoryItemFromDatabase(ByVal InInventoryID As Integer) As Integer
        Sql = New SqlHelper()
        Dim deleteStr As String
        deleteStr = "DELETE * FROM InventoryItems WHERE InventoryID  = " & InInventoryID
        Dim deleteStatus As Integer = Sql.ExecuteInsUpdDel(deleteStr)
        Return deleteStatus
    End Function

    Public Function GetInventoryItemID() As Integer
        Dim GetMaxID As Integer
        Dim selectStr As String
        Sql = New SqlHelper()
        selectStr = "select Max(InventoryID) as MaxID from InventoryItems"
        GetMaxID = Sql.GetMaxID(selectStr)
        Return GetMaxID
    End Function

    Public Function GetCategoryItemID() As Integer
        Dim GetMaxID As Integer
        Dim selectStr As String
        Sql = New SqlHelper()
        selectStr = "select Max(CategoryID) as MaxID from ItemCategories"
        GetMaxID = Sql.GetMaxID(selectStr)
        Return GetMaxID
    End Function

    Public Function LoadInventoryItemsDetails(ByVal InInventoryID As Integer) As DataTable
        Sql = New SqlHelper()
        Dim selectStr As String
        Dim dt As DataTable
        selectStr = "select * from InventoryItems where InventoryID = " & InInventoryID & ""
        dt = Sql.ExecuteSelectTable(selectStr)
        Return dt
    End Function

    Public Function LoadItemCategoriesList(ByVal CountryCode As String) As DataTable
        Sql = New SqlHelper()
        Dim selectStr As String
        Dim dt As DataTable
        selectStr = "select  CategoryID, CategoryName FROM ItemCategories"
        dt = Sql.ExecuteSelectTable(selectStr)
        Return dt

    End Function

    Public Function LoadInventoryItemsDetails() As DataTable
        Sql = New SqlHelper()
        Dim selectStr As String
        Dim dt As DataTable
        selectStr = "select InventoryID, InventoryName, AvailableQty, ReorderPoint from InventoryItems"
        dt = Sql.ExecuteSelectTable(selectStr)
        Return dt
    End Function
End Class
